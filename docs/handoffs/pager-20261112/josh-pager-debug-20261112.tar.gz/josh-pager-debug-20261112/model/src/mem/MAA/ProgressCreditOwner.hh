#ifndef UME_PROGRESS_CREDIT_OWNER_HH
#define UME_PROGRESS_CREDIT_OWNER_HH
#include <functional>
#include <vector>
#include "mem/port.hh"
#include "mem/packet.hh"
#include "mem/request.hh"
#include "base/addr_range.hh"
namespace gem5::maa {
struct ProgressCachePlan { uint64_t parent=0;bool targetBlocked=false,continuation=false; };
class ProgressCreditOwner {
 public:
 virtual ~ProgressCreditOwner() = default;
 virtual void registerProducer(RequestPort&, RequestorID) = 0;
 virtual void registerSpdConsumer(const AddrRange&) = 0;
 virtual void registerCache(const std::vector<ResponsePort*>&,unsigned,unsigned,unsigned,unsigned,
      std::function<ProgressCachePlan(PacketPtr)>,std::function<void(unsigned)>) = 0;
 virtual uint64_t authorizeSpdReceive(const RequestPtr&, Addr, unsigned) const = 0;
 virtual void claimDeferredReceiver(const RequestPtr&, uint64_t, unsigned) = 0;
 virtual void beginResponseHandoff(const RequestPtr&, uint64_t, unsigned) = 0;
 virtual void endResponseHandoff(const RequestPtr&, uint64_t, unsigned, bool) = 0;
 virtual uint64_t reserveInternalPrefetch(PacketPtr,unsigned) = 0;
 virtual void finishInternalAdmission(uint64_t,bool) = 0;
 virtual void completeInternalPrefetch(const RequestPtr&) = 0;
 virtual void bindCacheClone(const RequestPtr&,const RequestPtr&) = 0;
 virtual void bindMshr(const RequestPtr&,uintptr_t) = 0;
 virtual uint64_t mshrOwner(uintptr_t) const = 0;
 virtual void releaseMshr(uintptr_t) = 0;
 virtual void cacheResourcesChanged() = 0;
 virtual bool isSpdLine(Addr) const = 0;
 virtual void chargeDeferredService() = 0;
 virtual bool quiescent() const = 0;
};
}
#endif
