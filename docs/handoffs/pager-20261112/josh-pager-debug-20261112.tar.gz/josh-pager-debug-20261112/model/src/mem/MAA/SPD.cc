#include "mem/MAA/SPD.hh"

#include <algorithm>
#include <cassert>
#include <cstdlib>
#include <cstring>
#include <limits>

#include "base/trace.hh"
#include "base/types.hh"
#include "debug/MAAOperationSummary.hh"
#include "debug/SPD.hh"
#include "mem/MAA/ALU.hh"
#include "mem/MAA/IF.hh"
#include "mem/MAA/IndirectAccess.hh"
#include "mem/MAA/MAA.hh"
#include "mem/MAA/RangeFuser.hh"
#include "mem/MAA/StreamAccess.hh"
#include "sim/cur_tick.hh"
#include "sim/sim_exit.hh"

#ifndef TRACING_ON
#define TRACING_ON 1
#endif

namespace gem5 {

namespace {
struct DevicePageSenderState : public Packet::SenderState
{
    SPD *owner;
    int frame, line, slot;
    uint64_t generation;
    bool write;
};
class DevicePageTranslation : public BaseMMU::Translation
{
  public:
    bool done = false, delayed = false;
    Fault fault = NoFault;
    Addr address = 0;
    void markDelayed() override { delayed = true; }
    void finish(const Fault &f, const RequestPtr &req, ThreadContext *,
                BaseMMU::Mode) override {
        fault = f; address = req->getPaddr(); done = true;
    }
};
}

int SPD::pageIndex(int tile, int element) const {
    return tile * (num_tile_elements / physical_tile_elements) +
           element / physical_tile_elements;
}
int SPD::readyIndex(int tile, int element, int bytes) const {
    return tile * (paged() ? num_tile_elements : physical_tile_elements) +
           element * bytes / 4;
}
uint8_t *SPD::payload(int tile, int element, int bytes) {
    if (!paged())
        return tiles_data + tile * physical_tile_elements * 4 + element * bytes;
    const Page &p = pages[pageIndex(tile, element)];
    panic_if(p.frame < 0 || frames[p.frame].generation != p.generation ||
                 (transferFrame == p.frame && requestedPage != -1),
             "Device SPD access without a resident page tile=%d element=%d",
             tile, element);
    return tiles_data + (p.frame * physical_tile_elements +
                         element % physical_tile_elements) * 4;
}
void SPD::enablePaging(unsigned budget, bool stableFit) {
    panic_if(visible_tile_count != 32 || physical_tile_elements != 4096 ||
                 num_tile_elements != 16384 || (budget < 3 || budget > frames.size()),
             "Device SPD requires logical32x16384, physical32x4096, budget3..32");
    // Runtime diagnostic knob; one metadata record per coherent line.
    // No payload is allocated: packets still reference pinned frame SRAM.
    unsigned credits = 32;
    if (const char *value = std::getenv("DX100_PAGER_LINE_CREDITS")) {
        char *end = nullptr;
        const unsigned long parsed = std::strtoul(value, &end, 10);
        panic_if(!*value || *end || parsed < 1 || parsed > 256,
                 "Pager line credits must be in [1,256]");
        credits = parsed;
    }
    pageLines.resize(credits);
    frameBudget = budget;
    stableCore0Fit = stableFit;
    panic_if(stableFit && budget != 32, "Fixed mapping requires all32 frames");
    registerExitCallback([this] { reportPaging(); });
    pages.resize(visible_tile_count * 4);
    element_finished.assign(visible_tile_count * num_tile_elements, true);
    // Frames [budget,32) are RESERVED, never victims or silently borrowed.
}
void SPD::resetPages(int tile, bool preservePayload) {
    for (unsigned i = 0; i < 4; ++i) {
        const int key = tile * 4 + i;
        Page &p = pages[key];
        panic_if(requestedPage == key ||
                     (p.frame >= 0 && (frames[p.frame].pinned ||
                                       transferFrame == p.frame)),
                 "Device SPD generation overwrite with a live owner");
        if (p.frame >= 0 && !preservePayload)
            frames[p.frame] = Frame{};
        panic_if(p.generation == UINT64_MAX, "Device SPD generation exhausted");
        ++p.generation;
        if (preservePayload) {
            // Native masked loads leave false-lane bytes untouched. Carry
            // the old SRAM/backing bytes into the new generation; readiness
            // is still reset, and native setFakeData completes false lanes.
            if (p.frame >= 0) frames[p.frame].generation = p.generation;
        } else {
            p.frame = -1; p.backed = false;
        }
    }
}
void SPD::releasePages() {
    for (unsigned f = 0; f < frameBudget; ++f)
        frames[f].pinned = false;
}
bool SPD::pageTransferPending(int tile) const {
    if (requestedPage == -1) return false;
    return requestedPage / 4 == tile ||
        (transferFrame >= 0 && frames[transferFrame].page >= 0 &&
         frames[transferFrame].page / 4 == tile);
}
void SPD::releaseOwnerPages(uint8_t owner) {
    // A native unit can discover its final extent while a speculative page
    // lookup is pending. Do not install a retired owner's bit later.
    requestedOwners &= ~owner;
    for (unsigned f = 0; f < frameBudget; ++f)
        frames[f].pinned &= ~owner;
}
bool SPD::ensurePage(int tile, int element, bool pin) {
    return leasePage(tile, element, pin, 1);
}
bool SPD::leasePage(int tile, int element, bool pin, uint8_t owner) {
    lastPageResult = PageResult::Ready;
    if (!paged()) return true;
    check_tile_element_id(tile, element, 4);
    panic_if(stableCore0Fit && tile >= 8,
             "Stable fit overlap supports worker0 logical IDs0..7 only");
    panic_if(pin && !owner, "A pinned SPD lease needs an engine owner");
    const int key = pageIndex(tile, element);
    Page &p = pages[key];
    if (p.frame >= 0 && transferFrame != p.frame) {
        Frame &f = frames[p.frame];
        panic_if(f.page != key || f.generation != p.generation,
                 "Device SPD directory ownership mismatch");
        if (!pin || !(f.pinned & owner)) { ++directoryLookups; ++lookupCycles; }
        if (pin) f.pinned |= owner;
        f.age = ++pageClock;
        return true;
    }
    lastPageResult = PageResult::Pending;
    if (requestedPage != -1) return false;
    int victim = -1;
    if (stableCore0Fit) {
        // All8 worker0 logical IDs have exactly4 pages. This profile never
        // evicts or changes a frame's page identity; IF hazards qualify the
        // next producer generation before any reader can acquire it.
        panic_if(key >= 32 || (frames[key].page != -1 && frames[key].page != key),
                 "Stable SPD frame identity changed");
        if (!frames[key].pinned) victim = key;
    }
    for (unsigned f = 0; !stableCore0Fit && f < frameBudget; ++f) {
        if (frames[f].pinned) continue;
        if (victim == -1 || frames[f].page == -1 ||
            frames[f].age < frames[victim].age) victim = f;
        if (frames[f].page == -1) break;
    }
    if (victim == -1) {
        lastPageResult = PageResult::NoVictim;
        return false;
    }

    ++directoryLookups; ++pageMisses;
    panic_if(transferOutstanding || lineReadReserved,
             "Device SPD new page transfer with live line ownership");
    requestedPage = key; requestedOwners = pin ? owner : 0;
    pageWaitStart = curTick();
    transferFrame = victim; transferLine = 0;
    spilling = frames[victim].page != -1 && frames[victim].dirty;
    if (spilling) ++dirtyEvictions;
    transferGeneration = frames[victim].generation;
    DPRINTF(MAAOperationSummary,
            "pager_begin page=%d frame=%d spill=%d backed=%d\n",
            key, victim, spilling, p.backed);
    // One shared directory lookup port, one cycle on a page-lease miss.
    transferReady = maa->getClockEdge(Cycles(1));
    maa->scheduleLogicalSPDEvent();
    return false;
}
void SPD::publishPage() {
    panic_if(transferOutstanding,
             "Device SPD publish with live transfer credits");
    pageWaitTicks += curTick() - pageWaitStart;
    DPRINTF(MAAOperationSummary, "pager_end page=%d\n", requestedPage);
    requestedPage = -1; transferFrame = -1;
    unsigned mapped = 0;
    for (unsigned f = 0; f < frameBudget; ++f)
        mapped += frames[f].page >= 0;
    mappedFramePeak = std::max(mappedFramePeak, mapped);
    maa->wakeDevicePager();
}
void SPD::servicePager() {
    if (requestedPage == -1) return;
    // A ReadResp is not sufficient to release a credit: wait for the charged
    // write-port completion too. Responses may arrive in any line order.
    for (auto &slot : pageLines) {
        if (slot.line < 0 || slot.waiting) continue;
        if (slot.ready <= curTick()) {
            slot = PageLine{};
            --transferOutstanding;
        } else {
            maa->scheduleLogicalSPDEvent(
                maa->getTicksToCycles(slot.ready - curTick()));
        }
    }
    if (creditFull && transferOutstanding < pageLines.size()) {
        creditFullTicks += curTick() - creditFullSince;
        creditFull = false;
    }
    if (curTick() < transferReady) {
        maa->scheduleLogicalSPDEvent(
            maa->getTicksToCycles(transferReady - curTick())); return;
    }
    Frame &f = frames[transferFrame];
    if (transferLine == 256) {
        if (transferOutstanding) return;
        if (spilling) {
            // Only all256 WriteResp acknowledgments authorize frame reuse.
            pages[f.page].backed = true;
            f.dirty = false;
            spilling = false;
            transferLine = 0;
        } else {
            publishPage();
            return;
        }
    }
    if (!spilling && transferLine == 0 && f.page != requestedPage) {
        panic_if(transferOutstanding, "Device SPD reassign with live lines");
        if (f.page >= 0) pages[f.page].frame = -1;
        f = Frame{};
        f.page = requestedPage; f.pinned = requestedOwners; f.age = ++pageClock;
        f.generation = pages[requestedPage].generation;
        transferGeneration = f.generation;
        pages[requestedPage].frame = transferFrame;
        if (!pages[requestedPage].backed) {
            lookupCycles++;
            publishPage(); return;
        }
    }
    int available = -1;
    for (unsigned i = 0; i < pageLines.size(); ++i) {
        if (pageLines[i].line == -1) { available = i; break; }
    }
    if (available == -1) {
        if (!creditFull) {
            creditFull = true;
            creditFullSince = curTick();
        }
        return;
    }
    if (spilling && !lineReadReserved) {
        // Keep the exact SRAM reservation across transport retries.
        lineReadReserved = true;
        transferReady = maa->getClockEdge(getDataLatency(1));
        DPRINTF(MAAOperationSummary, "pager_read_port line=%d ready=%lu\n",
                transferLine, transferReady);
        if (curTick() < transferReady) {
            maa->scheduleLogicalSPDEvent(
                maa->getTicksToCycles(transferReady - curTick()));
            return;
        }
    }
    const int key = spilling ? f.page : requestedPage;
    const Addr base = maa->devicePageBacking();
    const Addr address = base + static_cast<Addr>(key) * 16384 + transferLine * 64;
    auto virtualReq = std::make_shared<Request>(
        address, 64, Request::Flags(0), maa->requestorId, 0, 0);
    DevicePageTranslation translation;
    maa->mmu->translateTiming(virtualReq, maa->system->threads[0], &translation,
                             spilling ? BaseMMU::Write : BaseMMU::Read);
    panic_if(!translation.done || translation.delayed || translation.fault != NoFault,
             "Device SPD backing translation failed at %#lx", address);
    auto req = std::make_shared<Request>(translation.address, 64,
                                         Request::Flags(0), maa->requestorId);
    req->setRegion(31);
    auto *pkt = new Packet(req, spilling ? MemCmd::WriteReq : MemCmd::ReadReq);
    pkt->dataStatic(tiles_data + transferFrame * 16384 + transferLine * 64);
    auto *state = new DevicePageSenderState;
    state->owner = this; state->frame = transferFrame; state->line = transferLine;
    state->slot = available;
    state->generation = transferGeneration; state->write = spilling;
    pkt->pushSenderState(state);
    if (!maa->sendPacketRetirementCache(pkt)) {
        pkt->popSenderState(); delete state; delete pkt;
        ++transferRetries;
        // A response or port retry/capacity callback restarts this line.
        return;
    }
    if (!acceptedLines) firstAcceptedTick = curTick();
    lastAcceptedTick = curTick();
    ++acceptedLines;
    auto &slot = pageLines[available];
    slot.line = transferLine;
    slot.waiting = true;
    ++transferOutstanding;
    peakTransferOutstanding =
        std::max(peakTransferOutstanding, transferOutstanding);
    DPRINTF(MAAOperationSummary, "pager_send write=%d line=%d\n",
            spilling, transferLine);
    ++transferLine;
    lineReadReserved = false;
    // One issue opportunity per device cycle, through the same coherent port.
    transferReady = maa->getClockEdge(Cycles(1));
    maa->scheduleLogicalSPDEvent(1);
}
bool SPD::pagerResponse(PacketPtr pkt) {
    auto *state = dynamic_cast<DevicePageSenderState *>(pkt->senderState);
    if (!state) return false;
    panic_if(state->owner != this || requestedPage == -1 ||
                 state->slot < 0 || state->slot >= pageLines.size() ||
                 state->frame != transferFrame ||
                 state->generation != transferGeneration ||
                 state->write != spilling || pkt->isError() ||
                 (spilling ? pkt->cmd != MemCmd::WriteResp :
                  pkt->cmd != MemCmd::ReadResp &&
                  pkt->cmd != MemCmd::ReadRespWithInvalidate),
             "Device SPD stale or invalid coherent response");
    auto &slot = pageLines[state->slot];
    panic_if(!slot.waiting || slot.line != state->line,
             "Device SPD response does not own its line credit");
    DPRINTF(MAAOperationSummary, "pager_response write=%d line=%d\n",
            spilling, state->line);
    slot.waiting = false;
    if (spilling) ++spillLines; else ++fillLines;
    const Cycles latency = spilling ? Cycles(0) :
        setDataLatency(requestedPage / 4, 1);
    slot.ready = maa->getClockEdge(latency);
    if (!spilling)
        DPRINTF(MAAOperationSummary, "pager_write_port line=%d ready=%lu\n",
                state->line, slot.ready);
    pkt->popSenderState(); delete state;
    maa->scheduleLogicalSPDEvent();
    return true;
}
void SPD::reportPaging() const {
    if (!paged()) return;
    inform("pager_credit_cap shared_spill_fill=1 credits=%u "
           "metadata_per_credit=%lu accepted_lines=%lu "
           "first_accepted_tick=%lu last_accepted_tick=%lu "
           "credit_full_ticks=%lu rejected_attempts=%lu peak=%u",
           unsigned(pageLines.size()), sizeof(PageLine), acceptedLines,
           firstAcceptedTick, lastAcceptedTick,
           creditFullTicks + (creditFull ? curTick()-creditFullSince : 0),
           transferRetries, peakTransferOutstanding);
    inform("device_spd tick=%lu pages=128 directory_entry_bytes=%lu "
           "frame_entries=32 "
           "frame_budget=%u reserved_frames=%u payload_bytes=524288 "
           "ready_bitmap_bytes=65536 directory_bytes=%lu frame_metadata_bytes=%lu "
           "misses=%lu lookups=%lu fill_lines=%lu spill_lines=%lu "
           "dirty_evictions=%lu transfer_credits=%u "
           "transfer_metadata_bytes=%lu "
           "peak_transfer_credits=%u transfer_retries=%lu "
           "mapped_frame_peak=%u page_wait_ticks=%lu", curTick(), sizeof(Page),
           frameBudget, 32-frameBudget, pages.size()*sizeof(Page),
           sizeof(frames), pageMisses, directoryLookups, fillLines, spillLines,
           dirtyEvictions, unsigned(pageLines.size()),
           pageLines.size() * sizeof(PageLine),
           peakTransferOutstanding,
           transferRetries, mappedFramePeak, pageWaitTicks);
}

///////////////
//
// SPD
//
///////////////
Cycles SPD::getDataLatency(int num_accesses) {
    if (paged()) {
        num_accesses += lookupCycles;
        lookupCycles = 0;
    }
    if (num_accesses == 0) {
        return Cycles(0);
    }
    panic_if(num_accesses < 0, "Invalid number of accesses: %d\n", num_accesses);
    int min_busy_port = 0;
    Tick min_busy_until = read_port_busy_until[0];
    for (int i = 0; i < num_read_ports; i++) {
        if (read_port_busy_until[i] < min_busy_until) {
            min_busy_until = read_port_busy_until[i];
            min_busy_port = i;
        }
    }
    if (read_port_busy_until[min_busy_port] < curTick()) {
        read_port_busy_until[min_busy_port] = curTick();
    }
    read_port_busy_until[min_busy_port] += maa->getCyclesToTicks(Cycles(read_latency * num_accesses));
    DPRINTF(SPD, "%s: read_port_busy_until[%d] = %lu\n", __func__, min_busy_port, read_port_busy_until[min_busy_port]);
    panic_if(read_port_busy_until[min_busy_port] < curTick(),
             "Scheduled read at %lu, but current tick is %lu!\n",
             read_port_busy_until[min_busy_port], curTick());
    return maa->getTicksToCycles(read_port_busy_until[min_busy_port] - curTick());
}
Cycles SPD::setDataLatency(int tile_id, int num_accesses) {
    check_tile_id(tile_id, sizeof(uint32_t));
    if (num_accesses == 0) {
        return Cycles(0);
    }
    panic_if(num_accesses < 0, "Invalid number of accesses: %d\n", num_accesses);
    int min_busy_port = 0;
    Tick min_busy_until = write_port_busy_until[0];
    for (int i = 0; i < num_write_ports; i++) {
        if (write_port_busy_until[i] < min_busy_until) {
            min_busy_until = write_port_busy_until[i];
            min_busy_port = i;
        }
    }
    if (write_port_busy_until[min_busy_port] < curTick()) {
        write_port_busy_until[min_busy_port] = curTick();
    }
    write_port_busy_until[min_busy_port] += maa->getCyclesToTicks(Cycles(write_latency * num_accesses));
    panic_if(write_port_busy_until[min_busy_port] < curTick(),
             "Scheduled write at %lu, but current tick is %lu!\n",
             write_port_busy_until[min_busy_port], curTick());
    DPRINTF(SPD, "%s: write_port_busy_until[%d] = %lu\n", __func__, min_busy_port, write_port_busy_until[min_busy_port]);
    wakeup_waiting_units(tile_id);
    return maa->getTicksToCycles(write_port_busy_until[min_busy_port] - curTick());
}
SPD::TileStatus SPD::getTileStatus(int tile_id) {
    check_tile_id(tile_id, sizeof(uint32_t));
    return tiles_status[tile_id];
}
void SPD::setTileIdle(int tile_id, int word_size) {
    setTileIdleImpl(tile_id, word_size, false);
}
void SPD::setTileIdleMasked(int tile_id, int word_size) {
    panic_if(!paged() || word_size != 4,
             "Masked device SPD requires32-bit paging");
    setTileIdleImpl(tile_id, word_size, true);
}
void SPD::setTileIdleImpl(int tile_id, int word_size, bool preservePayload) {
    check_tile_id(tile_id, word_size);
    tiles_status[tile_id] = SPD::TileStatus::Idle;
    if (word_size == 8) {
        tiles_status[tile_id + 1] = SPD::TileStatus::Idle;
    }
    if (paged()) {
        panic_if(word_size != 4, "Device paging supports 32-bit tiles only");
        resetPages(tile_id, preservePayload);
    }
    const unsigned capacity = paged() ? num_tile_elements : physical_tile_elements;
    for (int i = 0; i < capacity * word_size / 4; i++) {
        element_finished[tile_id * capacity + i] = false;
    }
}
void SPD::setTileFinished(int tile_id, int word_size) {
    check_tile_id(tile_id, word_size);
    tiles_status[tile_id] = SPD::TileStatus::Finished;
    if (word_size == 8) {
        tiles_status[tile_id + 1] = SPD::TileStatus::Finished;
    }
}
void SPD::setTileService(int tile_id, int word_size) {
    check_tile_id(tile_id, word_size);
    if (paged() && tiles_status[tile_id] == SPD::TileStatus::Idle) {
        // A dirty CPU line returned by invalidation belongs to the replaced
        // value. It may update SRAM, but cannot publish elements of the new
        // producer generation. Clear readiness after invalidation, before IF
        // readers can acquire Service leases; do not change that generation.
        std::fill(element_finished.begin() + tile_id * num_tile_elements,
                  element_finished.begin() + (tile_id + 1) * num_tile_elements,
                  false);
    }
    tiles_status[tile_id] = SPD::TileStatus::Service;
    if (word_size == 8) {
        tiles_status[tile_id + 1] = SPD::TileStatus::Service;
    }
}
void SPD::setTileDirty(int tile_id, int word_size) {
    check_tile_id(tile_id, word_size);
    tiles_dirty[tile_id] = true;
    if (word_size == 8) {
        tiles_dirty[tile_id + 1] = true;
    }
}
void SPD::setTileClean(int tile_id, int word_size) {
    check_tile_id(tile_id, word_size);
    tiles_dirty[tile_id] = false;
    if (word_size == 8) {
        tiles_dirty[tile_id + 1] = false;
    }
}
bool SPD::getTileDirty(int tile_id) {
    check_tile_id(tile_id, sizeof(uint32_t));
    return tiles_dirty[tile_id];
}
void SPD::setTileReady(int tile_id, int word_size) {
    check_tile_id(tile_id, word_size);
    panic_if(tiles_ready[tile_id] == 0 ||
                 (word_size == 8 && tiles_ready[tile_id + 1] == 0),
             "Tile %d received a ready credit without a matching debit\n",
             tile_id);
    tiles_ready[tile_id]--;
    wakeup_waiting_units(tile_id);
    if (word_size == 8) {
        tiles_ready[tile_id + 1]--;
        wakeup_waiting_units(tile_id + 1);
    }
}
void SPD::setTileNotReady(int tile_id, int word_size) {
    check_tile_id(tile_id, word_size);
    constexpr auto max_ready_refs = std::numeric_limits<uint16_t>::max();
    panic_if(tiles_ready[tile_id] == max_ready_refs ||
                 (word_size == 8 &&
                  tiles_ready[tile_id + 1] == max_ready_refs),
             "Tile %d exceeded the readiness-reference limit\n", tile_id);
    tiles_ready[tile_id]++;
    if (word_size == 8) {
        tiles_ready[tile_id + 1]++;
    }
}
bool SPD::getTileReady(int tile_id) {
    check_tile_id(tile_id, sizeof(uint32_t));
    return tiles_ready[tile_id] == 0;
}
bool SPD::getElementFinished(int tile_id, int element_id, int word_size,
                             uint8_t func, int id) {
    check_tile_id(tile_id, word_size);
    bool is_element_finished;
    // Functional units use one-past-the-tile as a sentinel while waiting for
    // the producer to mark the whole tile finished. With a smaller physical
    // tile, that sentinel begins at physical rather than logical capacity.
    if (element_id >= (paged() ? num_tile_elements : physical_tile_elements)) {
        is_element_finished = false;
    } else {
        check_tile_element_id(tile_id, element_id, word_size);
        int tile_element_id = readyIndex(tile_id, element_id, word_size);
        is_element_finished = element_finished[tile_element_id];
    }
    if (is_element_finished == false &&
        (std::find(waiting_units_ids[tile_id].begin(), waiting_units_ids[tile_id].end(), id) == waiting_units_ids[tile_id].end() ||
         std::find(waiting_units_funcs[tile_id].begin(), waiting_units_funcs[tile_id].end(), func) == waiting_units_funcs[tile_id].end())) {
        DPRINTF(SPD, "%s: adding %s[%d] to waiting list tile[%d]\n", __func__, func_unit_names[func], id, tile_id);
        waiting_units_funcs[tile_id].push_back(func);
        waiting_units_ids[tile_id].push_back(id);
    }
    return is_element_finished;
}
void SPD::wakeup_waiting_units(int tile_id) {
    check_tile_id(tile_id, sizeof(uint32_t));
    for (int i = 0; i < waiting_units_funcs[tile_id].size(); i++) {
        int waiting_units_id = waiting_units_ids[tile_id][i];
        switch (waiting_units_funcs[tile_id][i]) {
        case (uint8_t)FuncUnitType::ALU: {
            assert(maa->aluUnits[waiting_units_id].getState() == ALUUnit::Status::Work);
            maa->aluUnits[waiting_units_id].scheduleNextExecution(true);
            break;
        }
        case (uint8_t)FuncUnitType::STREAM: {
            assert(maa->streamAccessUnits[waiting_units_id].getState() == StreamAccessUnit::Status::Request);
            maa->streamAccessUnits[waiting_units_id].scheduleNextExecution(true);
            break;
        }
        case (uint8_t)FuncUnitType::INDIRECT: {
            assert(maa->indirectAccessUnits[waiting_units_id].getState() == IndirectAccessUnit::Status::Fill ||
                   maa->indirectAccessUnits[waiting_units_id].getState() == IndirectAccessUnit::Status::Request);
            maa->indirectAccessUnits[waiting_units_id].scheduleNextExecution(true);
            break;
        }
        case (uint8_t)FuncUnitType::RANGE: {
            assert(maa->rangeUnits[waiting_units_id].getState() == RangeFuserUnit::Status::Work);
            maa->rangeUnits[waiting_units_id].scheduleNextExecution(true);
            break;
        }
        }
    }
    waiting_units_funcs[tile_id].clear();
    waiting_units_ids[tile_id].clear();
}
int SPD::getSize(int tile_id) {
    check_tile_id(tile_id, sizeof(uint32_t));
    panic_if(getTileStatus(tile_id) != SPD::TileStatus::Finished,
             "Trying to get size of an uninitialized tile[%d]!\n",
             tile_id);
    return static_cast<int>(tiles_size[tile_id]);
}
int SPD::getSizeForReadyElement(int tile_id, int element_id, int word_size) {
    check_tile_element_id(tile_id, element_id, word_size);
    const int tile_element_id =
        readyIndex(tile_id, element_id, word_size);
    panic_if(!element_finished[tile_element_id],
             "Tile %d element %d is not ready to publish its size\n",
             tile_id, element_id);
    return static_cast<int>(tiles_size[tile_id]);
}
void SPD::setSize(int tile_id, int size) {
    check_tile_id(tile_id, sizeof(uint32_t));
    panic_if(size < 0 || size > static_cast<int>(paged() ? num_tile_elements : physical_tile_elements),
             "SPD tile size %d exceeds physical capacity %u "
             "(logical capacity %u) for tile[%d]!\n",
             size, physical_tile_elements, num_tile_elements, tile_id);
    tiles_size[tile_id] = size;
}
void SPD::setVirtualSize(int tile_id, int size) {
    check_tile_id(tile_id, sizeof(uint32_t));
    panic_if(size < 0 || size > static_cast<int>(num_tile_elements),
             "Invalid virtual tile size %d (logical max=%u) for tile[%d]!\n",
             size, num_tile_elements, tile_id);
    tiles_size[tile_id] = size;
}
SPD::SPD(MAA *_maa,
         unsigned int _visible_tile_count,
         unsigned int _num_tile_elements,
         unsigned int _physical_tile_elements,
         Cycles _read_latency,
         Cycles _write_latency,
         int _num_read_ports,
         int _num_write_ports)
    : visible_tile_count(_visible_tile_count),
      num_tile_elements(_num_tile_elements),
      physical_tile_elements(_physical_tile_elements),
      read_latency(_read_latency),
      write_latency(_write_latency),
      num_read_ports(_num_read_ports),
      num_write_ports(_num_write_ports),
      maa(_maa) {

    panic_if(physical_tile_elements == 0 ||
                 physical_tile_elements > num_tile_elements,
             "Invalid physical/logical SPD capacities: %u/%u\n",
             physical_tile_elements, num_tile_elements);
    panic_if(visible_tile_count == 0,
             "SPD must expose at least one architectural tile\n");
    const std::size_t payload_bytes_per_tile =
        static_cast<std::size_t>(physical_tile_elements) * sizeof(uint32_t);
    panic_if(visible_tile_count >
                 std::numeric_limits<std::size_t>::max() /
                     payload_bytes_per_tile,
             "SPD payload size overflows host accounting: %u tiles x %zu "
             "bytes\n",
             visible_tile_count, payload_bytes_per_tile);
    const std::size_t allocated_payload_bytes =
        static_cast<std::size_t>(visible_tile_count) * payload_bytes_per_tile;
    const std::size_t allocated_element_count =
        static_cast<std::size_t>(visible_tile_count) *
        physical_tile_elements;

    tiles_data = new uint8_t[allocated_payload_bytes];
    tiles_status = new SPD::TileStatus[visible_tile_count];
    tiles_dirty = new bool[visible_tile_count];
    tiles_ready = new uint16_t[visible_tile_count];
    tiles_size = new uint32_t[visible_tile_count];
    for (unsigned int i = 0; i < visible_tile_count; i++) {
        tiles_status[i] = SPD::TileStatus::Finished;
        tiles_size[i] = 0;
        tiles_dirty[i] = false;
        tiles_ready[i] = 0;
    }
    element_finished.resize(allocated_element_count);
    for (std::size_t i = 0; i < allocated_element_count; i++) {
        element_finished[i] = true;
    }
    waiting_units_funcs =
        new std::vector<uint8_t>[visible_tile_count];
    waiting_units_ids = new std::vector<int>[visible_tile_count];
    memset(tiles_data, 0, allocated_payload_bytes);
    read_port_busy_until = new Tick[num_read_ports];
    write_port_busy_until = new Tick[num_write_ports];
    for (int i = 0; i < num_read_ports; i++) {
        read_port_busy_until[i] = curTick();
    }
    for (int i = 0; i < num_write_ports; i++) {
        write_port_busy_until[i] = curTick();
    }
}
SPD::~SPD() {
    assert(tiles_data != nullptr);
    delete[] tiles_data;
    assert(tiles_status != nullptr);
    delete[] tiles_status;
    assert(tiles_dirty != nullptr);
    delete[] tiles_dirty;
    assert(tiles_ready != nullptr);
    delete[] tiles_ready;
    assert(tiles_size != nullptr);
    delete[] tiles_size;
    assert(read_port_busy_until != nullptr);
    delete[] read_port_busy_until;
    assert(write_port_busy_until != nullptr);
    delete[] write_port_busy_until;
    assert(waiting_units_funcs != nullptr);
    delete[] waiting_units_funcs;
    assert(waiting_units_ids != nullptr);
    delete[] waiting_units_ids;
}

///////////////
//
// RF
//
///////////////
RF::RF(unsigned int _num_regs) : num_regs(_num_regs) {
    data = new uint8_t[num_regs * 4];
    memset(data, 0, num_regs * 4 * sizeof(uint8_t));
}
RF::~RF() {
    assert(data != nullptr);
    delete[] data;
}
} // namespace gem5
