#ifndef __MEM_MAA_SOA_JIT_STORE_EPOCH_CONTRACT_HH__
#define __MEM_MAA_SOA_JIT_STORE_EPOCH_CONTRACT_HH__

#include <cstdint>

namespace gem5::maa
{

// Assertion snapshot of existing controller counters, not persistent storage.
// Each pressure epoch admits a contiguous source prefix, then closes its
// coherent writes before the rejected source ordinal can be retried.
struct SoaJitStoreEpochSnapshot
{
    uint64_t logical, begin, end, cursor, selected, applied, offsets, contexts;
    uint64_t readIssues, readResponses, writeIssues, writeResponses;
    uint64_t valueIssues, valueResponses;
    bool final, retry;
    int64_t retryOrdinal;

    bool validCursor() const {
        return logical > 0 && logical <= 16384 && begin < end &&
            end <= logical && cursor == end && selected == end &&
            (final ? end == logical && !retry && retryOrdinal == -1
                   : end < logical && retry &&
                         retryOrdinal == static_cast<int64_t>(end));
    }

    bool acknowledged() const {
        return contexts == 0 && readIssues == readResponses &&
            writeIssues == writeResponses && readIssues == writeIssues &&
            valueIssues == valueResponses;
    }

    bool validAdmission() const {
        return validCursor() && acknowledged() && applied == begin &&
            offsets == end - begin && (begin != 0 || readIssues == 0);
    }

    bool validCompletion() const {
        return validCursor() && acknowledged() && applied == end &&
            offsets == 0 && writeIssues > 0;
    }
};

} // namespace gem5::maa
#endif
