#ifndef GEM5_MAA_WINDOW_TIMING_OBSERVER_HH
#define GEM5_MAA_WINDOW_TIMING_OBSERVER_HH
#if defined(MAA_WINDOW_TIMING_OBSERVER) && MAA_WINDOW_TIMING_OBSERVER
#include <cinttypes>
#include <cerrno>
#include <cstdint>
#include <cstdio>

namespace gem5::maa {
// Host-only diagnostic state. No simulated storage, latency, readiness or
// scheduling decisions. Disabled builds include neither this type nor hooks.
struct WindowTimingObserver {
    using U64 = uint64_t;
    static constexpr unsigned Bins = 65;
    static constexpr unsigned Metrics = 6;
    static constexpr U64 RecordLimit = 512;
    struct Sample {
        U64 unit = 0;
        U64 core = 0;
        U64 uid = 0;       // Existing unit + my_decode_start_tick, run-scoped.
        U64 generation = 0; // Existing SoA generation; zero means not supplied.
        U64 epoch = 0;
        U64 kind = 0;      // 1 virtual producer, 2 SoA RMW, 3 other indirect.
        U64 logical = 0;
        bool logical_known = false;
        U64 observed = 0;
        U64 begin = 0;
        U64 close = 0;
        U64 ready = 0;
        U64 claim = 0;
        U64 first_a = 0;
        U64 offsets = 0;
        U64 admissions = 0; // Existing cumulative row-insert successes for UID.
        int64_t cursor = -1;
        int64_t epoch_start = -1; // Existing SoA epoch ordinal, otherwise unknown.
        U64 drains = 0;
        U64 complete = 0;
        U64 backing_ack = 0;
        U64 seen = 0; // 1 begin,2 close,4 committed claim,8 A-created,16 complete,32 ack.
    } current{};
    bool active = false;
    bool summarized = false;
    bool exit_registered = false;
    U64 emitted = 0;
    U64 dropped = 0;
    U64 epochs = 0;
    U64 invalid_intervals = 0;
    U64 causes[3] = {}; // Fill-wait-finish, Fill-wait-element, Offset/Row drain.
    U64 publication_credit_observations = 0;
    U64 publications = 0;
    U64 hist[Metrics][Bins] = {};

    bool register_once() {
        if (exit_registered) return false;
        exit_registered = true;
        return true;
    }
    static U64 inc(U64 n) { return n == UINT64_MAX ? n : n + 1; }
    static unsigned bucket(U64 value) {
        unsigned n = 0;
        while (value != 0) {
            ++n;
            value >>= 1;
        }
        return n;
    }
    void sample(unsigned metric, U64 value) {
        const unsigned b = bucket(value);
        hist[metric][b] = inc(hist[metric][b]);
    }
    void interval(unsigned metric, U64 start, U64 end) {
        if (end < start) {
            invalid_intervals = inc(invalid_intervals);
            return;
        }
        sample(metric, end - start);
    }
    // I/O only: state transitions and the hard record cap live in flush().
    void emit_epoch(unsigned reason) const {
        const int saved_errno = errno;
        const Sample &s = current;
        std::fprintf(stderr,
            "UME_WINDOW_OBSERVER v1 type=epoch unit=%" PRIu64 " core=%" PRIu64
            " uid=%" PRIu64 " generation=%" PRIu64 " epoch=%" PRIu64
            " kind=%" PRIu64 " generation_is_soa=%u logical=%" PRIu64 " logical_known=%u"
            " observed=%" PRIu64 " begin=%" PRIu64 " close=%" PRIu64
            " ready=%" PRIu64 " claim=%" PRIu64 " a_created=%" PRIu64
            " first_a_offsets=%" PRIu64 " first_a_cursor=%" PRId64
            " first_a_admissions_total=%" PRIu64 " first_a_epoch_start=%" PRId64
            " drains=%" PRIu64 " complete=%" PRIu64 " backing_ack=%" PRIu64
            " seen=%" PRIu64 " reason=%u publication_to_A=UNBOUND\n",
            s.unit,s.core,s.uid,s.generation,s.epoch,s.kind,unsigned(s.kind == 2),s.logical,
            unsigned(s.logical_known),s.observed,s.begin,s.close,s.ready,
            s.claim,s.first_a,s.offsets,s.cursor,s.admissions,s.epoch_start,s.drains,s.complete,
            s.backing_ack,s.seen,reason);
        errno = saved_errno;
    }
    void flush(unsigned reason) {
        if (!active) return;
        if (emitted < RecordLimit) {
            emit_epoch(reason);
            emitted = inc(emitted);
        } else {
            dropped = inc(dropped);
        }
        active = false;
    }
    void touch(U64 unit, U64 core, U64 uid, U64 generation, U64 epoch,
               int64_t logical, U64 kind, U64 now) {
        if (summarized) return;
        if (active && current.unit == unit && current.core == core &&
            current.uid == uid && current.generation == generation && current.epoch == epoch)
            return;
        flush(1); // New identity/epoch, NOT a fabricated completion.
        current = Sample{};
        current.unit = unit;
        current.core = core;
        current.uid = uid;
        current.generation = generation;
        current.epoch = epoch;
        current.kind = kind;
        if (logical >= 0) {
            current.logical = logical;
            current.logical_known = true;
        }
        current.observed = now;
        active = true;
        epochs = inc(epochs);
    }
    void pre_begin(U64 now) {
        if (!active || (current.seen & 1)) return;
        current.begin = now;
        current.seen |= 1;
    }
    void pre_close(U64 now, U64 ready_tick) {
        if (!active || (current.seen & 2)) return;
        current.close = now;
        current.ready = ready_tick;
        current.seen |= 2;
        if (current.seen & 1) interval(0, current.begin, now);
    }
    void committed_claim(U64 now, bool accepted, bool commit) {
        if (!active || !accepted || !commit || (current.seen & 4)) return;
        current.claim = now;
        current.seen |= 4;
        if (current.seen & 2) interval(1, current.close, now);
    }
    void first_a(U64 now, U64 offsets, int64_t cursor, U64 drains,
                 U64 admissions, int64_t epoch_start) {
        if (!active || (current.seen & 8)) return;
        current.first_a = now;
        current.offsets = offsets;
        current.cursor = cursor;
        current.admissions = admissions;
        current.epoch_start = epoch_start;
        current.drains = drains;
        current.seen |= 8;
        sample(4, offsets);
        if (cursor >= 0) sample(5, cursor);
        if (current.seen & 2) {
            interval(2, current.close, now);
            interval(3, current.ready, now);
        }
    }
    void cause(unsigned which) {
        if (summarized) return;
        if (which < 3) causes[which] = inc(causes[which]);
        // Counts of observed existing branches, NOT stall durations/ROI cycles.
    }
    void finish(U64 now, U64 ack, U64 drains) {
        if (!active) return;
        current.complete = now;
        current.drains = drains;
        current.seen |= 16;
        if (ack != 0) {
            current.backing_ack = ack;
            current.seen |= 32;
        }
        flush(2);
    }
    void emit_publication(U64 unit, U64 core, U64 uid, U64 sequence,
                          U64 generation, U64 page, U64 backing, U64 elements,
                          U64 now) const {
        const int saved_errno = errno;
            std::fprintf(stderr,
                "UME_WINDOW_OBSERVER v1 type=publication unit=%" PRIu64
                " core=%" PRIu64 " uid=%" PRIu64 " sequence=%" PRIu64
                " generation=%" PRIu64 " page=%" PRIu64 " backing=%" PRIu64
                " elements=%" PRIu64 " complete=%" PRIu64 " consumer=UNBOUND\n",
                unit,core,uid,sequence,generation,page,backing,elements,now);
        errno = saved_errno;
    }
    void publication(U64 unit, U64 core, U64 uid, U64 sequence,
                     U64 generation, U64 page, U64 backing, U64 elements,
                     U64 now) {
        if (summarized) return;
        publications = inc(publications);
        // No retained cross-UID/backing-address join and no causal latency.
        if (emitted < RecordLimit) {
            emit_publication(unit, core, uid, sequence, generation, page, backing, elements, now);
            emitted = inc(emitted);
        } else {
            dropped = inc(dropped);
        }
    }
    void publication_credit() {
        if (summarized) return;
        publication_credit_observations = inc(publication_credit_observations);
    }
    void emit_summary(U64 unit, unsigned kind) const {
        const int saved_errno = errno;
        std::fprintf(stderr,
            "UME_WINDOW_OBSERVER v1 type=summary unit=%" PRIu64
            " unit_kind=%u emitted=%" PRIu64 " dropped=%" PRIu64
            " epochs=%" PRIu64 " invalid_intervals=%" PRIu64
            " wait_finish_observations=%" PRIu64 " wait_element_observations=%" PRIu64
            " drain_branch_observations=%" PRIu64 " publication_credit_observations=%" PRIu64
            " publications=%" PRIu64 " state_bytes=%zu no_ROI_sum=1 join=UNBOUND\n",
            unit,kind,emitted,dropped,epochs,invalid_intervals,causes[0],causes[1],
            causes[2],publication_credit_observations,publications,sizeof(*this));
        for (unsigned metric = 0; metric < Metrics; ++metric) {
            std::fprintf(stderr,"UME_WINDOW_OBSERVER v1 type=hist unit=%" PRIu64
                " unit_kind=%u metric=%u bins=",unit,kind,metric);
            for (unsigned b = 0; b < Bins; ++b)
                std::fprintf(stderr,"%s%" PRIu64,b ? "," : "",hist[metric][b]);
            std::fprintf(stderr,"\n");
        }
        errno = saved_errno;
    }
    void summary(U64 unit, unsigned kind) {
        if (summarized) return;
        flush(3); // Exit with incomplete context remains explicitly incomplete.
        summarized = true;
        emit_summary(unit, kind);
    }
};
static_assert(sizeof(WindowTimingObserver) <= 4096, "bounded host observer state");
} // namespace gem5::maa
#endif
#endif
