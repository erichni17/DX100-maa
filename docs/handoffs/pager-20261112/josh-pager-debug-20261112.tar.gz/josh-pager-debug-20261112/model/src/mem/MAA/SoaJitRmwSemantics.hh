#ifndef __MEM_MAA_SOA_JIT_RMW_SEMANTICS_HH__
#define __MEM_MAA_SOA_JIT_RMW_SEMANTICS_HH__

#include <cstdint>
#include <cstring>
#include <type_traits>

namespace gem5::maa
{

/** Arithmetic semantics shared by the ordered SoA/JIT RMW paths. */
enum class SoaJitRmwOperation : uint8_t
{
    Add,
    Min,
    Max,
};

/**
 * Apply one typed RMW operation.  INT32 ADD is explicitly modulo 2^32:
 * performing signed addition directly would make overflow undefined in C++.
 * The memcpy round trip preserves the exact 32-bit storage representation.
 */
template <typename T>
inline void
applySoaJitRmw(T &lhs, T rhs, SoaJitRmwOperation operation)
{
    switch (operation) {
      case SoaJitRmwOperation::Add:
        if constexpr (std::is_same_v<T, int32_t>) {
            static_assert(sizeof(int32_t) == sizeof(uint32_t));
            uint32_t lhs_bits = 0;
            uint32_t rhs_bits = 0;
            std::memcpy(&lhs_bits, &lhs, sizeof(lhs_bits));
            std::memcpy(&rhs_bits, &rhs, sizeof(rhs_bits));
            const uint32_t sum_bits = lhs_bits + rhs_bits;
            std::memcpy(&lhs, &sum_bits, sizeof(lhs));
        } else {
            lhs += rhs;
        }
        return;
      case SoaJitRmwOperation::Min:
        lhs = lhs < rhs ? lhs : rhs;
        return;
      case SoaJitRmwOperation::Max:
        lhs = lhs > rhs ? lhs : rhs;
        return;
    }
}

} // namespace gem5::maa

#endif // __MEM_MAA_SOA_JIT_RMW_SEMANTICS_HH__
