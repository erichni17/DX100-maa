#ifndef __MEM_MAA_ORDERED_SCATTER_ASSIGNMENT_HH__
#define __MEM_MAA_ORDERED_SCATTER_ASSIGNMENT_HH__

#include <cstdint>
#include <cstring>

namespace gem5::maa
{

// One context owns one coherent destination line. All aliases for that line
// must apply in original source order, even if value responses arrive out of
// order. This permits repeated destinations with serial last-writer semantics.
// Context reset after acknowledged retirement resets this ordering state.
class OrderedScatterAssignment
{
  public:
    static constexpr uint32_t LogicalElements = 16384;

    bool apply(uint8_t *line, uint32_t word, uint32_t ordinal,
               const uint8_t *value, uint32_t word_bytes = 4) {
        if (!line || !value || (word_bytes != 4 && word_bytes != 8) ||
            word >= 64 / word_bytes ||
            ordinal < nextMinimum || ordinal >= LogicalElements)
            return false;
        std::memcpy(line + word * word_bytes, value, word_bytes);
        nextMinimum = ordinal + 1;
        return true;
    }

  private:
    uint32_t nextMinimum = 0;
};
static_assert(sizeof(OrderedScatterAssignment) == sizeof(uint32_t),
              "charge four bytes of ordering state per provisioned context");

} // namespace gem5::maa

#endif
