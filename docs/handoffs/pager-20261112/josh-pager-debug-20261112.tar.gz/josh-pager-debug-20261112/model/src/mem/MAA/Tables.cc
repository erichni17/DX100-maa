#include "mem/MAA/Tables.hh"

#include <limits>

#include "base/logging.hh"
#include "debug/MAAOffsetTable.hh"
#include "debug/MAARequestTable.hh"
#include "debug/MAARowTable.hh"
#include "mem/MAA/MAA.hh"

#ifndef TRACING_ON
#define TRACING_ON 1
#endif

namespace gem5 {

///////////////
// REQUEST TABLE
///////////////
// NOTE: this class was rewritten from O(num_addresses) linear scans to O(1)
// lookups (hash map + free-slot stack + per-slot fill count). It is intended to
// be behavior-preserving: the same entries are stored/returned in the same order
// and the same stats are incremented under the same conditions; only the host
// cost of add_entry/get_entries/is_full changes. Verified via stats-identical
// comparison against the pre-change baseline.
RequestTable::RequestTable(MAA *_maa, unsigned int _num_addresses, unsigned int _num_entries_per_address, int _my_unit_id, bool _is_stream) {
    maa = _maa;
    num_addresses = _num_addresses;
    num_entries_per_address = _num_entries_per_address;
    my_unit_id = _my_unit_id;
    is_stream = _is_stream;
    entries = new RequestTableEntry *[num_addresses];
    entry_count = new int[num_addresses];
    addresses = new Addr[num_addresses];
    for (int i = 0; i < num_addresses; i++) {
        entries[i] = new RequestTableEntry[num_entries_per_address];
        entry_count[i] = 0;
    }
    addr_to_idx.reserve(num_addresses);
    free_slots.reserve(num_addresses);
    // Seed in reverse so that pop_back() hands out slots 0,1,2,... first,
    // matching the old "lowest free index" allocation order.
    for (int i = num_addresses - 1; i >= 0; i--) {
        free_slots.push_back(i);
    }
}
RequestTable::~RequestTable() {
    for (int i = 0; i < num_addresses; i++) {
        delete[] entries[i];
    }
    delete[] entries;
    delete[] entry_count;
    delete[] addresses;
}
std::vector<RequestTableEntry> RequestTable::get_entries(Addr base_addr) {
    std::vector<RequestTableEntry> result;
    auto it = addr_to_idx.find(base_addr);
    if (it != addr_to_idx.end()) {
        int i = it->second;
        // entries are filled contiguously [0, entry_count), so this returns them
        // in the same order the old valid-flag scan did.
        for (int j = 0; j < entry_count[i]; j++) {
            result.push_back(entries[i][j]);
        }
        entry_count[i] = 0;
        addr_to_idx.erase(it);
        free_slots.push_back(i);
    }
    return result;
}
bool RequestTable::add_entry(int itr, Addr base_addr, uint16_t wid) {
    auto it = addr_to_idx.find(base_addr);
    int address_itr;
    if (it != addr_to_idx.end()) {
        address_itr = it->second;
    } else {
        if (free_slots.empty()) {
            return false;
        }
        address_itr = free_slots.back();
        free_slots.pop_back();
        addresses[address_itr] = base_addr;
        addr_to_idx[base_addr] = address_itr;
        entry_count[address_itr] = 0;
        if (is_stream) {
            (*maa->stats.STR_NumCacheLineInserted[my_unit_id])++;
        } else {
            (*maa->stats.IND_NumCacheLineInserted[my_unit_id])++;
        }
    }
    assert(entry_count[address_itr] < (int)num_entries_per_address);
    entries[address_itr][entry_count[address_itr]] = RequestTableEntry(itr, wid);
    entry_count[address_itr]++;
    if (is_stream) {
        (*maa->stats.STR_NumWordsInserted[my_unit_id])++;
    } else {
        (*maa->stats.IND_NumWordsInserted[my_unit_id])++;
    }
    return true;
}
void RequestTable::check_reset() {
    panic_if(!addr_to_idx.empty(), "Request table not empty: %zu address(es) still valid!\n", addr_to_idx.size());
    for (int i = 0; i < num_addresses; i++) {
        panic_if(entry_count[i] != 0, "Slot %d still has %d valid entries!\n", i, entry_count[i]);
    }
}
void RequestTable::reset() {
    addr_to_idx.clear();
    free_slots.clear();
    for (int i = num_addresses - 1; i >= 0; i--) {
        free_slots.push_back(i);
    }
    for (int i = 0; i < num_addresses; i++) {
        entry_count[i] = 0;
    }
}
bool RequestTable::is_full() {
    return free_slots.empty();
}

///////////////
//
// OFFSET TABLE
//
///////////////
void OffsetTable::allocate(int _my_unit_id,
                           int _num_entries,
                           MAA *_maa,
                           bool _is_stream) {
    my_unit_id = _my_unit_id;
    num_entries = _num_entries;
    maa = _maa;
    is_stream = _is_stream;
    panic_if(num_entries <= 0, "Offset Table must have positive capacity\n");
    entries = new OffsetTableEntry[num_entries];
    entries_valid = new bool[num_entries];
    free_entries.reserve(num_entries);
    for (int i = num_entries - 1; i >= 0; i--) {
        entries_valid[i] = false;
        entries[i].next_itr = -1;
        entries[i].wid = -1;
        entries[i].itr = -1;
        entries[i].pass = -1;
        free_entries.push_back(i);
    }
}
int OffsetTable::insert(int itr, int wid, int last_entry, int pass) {
    panic_if(summary_mode,
             "Offset Table reorder insert attempted during summary phase\n");
    panic_if(free_entries.empty(),
             "Offset Table is full while inserting logical iteration %d\n",
             itr);
    const int entry_id = free_entries.back();
    free_entries.pop_back();
    panic_if(entries_valid[entry_id],
             "Offset Table free entry %d is still valid\n", entry_id);
    entries[entry_id].itr = itr;
    entries[entry_id].wid = wid;
    entries[entry_id].next_itr = -1;
    entries[entry_id].pass = pass;
    entries_valid[entry_id] = true;
    if (last_entry != -1) {
        panic_if(last_entry < 0 || last_entry >= num_entries ||
                     !entries_valid[last_entry],
                 "Offset Table tail %d is invalid\n", last_entry);
        entries[last_entry].next_itr = entry_id;
    }
    if (is_stream) {
        (*maa->stats.STR_NumWordsInserted[my_unit_id])++;
    } else {
        (*maa->stats.IND_NumWordsInserted[my_unit_id])++;
    }
    return entry_id;
}
void OffsetTable::beginInlineOperandMode() {
    panic_if(summary_mode || inline_operand_mode || occupancy() != 0,
             "Offset Table inline-operand mode requires one empty, ordinary "
             "epoch\n");
    inline_operand_mode = true;
}
void OffsetTable::endInlineOperandMode() {
    panic_if(!inline_operand_mode || summary_mode || occupancy() != 0,
             "Offset Table inline-operand mode closed with live aux state\n");
    inline_operand_mode = false;
}
uint32_t OffsetTable::inlineOperandBits(int entry) const {
    panic_if(!inline_operand_mode || summary_mode || entry < 0 ||
                 entry >= num_entries || !entries_valid[entry],
             "Offset Table inline operand read from invalid entry %d\n",
             entry);
    return static_cast<uint32_t>(entries[entry].pass);
}
std::vector<OffsetTableEntry> OffsetTable::get_entry_recv(int first_itr) {
    std::vector<OffsetTableEntry> result;
    assert(first_itr != -1);
    int itr = first_itr;
    int prev_itr = itr;
    while (itr != -1) {
        panic_if(itr < 0 || itr >= num_entries || !entries_valid[itr],
                 "Entry %d is invalid!\n", itr);
        result.push_back(entries[itr]);
        prev_itr = itr;
        itr = entries[itr].next_itr;
        // Invalidate the previous itr
        entries_valid[prev_itr] = false;
        entries[prev_itr].itr = -1;
        entries[prev_itr].wid = -1;
        entries[prev_itr].next_itr = -1;
        entries[prev_itr].pass = -1;
        free_entries.push_back(prev_itr);
    }
    return result;
}
OffsetTableEntry OffsetTable::consume_entry(int &itr) {
    panic_if(summary_mode,
             "Offset Table consume attempted during summary phase\n");
    panic_if(itr < 0 || itr >= num_entries || !entries_valid[itr],
             "Entry %d is invalid!\n", itr);
    OffsetTableEntry result = entries[itr];
    entries_valid[itr] = false;
    entries[itr].itr = -1;
    entries[itr].wid = -1;
    entries[itr].next_itr = -1;
    entries[itr].pass = -1;
    free_entries.push_back(itr);
    itr = result.next_itr;
    return result;
}
OffsetTableEntry OffsetTable::peek_entry(int itr) const {
    panic_if(itr < 0 || itr >= num_entries || entries_valid[itr] == false,
             "Entry %d is invalid!\n", itr);
    return entries[itr];
}
int OffsetTable::count_entries(int itr) const {
    panic_if(summary_mode,
             "Offset Table count attempted during summary phase\n");
    int count = 0;
    while (itr != -1) {
        panic_if(itr < 0 || itr >= num_entries || !entries_valid[itr],
                 "Entry %d is invalid while counting!\n", itr);
        count++;
        itr = entries[itr].next_itr;
    }
    return count;
}
void OffsetTable::beginSummary() {
    panic_if(summary_mode || inline_operand_mode,
             "Offset Table summary conflicts with inline aux ownership\n");
    panic_if(occupancy() != 0,
             "Offset Table summary phase requires empty reorder state\n");
    for (int i = 0; i < num_entries; ++i) {
        panic_if(entries_valid[i] || entries[i].itr != -1 ||
                     entries[i].wid != -1 || entries[i].next_itr != -1,
                 "Offset Table entry %d is not clean for summary reuse\n", i);
    }
    summary_mode = true;
    summary_records = 0;
    summary_observations = 0;
    summary_probes = 0;
}
bool OffsetTable::observeSummaryKey(uint32_t key) {
    panic_if(!summary_mode,
             "Offset Table summary observation outside summary phase\n");
    panic_if(key > static_cast<uint32_t>(std::numeric_limits<int>::max()),
             "Offset Table summary key %u exceeds signed storage\n", key);
    const uint32_t start =
        (key * uint32_t(2654435761U)) % static_cast<uint32_t>(num_entries);
    for (int probe = 0; probe < num_entries; ++probe) {
        summary_probes++;
        const int slot = (start + probe) % num_entries;
        if (!entries_valid[slot]) {
            entries_valid[slot] = true;
            entries[slot].itr = static_cast<int>(key);
            entries[slot].wid = 1;
            entries[slot].next_itr = -1;
            summary_records++;
            summary_observations++;
            return true;
        }
        if (entries[slot].itr == static_cast<int>(key)) {
            panic_if(entries[slot].wid == std::numeric_limits<int>::max(),
                     "Offset Table summary count overflow for key %u\n", key);
            entries[slot].wid++;
            summary_observations++;
            return true;
        }
    }
    return false;
}
void OffsetTable::endSummary() {
    panic_if(!summary_mode, "Offset Table summary phase is not active\n");
    summary_mode = false;
    reset();
    summary_records = 0;
    summary_observations = 0;
    summary_probes = 0;
}
void OffsetTable::check_reset() {
    panic_if(summary_mode || inline_operand_mode,
             "Offset Table reset check with an active aux owner\n");
    for (int i = 0; i < num_entries; i++) {
        panic_if(entries_valid[i], "Entry %d is valid: wid(%d) next_itr(%d)!\n",
                 i, entries[i].wid, entries[i].next_itr);
        panic_if(entries[i].next_itr != -1, "Entry %d has next_itr(%d) with wid(%d)!\n",
                 i, entries[i].next_itr, entries[i].wid);
        panic_if(entries[i].wid != -1, "Entry %d has wid(%d) with next_itr(%d)!\n",
                 i, entries[i].wid, entries[i].next_itr);
        panic_if(entries[i].itr != -1,
                 "Entry %d has logical iteration %d while free!\n",
                 i, entries[i].itr);
        panic_if(entries[i].pass != -1,
                 "Entry %d has bounded pass %d while free!\n",
                 i, entries[i].pass);
    }
    panic_if(static_cast<int>(free_entries.size()) != num_entries,
             "Offset Table has %d/%d free entries at reset\n",
             static_cast<int>(free_entries.size()), num_entries);
}
void OffsetTable::reset() {
    panic_if(summary_mode || inline_operand_mode,
             "Offset Table reset with an active aux owner\n");
    free_entries.clear();
    for (int i = num_entries - 1; i >= 0; i--) {
        entries_valid[i] = false;
        entries[i].itr = -1;
        entries[i].next_itr = -1;
        entries[i].wid = -1;
        entries[i].pass = -1;
        free_entries.push_back(i);
    }
}

///////////////
//
// ROW TABLE ENTRY
//
///////////////
void RowTableEntry::allocate(int _my_unit_id,
                             int _my_table_id,
                             int _my_table_row_id,
                             int _num_RT_entries_per_row,
                             OffsetTable *_offset_table,
                             MAA *_maa,
                             bool _is_stream) {
    my_unit_id = _my_unit_id;
    my_table_id = _my_table_id;
    my_table_row_id = _my_table_row_id;
    offset_table = _offset_table;
    maa = _maa;
    is_stream = _is_stream;
    num_RT_entries_per_row = _num_RT_entries_per_row;
    entries = new Entry[num_RT_entries_per_row];
    entries_valid = new bool[num_RT_entries_per_row];
    entries_claimed = new bool[num_RT_entries_per_row];
    last_sent_entry_id = 0;
    for (int i = 0; i < num_RT_entries_per_row; i++) {
        entries_valid[i] = false;
        entries_claimed[i] = false;
    }
}
bool RowTableEntry::find_addr(Addr addr) const {
    for (int i = 0; i < num_RT_entries_per_row; i++) {
        if (entries_valid[i] == true && entries[i].addr == addr) {
            return true;
        }
    }
    return false;
}
bool RowTableEntry::insert(Addr addr, int itr, int wid, int pass) {
    int free_entry_id = -1;
    for (int i = 0; i < num_RT_entries_per_row; i++) {
        if (entries_valid[i] == true && entries[i].addr == addr) {
            entries[i].last_itr =
                offset_table->insert(itr, wid, entries[i].last_itr, pass);
            DPRINTF(MAARowTable, "ROT[%d] ROW[%d] %s: entry[%d] inserted!\n",
                    my_table_id, my_table_row_id, __func__, i);
            return true;
        } else if (entries_valid[i] == false && free_entry_id == -1) {
            free_entry_id = i;
        }
    }
    if (free_entry_id == -1) {
        return false;
    }
    entries[free_entry_id].addr = addr;
    const int offset_entry = offset_table->insert(itr, wid, -1, pass);
    entries[free_entry_id].first_itr = offset_entry;
    entries[free_entry_id].last_itr = offset_entry;
    entries_valid[free_entry_id] = true;
    DPRINTF(MAARowTable, "ROT[%d] ROW[%d] %s: new entry[%d] addr[0x%lx] inserted!\n",
            my_table_id, my_table_row_id, __func__, free_entry_id, addr);
    if (is_stream) {
        (*maa->stats.STR_NumCacheLineInserted[my_unit_id])++;
    } else {
        (*maa->stats.IND_NumCacheLineInserted[my_unit_id])++;
    }
    return true;
}
void RowTableEntry::check_reset() {
    for (int i = 0; i < num_RT_entries_per_row; i++) {
        panic_if(entries_valid[i], "Entry %d is valid: addr(0x%lx)!\n", i, entries[i].addr);
        panic_if(entries_claimed[i], "Entry %d remains claimed!\n", i);
    }
    panic_if(last_sent_entry_id != 0, "Last sent entry id is not 0: %d!\n", last_sent_entry_id);
}
void RowTableEntry::reset() {
    for (int i = 0; i < num_RT_entries_per_row; i++) {
        entries_valid[i] = false;
        entries_claimed[i] = false;
    }
    last_sent_entry_id = 0;
}
bool RowTableEntry::get_entry_send(Addr &addr) {
    assert(last_sent_entry_id <= num_RT_entries_per_row);
    for (; last_sent_entry_id < num_RT_entries_per_row; last_sent_entry_id++) {
        if (entries_valid[last_sent_entry_id] == true) {
            addr = entries[last_sent_entry_id].addr;
            DPRINTF(MAARowTable, "ROT[%d] ROW[%d] %s: sending entry[%d] addr[0x%lx]!\n",
                    my_table_id, my_table_row_id, __func__,
                    last_sent_entry_id, addr);
            last_sent_entry_id++;
            return true;
        }
    }
    return false;
}
bool RowTableEntry::claim_entry_send(Addr &addr, int &head, int &words,
                                     bool commit) {
    // Virtual claims free their slot immediately, so refill may reuse an
    // earlier slot before this row is drained. The native monotonic send
    // cursor would skip that newly inserted work.
    for (int entry_id = 0; entry_id < num_RT_entries_per_row; entry_id++) {
        if (!entries_valid[entry_id])
            continue;
        addr = entries[entry_id].addr;
        head = entries[entry_id].first_itr;
        words = offset_table->count_entries(head);
        panic_if(words <= 0,
                 "ROT[%d] ROW[%d] cannot claim empty entry[%d]\n",
                 my_table_id, my_table_row_id, entry_id);
        if (commit)
            entries_valid[entry_id] = false;
        DPRINTF(MAARowTable,
                "ROT[%d] ROW[%d] %s: claimed entry[%d] addr[0x%lx] "
                "head[%d] words[%d]!\n",
                my_table_id, my_table_row_id, __func__,
                entry_id, addr, head, words);
        return true;
    }
    return false;
}
bool RowTableEntry::claim_entry_send_native_order(Addr &addr, int &head,
                                                   int &words,
                                                   int &claimed_entry_id) {
    assert(last_sent_entry_id <= num_RT_entries_per_row);
    for (; last_sent_entry_id < num_RT_entries_per_row;
         last_sent_entry_id++) {
        if (!entries_valid[last_sent_entry_id])
            continue;
        const int entry_id = last_sent_entry_id++;
        panic_if(entries_claimed[entry_id],
                 "ROT[%d] ROW[%d] entry[%d] was claimed twice\n",
                 my_table_id, my_table_row_id, entry_id);
        addr = entries[entry_id].addr;
        head = entries[entry_id].first_itr;
        words = offset_table->count_entries(head);
        panic_if(words <= 0,
                 "ROT[%d] ROW[%d] cannot natively claim empty entry[%d]\n",
                 my_table_id, my_table_row_id, entry_id);
        entries_claimed[entry_id] = true;
        claimed_entry_id = entry_id;
        DPRINTF(MAARowTable,
                "ROT[%d] ROW[%d] %s: claimed entry[%d] addr[0x%lx] "
                "head[%d] words[%d]!\n",
                my_table_id, my_table_row_id, __func__, entry_id, addr,
                head, words);
        return true;
    }
    return false;
}
bool RowTableEntry::release_native_claim(int entry_id, Addr addr, int head) {
    panic_if(entry_id < 0 || entry_id >= num_RT_entries_per_row,
             "ROT[%d] ROW[%d] native claim entry %d is out of range\n",
             my_table_id, my_table_row_id, entry_id);
    if (!entries_valid[entry_id] || !entries_claimed[entry_id] ||
        entries[entry_id].addr != addr || entries[entry_id].first_itr != head)
        return false;
    entries_claimed[entry_id] = false;
    entries_valid[entry_id] = false;
    DPRINTF(MAARowTable,
            "ROT[%d] ROW[%d] %s: released entry[%d] addr[0x%lx] "
            "head[%d]!\n",
            my_table_id, my_table_row_id, __func__, entry_id, addr, head);
    return true;
}
bool RowTableEntry::all_entries_claimed() const {
    for (int entry_id = 0; entry_id < num_RT_entries_per_row; entry_id++) {
        if (entries_valid[entry_id] && !entries_claimed[entry_id])
            return false;
    }
    return true;
}
std::vector<OffsetTableEntry> RowTableEntry::get_entry_recv(Addr addr) {
    for (int i = 0; i < num_RT_entries_per_row; i++) {
        if (entries_valid[i] == true && entries[i].addr == addr) {
            entries_valid[i] = false;
            DPRINTF(MAARowTable, "ROT[%d] ROW[%d] %s: entry[%d] addr[0x%lx] received, setting to invalid!\n",
                    my_table_id, my_table_row_id, __func__, i, addr);
            return offset_table->get_entry_recv(entries[i].first_itr);
        }
    }
    return std::vector<OffsetTableEntry>();
}
int RowTableEntry::get_entry_recv_head(Addr addr) {
    for (int i = 0; i < num_RT_entries_per_row; i++) {
        if (entries_valid[i] && entries[i].addr == addr) {
            entries_valid[i] = false;
            return entries[i].first_itr;
        }
    }
    return -1;
}
int RowTableEntry::count_entry_words(Addr addr) const {
    for (int i = 0; i < num_RT_entries_per_row; i++) {
        if (entries_valid[i] && entries[i].addr == addr)
            return offset_table->count_entries(entries[i].first_itr);
    }
    return -1;
}

bool RowTableEntry::all_entries_received() {
    for (int i = 0; i < num_RT_entries_per_row; i++) {
        if (entries_valid[i] == true) {
            return false;
        }
    }
    last_sent_entry_id = 0;
    return true;
}

///////////////
//
// ROW TABLE
//
///////////////
void RowTableSlice::allocate(int _my_unit_id,
                             int _my_table_id,
                             int _num_RT_rows_per_slice,
                             int _num_RT_entries_per_row,
                             OffsetTable *_offset_table,
                             MAA *_maa,
                             bool _is_stream) {
    my_unit_id = _my_unit_id;
    my_table_id = _my_table_id;
    offset_table = _offset_table;
    maa = _maa;
    is_stream = _is_stream;
    num_RT_rows_per_slice = _num_RT_rows_per_slice;
    num_RT_entries_per_row = _num_RT_entries_per_row;
    entries = new RowTableEntry[num_RT_rows_per_slice];
    entries_valid = new bool[num_RT_rows_per_slice];
    entries_sent = new bool[num_RT_rows_per_slice];
    last_sent_grow_addr = 0;
    last_sent_rowid = 0;
    last_sent_grow_rowid = 0;
    virtual_claim_grow_addr = 0;
    virtual_claim_grow_valid = false;
    for (int i = 0; i < num_RT_rows_per_slice; i++) {
        entries[i].allocate(my_unit_id,
                            my_table_id,
                            i,
                            num_RT_entries_per_row,
                            offset_table,
                            maa,
                            is_stream);
        entries_valid[i] = false;
        entries_sent[i] = false;
    }
}
bool RowTableSlice::insert(Addr grow_addr, Addr addr, int itr, int wid,
                           bool &first_CL_access, int pass) {
    first_CL_access = false;
    // 1. Check if the (Row, CL) pair exists
    for (int i = 0; i < num_RT_rows_per_slice; i++) {
        if (entries_valid[i] == true && entries_sent[i] == false && entries[i].grow_addr == grow_addr && entries[i].find_addr(addr)) {
            DPRINTF(MAARowTable, "ROT[%d] %s: grow[0x%lx] addr[0x%lx] found in R[%d]!\n", my_table_id, __func__, grow_addr, addr, i);
            assert(entries[i].insert(addr, itr, wid, pass));
            return true;
        }
    }
    first_CL_access = true;
    // 2. Check if (Row) exists and can insert the new CL
    // 2.1 At the same time, look for a free row
    int free_row_id = -1;
    int num_free_entries = 0;
    for (int i = 0; i < num_RT_rows_per_slice; i++) {
        if (entries_valid[i] == true && entries_sent[i] == false && entries[i].grow_addr == grow_addr) {
            if (entries[i].insert(addr, itr, wid, pass)) {
                DPRINTF(MAARowTable,
                        "ROT[%d] %s: grow[0x%lx] R[%d] inserted new "
                        "addr[0x%lx]!\n",
                        my_table_id, __func__, grow_addr, i, addr);
                return true;
            }
        } else if (entries_valid[i] == false) {
            panic_if(entries_sent[i] == true, "Row[%d] is already sent: grow_addr(0x%lx)!\n", i, entries[i].grow_addr);
            num_free_entries++;
            if (free_row_id == -1) {
                free_row_id = i;
            }
        }
    }
    // 3. Check if we can insert the new Row or we need drain
    if (free_row_id == -1) {
        DPRINTF(MAARowTable, "ROT[%d] %s: no entry exists or available for grow[0x%lx] and addr[0x%lx], requires drain. Avg CL/Row: %d!\n", my_table_id, __func__, grow_addr, addr, getAverageEntriesPerRow());
        return false;
    }
    // 4. Add new (Row), add new (CL)
    DPRINTF(MAARowTable, "ROT[%d] %s: grow[0x%lx] adding to new R[%d]!\n", my_table_id, __func__, grow_addr, free_row_id);
    entries[free_row_id].grow_addr = grow_addr;
    assert(entries[free_row_id].insert(addr, itr, wid, pass));
    entries_valid[free_row_id] = true;
    entries_sent[free_row_id] = false;
    if (num_free_entries == 1) {
        DPRINTF(MAARowTable, "ROT[%d] %s: R[%d] grow[0x%lx] set to full!\n", my_table_id, __func__, free_row_id, grow_addr);
    }
    if (is_stream == false) {
        (*maa->stats.IND_NumRowsInserted[my_unit_id])++;
    }
    return true;
}
float RowTableSlice::getAverageEntriesPerRow() {
    float total_entries = 0.0000;
    for (int i = 0; i < num_RT_rows_per_slice; i++) {
        if (entries_valid[i] == true) {
            for (int j = 0; j < num_RT_entries_per_row; j++) {
                total_entries += entries[i].entries_valid[j] ? 1 : 0;
            }
        }
    }
    return total_entries / num_RT_rows_per_slice;
}
void RowTableSlice::check_reset() {
    for (int i = 0; i < num_RT_rows_per_slice; i++) {
        entries[i].check_reset();
        panic_if(entries_valid[i], "Row[%d] is valid: grow_addr(0x%lx)!\n", i, entries[i].grow_addr);
    }
    panic_if(last_sent_rowid != 0, "Last sent row id is not 0: %d!\n", last_sent_rowid);
    panic_if(virtual_claim_grow_valid,
             "Virtual grow claim 0x%lx is still active!\n",
             virtual_claim_grow_addr);
    panic_if(virtual_claim_grow_addr != 0,
             "Inactive virtual grow claim retained address 0x%lx!\n",
             virtual_claim_grow_addr);
}
void RowTableSlice::reset() {
    for (int i = 0; i < num_RT_rows_per_slice; i++) {
        entries[i].reset();
        entries_valid[i] = false;
        entries_sent[i] = false;
    }
    last_sent_rowid = 0;
    last_sent_grow_rowid = 0;
    last_sent_grow_addr = 0;
    virtual_claim_grow_addr = 0;
    virtual_claim_grow_valid = false;
}
bool RowTableSlice::find_next_grow_addr() {
    for (; last_sent_rowid < num_RT_rows_per_slice; last_sent_rowid++) {
        if (entries_valid[last_sent_rowid] == true && entries_sent[last_sent_rowid] == false) {
            last_sent_grow_rowid = last_sent_rowid;
            last_sent_grow_addr = entries[last_sent_rowid].grow_addr;
            return true;
        }
    }
    last_sent_rowid = 0;
    return false;
}
void RowTableSlice::get_send_grow_rowid() {
    for (; last_sent_grow_rowid < num_RT_rows_per_slice; last_sent_grow_rowid++) {
        if (entries_valid[last_sent_grow_rowid] == true && entries_sent[last_sent_grow_rowid] == false && entries[last_sent_grow_rowid].grow_addr == last_sent_grow_addr) {
            return;
        }
    }
    last_sent_grow_rowid = 0;
    last_sent_grow_addr = 0;
}
bool RowTableSlice::get_entry_send(Addr &addr, bool drain) {
    while (true) {
        if (last_sent_grow_addr == 0) {
            if (find_next_grow_addr() == false)
                return false;
        }
        panic_if(entries_valid[last_sent_grow_rowid] == false, "Row[%d] is invalid: grow_addr(0x%lx)!\n", last_sent_grow_rowid, last_sent_grow_addr);
        panic_if(entries_sent[last_sent_grow_rowid] == true, "Row[%d] is already sent: grow_addr(0x%lx)!\n", last_sent_grow_rowid, last_sent_grow_addr);
        if (entries[last_sent_grow_rowid].get_entry_send(addr)) {
            DPRINTF(MAARowTable, "ROT[%d] %s: ROW[%d] retuned!\n", my_table_id, __func__, last_sent_grow_rowid);
            return true;
        } else {
            DPRINTF(MAARowTable, "ROT[%d] %s: ROW[%d] finished!\n", my_table_id, __func__, last_sent_grow_rowid);
        }
        entries_sent[last_sent_grow_rowid] = true;
        get_send_grow_rowid();
    }
    return false;
}
bool RowTableSlice::claim_entry_send(Addr &addr, int &head, int &words,
                                     bool drain, bool group_by_grow,
                                     bool commit) {
    // Claimed virtual rows are immediately reusable. Scan the bounded row
    // array directly so refill cannot insert work behind native send cursors.
    auto claim_row = [&](int row_id) {
        if (entries[row_id].claim_entry_send(addr, head, words, commit)) {
            DPRINTF(MAARowTable,
                    "ROT[%d] %s: ROW[%d] grow[0x%lx] claimed!\n",
                    my_table_id, __func__, row_id,
                    entries[row_id].grow_addr);
            if (commit && entries[row_id].all_entries_received()) {
                entries_valid[row_id] = false;
                entries_sent[row_id] = false;
                entries[row_id].check_reset();
            }
            return true;
        }
        DPRINTF(MAARowTable,
                "ROT[%d] %s: ROW[%d] finished!\n",
                my_table_id, __func__, row_id);
        panic("ROT[%d] ROW[%d] is valid but has no claimable entries\n",
              my_table_id, row_id);
    };

    if (group_by_grow) {
        while (true) {
            if (!virtual_claim_grow_valid) {
                for (int row_id = 0; row_id < num_RT_rows_per_slice;
                     ++row_id) {
                    if (!entries_valid[row_id] || entries_sent[row_id])
                        continue;
                    virtual_claim_grow_addr = entries[row_id].grow_addr;
                    virtual_claim_grow_valid = true;
                    break;
                }
                if (!virtual_claim_grow_valid)
                    return false;
            }

            for (int row_id = 0; row_id < num_RT_rows_per_slice;
                 ++row_id) {
                if (!entries_valid[row_id] || entries_sent[row_id] ||
                    entries[row_id].grow_addr != virtual_claim_grow_addr)
                    continue;
                if (claim_row(row_id))
                    return true;
            }
            virtual_claim_grow_addr = 0;
            virtual_claim_grow_valid = false;
        }
    }

    panic_if(virtual_claim_grow_valid,
             "Legacy virtual claim saw an active grow group 0x%lx\n",
             virtual_claim_grow_addr);
    for (int row_id = 0; row_id < num_RT_rows_per_slice; row_id++) {
        if (!entries_valid[row_id] || entries_sent[row_id])
            continue;
        if (claim_row(row_id))
            return true;
    }
    return false;
}
bool RowTableSlice::claim_entry_send_native_order(Addr &addr, int &head,
                                                  int &words, bool,
                                                  int &claimed_row_id,
                                                  int &claimed_entry_id) {
    while (true) {
        if (last_sent_grow_addr == 0 && !find_next_grow_addr())
            return false;
        panic_if(!entries_valid[last_sent_grow_rowid],
                 "ROT[%d] native claim row[%d] is invalid\n",
                 my_table_id, last_sent_grow_rowid);
        panic_if(entries_sent[last_sent_grow_rowid],
                 "ROT[%d] native claim row[%d] is already sent\n",
                 my_table_id, last_sent_grow_rowid);
        if (entries[last_sent_grow_rowid].claim_entry_send_native_order(
                addr, head, words, claimed_entry_id)) {
            claimed_row_id = last_sent_grow_rowid;
            DPRINTF(MAARowTable,
                    "ROT[%d] %s: ROW[%d] grow[0x%lx] claimed!\n",
                    my_table_id, __func__, last_sent_grow_rowid,
                    entries[last_sent_grow_rowid].grow_addr);
            return true;
        }
        const int completed_row = last_sent_grow_rowid;
        panic_if(!entries[completed_row].all_entries_claimed(),
                 "ROT[%d] native claim exhausted unclaimed row[%d]\n",
                 my_table_id, completed_row);
        entries_sent[completed_row] = true;
        if (entries[completed_row].all_entries_received()) {
            entries_valid[completed_row] = false;
            entries_sent[completed_row] = false;
            entries[completed_row].check_reset();
        }
        get_send_grow_rowid();
    }
}
bool RowTableSlice::claim_entry_send_sorted(Addr &grow_addr, Addr &addr,
                                             int &head, int &words,
                                             uint64_t &comparisons) {
    int selected_row = -1;
    int selected_entry = -1;
    Addr selected_grow = 0;
    Addr selected_addr = 0;
    comparisons = 0;
    for (int row_id = 0; row_id < num_RT_rows_per_slice; ++row_id) {
        if (!entries_valid[row_id] || entries_sent[row_id])
            continue;
        for (int entry_id = 0;
             entry_id < entries[row_id].num_RT_entries_per_row;
             ++entry_id) {
            if (!entries[row_id].entries_valid[entry_id])
                continue;
            const Addr candidate_grow = entries[row_id].grow_addr;
            const Addr candidate_addr =
                entries[row_id].entries[entry_id].addr;
            if (selected_row == -1) {
                selected_row = row_id;
                selected_entry = entry_id;
                selected_grow = candidate_grow;
                selected_addr = candidate_addr;
                continue;
            }
            comparisons++;
            if (candidate_grow < selected_grow ||
                (candidate_grow == selected_grow &&
                 candidate_addr < selected_addr)) {
                selected_row = row_id;
                selected_entry = entry_id;
                selected_grow = candidate_grow;
                selected_addr = candidate_addr;
            }
        }
    }
    if (selected_row == -1)
        return false;

    RowTableEntry &row = entries[selected_row];
    RowTableEntry::Entry &entry = row.entries[selected_entry];
    grow_addr = selected_grow;
    addr = selected_addr;
    head = entry.first_itr;
    words = offset_table->count_entries(head);
    panic_if(words <= 0,
             "ROT[%d] sorted claim selected empty ROW[%d] entry[%d]\n",
             my_table_id, selected_row, selected_entry);
    row.entries_valid[selected_entry] = false;
    row.entries_claimed[selected_entry] = false;
    if (row.all_entries_received()) {
        entries_valid[selected_row] = false;
        entries_sent[selected_row] = false;
        row.check_reset();
    }
    last_sent_rowid = 0;
    last_sent_grow_rowid = 0;
    last_sent_grow_addr = 0;
    virtual_claim_grow_addr = 0;
    virtual_claim_grow_valid = false;
    DPRINTF(MAARowTable,
            "ROT[%d] sorted claim grow[0x%lx] addr[0x%lx] head[%d] "
            "words[%d] comparisons[%lu]\n",
            my_table_id, grow_addr, addr, head, words, comparisons);
    return true;
}
bool RowTableSlice::release_native_claim(int row_id, int entry_id,
                                         Addr grow_addr, Addr addr,
                                         int head) {
    panic_if(row_id < 0 || row_id >= num_RT_rows_per_slice,
             "ROT[%d] native claim row %d is out of range\n",
             my_table_id, row_id);
    if (!entries_valid[row_id] ||
        entries[row_id].grow_addr != grow_addr ||
        !entries[row_id].release_native_claim(entry_id, addr, head))
        return false;
    if (entries_sent[row_id] && entries[row_id].all_entries_received()) {
        entries_valid[row_id] = false;
        entries_sent[row_id] = false;
        entries[row_id].check_reset();
    }
    return true;
}
void RowTableSlice::reset_virtual_claim_group() {
    virtual_claim_grow_addr = 0;
    virtual_claim_grow_valid = false;
}
std::vector<OffsetTableEntry> RowTableSlice::get_entry_recv(Addr grow_addr, Addr addr, bool check_sent) {
    std::vector<OffsetTableEntry> results;
    for (int i = 0; i < num_RT_rows_per_slice; i++) {
        if (entries_valid[i] == true && (check_sent == false || entries_sent[i] == true) && entries[i].grow_addr == grow_addr) {
            std::vector<OffsetTableEntry> result = entries[i].get_entry_recv(addr);
            if (result.size() == 0) {
                DPRINTF(MAARowTable, "ROT[%d] %s: grow[0x%lx] addr[0x%lx] hit with ROW[%d] but no CLs returned!\n", my_table_id, __func__, grow_addr, addr, i);
                continue;
            }
            DPRINTF(MAARowTable, "ROT[%d] %s: grow[0x%lx] addr[0x%lx] hit with ROW[%d], %d entries returned!\n", my_table_id, __func__, grow_addr, addr, i, result.size());
            panic_if(results.size() != 0, "ROT[%d] %s: duplicate entry is not allowed!\n", my_table_id, __func__);
            results.insert(results.begin(), result.begin(), result.end());
            if (entries[i].all_entries_received()) {
                DPRINTF(MAARowTable, "ROT[%d] %s: all ROW[%d] entries received, setting to invalid!\n", my_table_id, __func__, i);
                entries_valid[i] = false;
                entries_sent[i] = false;
                entries[i].check_reset();
            }
        }
    }
    std::sort(results.begin(), results.end(), [](const OffsetTableEntry& a, const OffsetTableEntry& b) {
        return a.itr < b.itr;
    });
    return results;
}
int RowTableSlice::get_entry_recv_head(Addr grow_addr, Addr addr, bool check_sent) {
    int result = -1;
    for (int i = 0; i < num_RT_rows_per_slice; i++) {
        if (entries_valid[i] && (!check_sent || entries_sent[i]) &&
            entries[i].grow_addr == grow_addr) {
            int head = entries[i].get_entry_recv_head(addr);
            if (head == -1)
                continue;
            panic_if(result != -1, "ROT[%d] %s: duplicate entry is not allowed!\n",
                     my_table_id, __func__);
            result = head;
            if (entries[i].all_entries_received()) {
                entries_valid[i] = false;
                entries_sent[i] = false;
                entries[i].check_reset();
                if (i == last_sent_grow_rowid) {
                    last_sent_grow_rowid = 0;
                    last_sent_grow_addr = 0;
                }
            }
        }
    }
    return result;
}
int RowTableSlice::count_entry_words(Addr grow_addr, Addr addr) const {
    int result = -1;
    for (int i = 0; i < num_RT_rows_per_slice; i++) {
        if (!entries_valid[i] || entries[i].grow_addr != grow_addr)
            continue;
        int count = entries[i].count_entry_words(addr);
        if (count == -1)
            continue;
        panic_if(result != -1,
                 "ROT[%d] duplicate entry while counting addr 0x%lx\n",
                 my_table_id, addr);
        result = count;
    }
    return result;
}
bool RowTableSlice::is_full() {
    for (int i = 0; i < num_RT_rows_per_slice; i++) {
        if (entries_valid[i] == false) {
            return false;
        }
    }
    return true;
}
} // namespace gem5
