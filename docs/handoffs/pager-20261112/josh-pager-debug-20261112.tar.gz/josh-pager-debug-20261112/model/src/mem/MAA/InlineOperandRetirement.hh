#ifndef __MEM_MAA_INLINE_OPERAND_RETIREMENT_HH__
#define __MEM_MAA_INLINE_OPERAND_RETIREMENT_HH__

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>

#include <gem5/maa_page_fed_soa_abi.hh>

namespace gem5::maa
{

struct InlineRetirementRecord
{
    uint32_t destination = UINT32_MAX;
    uint32_t valueBits = 0;
};

static_assert(sizeof(InlineRetirementRecord) ==
              InlineOperandPageFedABI::RetirementRecordBytes);

/**
 * Eight response credits plus one dense line packer. Bulk mode retires finite
 * payload credits as the contiguous WriteResp prefix advances, because one
 * complete logical window is retained in coherent backing. It returns four
 * exact page-prefix barriers. Legacy line-permit methods remain isolated for
 * regression tests.
 */
class InlineOperandRetirementState
{
  public:
    static constexpr size_t Credits = 8;
    static constexpr size_t RecordsPerLine =
        InlineOperandPageFedABI::RetirementRecordsPerLine;
    static constexpr size_t LineBytes = 64;
    static constexpr uint32_t BulkChunkLines =
        InlineOperandPageFedABI::PageElements / RecordsPerLine;
    static constexpr uint32_t BulkChunks =
        InlineOperandPageFedABI::RetirementRingLines / BulkChunkLines;

    enum class Result : uint8_t
    {
        Accepted,
        Disabled,
        Busy,
        Inactive,
        StaleGeneration,
        Full,
        InvalidCredit,
        EarlyVisibility,
        DuplicateResponse,
        DuplicateWait,
        WaitPending,
        PermitMismatch,
        AckOrder,
        Incomplete,
    };

    enum class CreditState : uint8_t
    {
        Free,
        Reserved,
        WriteIssued,
        Visible,
        CpuReadable,
    };

    struct PermitIdentity
    {
        uint64_t generation = 0;
        uint32_t sequence = UINT32_MAX;
        uint64_t lineAddress = 0;
        uint16_t core = UINT16_MAX;
        uint16_t port = UINT16_MAX;
        uint16_t maa = UINT16_MAX;
        int16_t region = -1;
    };

    struct WaitOwner
    {
        uintptr_t packet = 0;
        PermitIdentity permit{};
        bool occupied = false;
    };

    struct Credit
    {
        std::array<uint8_t, LineBytes> payload{};
        uint64_t generation = 0;
        uint32_t sequence = UINT32_MAX;
        uint8_t records = 0;
        CreditState state = CreditState::Free;
        PermitIdentity permit{};
    };

    Result open(bool enabled, uint64_t newGeneration)
    {
        if (!enabled)
            return Result::Disabled;
        if (active)
            return Result::Busy;
        if (newGeneration == 0 ||
            newGeneration > InlineOperandPageFedABI::GenerationMask ||
            newGeneration == generation ||
            (countedMode && newGeneration < generation))
            return Result::StaleGeneration;
        for (const auto &credit : credits)
            if (credit.state != CreditState::Free)
                return Result::Incomplete;
        for (const auto &wait : deferredWaits)
            if (wait.occupied)
                return Result::Incomplete;
        active = true;
        closed = false;
        generation = newGeneration;
        nextSequence = 0;
        nextAck = 0;
        records = 0;
        writeIssues = 0;
        writeResponses = 0;
        waitRequests = 0;
        waitResponses = 0;
        acks = 0;
        highWater = 0;
        bulkMode = false;
        countedMode = false;
        return Result::Accepted;
    }

    Result beginBulk()
    {
        if (!active)
            return Result::Inactive;
        if (bulkMode || nextSequence != 0 || writeIssues != 0 ||
            writeResponses != 0 || waitRequests != 0 || waitResponses != 0 ||
            acks != 0)
            return Result::Busy;
        bulkMode = true;
        return Result::Accepted;
    }

    // Counted mode reuses existing bounded wait storage and counters. Slot 1
    // retains the granted owner until guest ring consumption finishes.
    Result beginCountedBulk(bool enabled)
    {
        if (!enabled)
            return Result::Disabled;
        const auto result = beginBulk();
        if (result == Result::Accepted)
            countedMode = true;
        return result;
    }

    Result requestCountWait(const WaitOwner &owner, WaitOwner &ready)
    {
        if (!active || !countedMode)
            return Result::Inactive;
        if (!validOwner(owner) || owner.permit.generation != generation)
            return Result::StaleGeneration;
        if (owner.permit.sequence != InlineOperandPageFedABI::CountSequence)
            return Result::PermitMismatch;
        if (waitRequests != 0)
            return Result::DuplicateWait;
        ++waitRequests;
        deferredWaits[0] = owner;
        if (releaseBulkWait(ready))
            return Result::Accepted;
        return Result::WaitPending;
    }

    Result readCount(const PermitIdentity &owner, uint64_t &response)
    {
        if (!active || !countedMode)
            return Result::Inactive;
        if (owner.generation != generation)
            return Result::StaleGeneration;
        if (waitResponses != 1 || !closed || acks != nextSequence)
            return Result::EarlyVisibility;
        if (!samePermit(deferredWaits[1].permit, owner))
            return Result::PermitMismatch;
        if (nextAck != 0)
            return Result::AckOrder;
        response = InlineOperandPageFedABI::encodeCount(generation, records);
        nextAck = 1;
        return Result::Accepted;
    }

    Result acknowledgeCount(const PermitIdentity &owner)
    {
        if (!active || !countedMode)
            return Result::Inactive;
        if (owner.generation != generation)
            return Result::StaleGeneration;
        if (nextAck != 1)
            return Result::AckOrder;
        if (!samePermit(deferredWaits[1].permit, owner))
            return Result::PermitMismatch;
        deferredWaits[1] = WaitOwner();
        nextAck = 2;
        return Result::Accepted;
    }

    Result reserve(uint8_t recordCount, uint8_t &creditIndex)
    {
        if (!active)
            return Result::Inactive;
        if ((countedMode && closed) || recordCount == 0 ||
            recordCount > RecordsPerLine)
            return Result::InvalidCredit;
        for (uint8_t index = 0; index < credits.size(); ++index) {
            Credit &credit = credits[index];
            if (credit.state != CreditState::Free)
                continue;
            credit = Credit();
            credit.generation = generation;
            credit.records = recordCount;
            credit.state = CreditState::Reserved;
            creditIndex = index;
            size_t used = 0;
            for (const auto &candidate : credits)
                used += candidate.state != CreditState::Free;
            if (used > highWater)
                highWater = used;
            return Result::Accepted;
        }
        return Result::Full;
    }

    Result fill(uint8_t creditIndex, const InlineRetirementRecord *source,
                uint8_t recordCount)
    {
        if (!valid(creditIndex))
            return Result::InvalidCredit;
        Credit &credit = credits[creditIndex];
        if (!active || credit.generation != generation)
            return Result::StaleGeneration;
        if (credit.state != CreditState::Reserved || source == nullptr ||
            recordCount == 0 || recordCount > RecordsPerLine)
            return Result::InvalidCredit;
        if (countedMode && (closed || records % RecordsPerLine != 0 ||
            records + recordCount > InlineOperandPageFedABI::LogicalElements ||
            nextSequence >= InlineOperandPageFedABI::RetirementRingLines))
            return Result::Full;
        credit.records = recordCount;
        if (credit.sequence != UINT32_MAX)
            return Result::InvalidCredit;
        credit.sequence = nextSequence++;
        std::memcpy(credit.payload.data(), source,
                    recordCount * sizeof(InlineRetirementRecord));
        records += recordCount;
        return Result::Accepted;
    }

    Result markWriteIssued(uint8_t creditIndex)
    {
        if (!valid(creditIndex))
            return Result::InvalidCredit;
        Credit &credit = credits[creditIndex];
        if (!active || credit.generation != generation)
            return Result::StaleGeneration;
        if (credit.state != CreditState::Reserved)
            return Result::EarlyVisibility;
        credit.state = CreditState::WriteIssued;
        ++writeIssues;
        return Result::Accepted;
    }

    Result cancelReservation(uint8_t creditIndex)
    {
        if (!valid(creditIndex))
            return Result::InvalidCredit;
        Credit &credit = credits[creditIndex];
        if (!active || credit.generation != generation)
            return Result::StaleGeneration;
        if (credit.state != CreditState::Reserved)
            return Result::InvalidCredit;
        credit = Credit();
        return Result::Accepted;
    }

    Result markWriteResponse(uint8_t creditIndex,
                             uint64_t candidateGeneration,
                             uint32_t candidateSequence)
    {
        if (bulkMode || !valid(creditIndex))
            return Result::InvalidCredit;
        Credit &credit = credits[creditIndex];
        if (!active || candidateGeneration != generation ||
            credit.generation != generation)
            return Result::StaleGeneration;
        if (credit.sequence != candidateSequence)
            return Result::InvalidCredit;
        if (credit.state == CreditState::Visible ||
            credit.state == CreditState::CpuReadable)
            return Result::DuplicateResponse;
        if (credit.state != CreditState::WriteIssued)
            return Result::EarlyVisibility;
        credit.state = CreditState::Visible;
        ++writeResponses;
        return Result::Accepted;
    }

    Result markBulkWriteResponse(uint8_t creditIndex,
                                 uint64_t candidateGeneration,
                                 uint32_t candidateSequence,
                                 WaitOwner &ready, bool &release)
    {
        release = false;
        if (!bulkMode || !valid(creditIndex))
            return Result::InvalidCredit;
        Credit &credit = credits[creditIndex];
        if (!active || candidateGeneration != generation ||
            credit.generation != generation)
            return Result::StaleGeneration;
        if (credit.sequence != candidateSequence)
            return Result::InvalidCredit;
        if (credit.state != CreditState::WriteIssued)
            return credit.state == CreditState::Visible ||
                    credit.state == CreditState::CpuReadable
                ? Result::DuplicateResponse
                : Result::EarlyVisibility;
        ++writeResponses;
        credit.state = CreditState::Visible;
        advanceBulkResponsePrefix();
        release = releaseBulkWait(ready);
        return Result::Accepted;
    }

    Result requestBulkWait(const WaitOwner &owner, WaitOwner &ready)
    {
        if (!active || !bulkMode || countedMode)
            return Result::Inactive;
        if (!validOwner(owner) || owner.permit.generation != generation)
            return Result::StaleGeneration;
        const uint32_t expected_sequence =
            (waitRequests + 1) * BulkChunkLines - 1;
        if (waitRequests >= BulkChunks ||
            owner.permit.sequence != expected_sequence ||
            deferredWaits[0].occupied)
            return Result::DuplicateWait;
        nextAck = owner.permit.sequence + 1;
        ++waitRequests;
        if (bulkVisibilityReady()) {
            ready = owner;
            ++waitResponses;
            return Result::Accepted;
        }
        deferredWaits[0] = owner;
        deferredWaits[0].occupied = true;
        return Result::WaitPending;
    }

    Result closeBulk(WaitOwner &ready, bool &release)
    {
        release = false;
        if (!active || !bulkMode)
            return Result::Inactive;
        if (closed)
            return Result::Busy;
        closed = true;
        if (!countedMode &&
            nextSequence != InlineOperandPageFedABI::RetirementRingLines)
            return Result::Incomplete;
        release = releaseBulkWait(ready);
        return Result::Accepted;
    }

    Result finishBulk()
    {
        if (countedMode) {
            if (!active || !closed || nextAck != 2 ||
                writeIssues != nextSequence ||
                writeResponses != nextSequence || acks != nextSequence ||
                waitRequests != 1 || waitResponses != 1)
                return Result::Incomplete;
            for (const auto &credit : credits)
                if (credit.state != CreditState::Free)
                    return Result::Incomplete;
            for (const auto &wait : deferredWaits)
                if (wait.occupied)
                    return Result::Incomplete;
            active = false;
            closed = false;
            return Result::Accepted;
        }
        if (!active || !bulkMode || !closed || nextAck == 0 ||
            nextSequence != InlineOperandPageFedABI::RetirementRingLines ||
            nextAck != nextSequence || writeIssues != nextSequence ||
            writeResponses != nextSequence || waitRequests != BulkChunks ||
            waitResponses != BulkChunks || acks != nextSequence)
            return Result::Incomplete;
        for (const auto &credit : credits)
            if (credit.state != CreditState::Free)
                return Result::Incomplete;
        for (const auto &wait : deferredWaits)
            if (wait.occupied)
                return Result::Incomplete;
        active = false;
        closed = false;
        return Result::Accepted;
    }

    Result requestWait(const WaitOwner &owner, WaitOwner &ready)
    {
        if (!active || bulkMode)
            return Result::Inactive;
        if (!validOwner(owner) || owner.permit.generation != generation)
            return Result::StaleGeneration;
        if (owner.permit.sequence < nextAck)
            return Result::DuplicateWait;
        if (findDeferred(owner.permit.generation,
                         owner.permit.sequence) != nullptr)
            return Result::DuplicateWait;
        Credit *credit = findCredit(owner.permit.generation,
                                    owner.permit.sequence);
        if (credit != nullptr && credit->state == CreditState::CpuReadable)
            return Result::DuplicateWait;
        ++waitRequests;
        if (credit != nullptr && credit->state == CreditState::Visible) {
            grantReadPermit(*credit, owner, ready);
            return Result::Accepted;
        }
        for (auto &wait : deferredWaits) {
            if (wait.occupied)
                continue;
            wait = owner;
            wait.occupied = true;
            return Result::WaitPending;
        }
        --waitRequests;
        return Result::Full;
    }

    bool hasDeferredWait(uint64_t candidateGeneration,
                         uint32_t sequence) const
    {
        return findDeferred(candidateGeneration, sequence) != nullptr;
    }

    Result releaseDeferredWait(uint64_t candidateGeneration,
                               uint32_t sequence, uint64_t lineAddress,
                               WaitOwner &ready)
    {
        if (!active || candidateGeneration != generation)
            return Result::StaleGeneration;
        WaitOwner *wait = findDeferred(candidateGeneration, sequence);
        if (wait == nullptr)
            return Result::InvalidCredit;
        if (wait->permit.lineAddress != lineAddress)
            return Result::PermitMismatch;
        Credit *credit = findCredit(candidateGeneration, sequence);
        if (credit == nullptr || credit->state != CreditState::Visible)
            return Result::EarlyVisibility;
        grantReadPermit(*credit, *wait, ready);
        *wait = WaitOwner();
        return Result::Accepted;
    }

    Result acknowledge(const PermitIdentity &candidate)
    {
        if (!active || bulkMode)
            return Result::Inactive;
        if (candidate.generation != generation)
            return Result::StaleGeneration;
        if (candidate.sequence != nextAck)
            return Result::AckOrder;
        for (auto &credit : credits) {
            if (credit.generation != generation ||
                credit.sequence != candidate.sequence)
                continue;
            if (credit.state != CreditState::CpuReadable)
                return Result::EarlyVisibility;
            if (!samePermit(credit.permit, candidate))
                return Result::PermitMismatch;
            credit = Credit();
            ++nextAck;
            ++acks;
            return Result::Accepted;
        }
        return Result::InvalidCredit;
    }

    Result close()
    {
        if (!active || bulkMode)
            return Result::Inactive;
        closed = true;
        return Result::Accepted;
    }

    Result finish()
    {
        if (!active || bulkMode || !closed ||
            writeIssues != writeResponses ||
            writeResponses != waitRequests ||
            waitRequests != waitResponses || waitResponses != acks ||
            nextSequence != nextAck)
            return Result::Incomplete;
        for (const auto &credit : credits)
            if (credit.state != CreditState::Free)
                return Result::Incomplete;
        for (const auto &wait : deferredWaits)
            if (wait.occupied)
                return Result::Incomplete;
        active = false;
        closed = false;
        return Result::Accepted;
    }

    const Credit &credit(uint8_t index) const { return credits.at(index); }
    Credit &credit(uint8_t index) { return credits.at(index); }
    bool isActive() const { return active; }
    bool isClosed() const { return closed; }
    bool isBulkMode() const { return bulkMode; }
    bool isCountedMode() const { return countedMode; }
    uint64_t currentGeneration() const { return generation; }
    uint32_t recordCount() const { return records; }
    uint32_t issuedLines() const { return writeIssues; }
    uint32_t respondedLines() const { return writeResponses; }
    uint32_t waitedLines() const { return waitResponses; }
    uint32_t ackedLines() const { return bulkMode ? 0 : acks; }
    uint32_t consumedWindows() const
    { return countedMode && nextAck == 2 ? 1 : 0; }
    uint32_t nextAckSequence() const { return nextAck; }
    size_t creditHighWater() const { return highWater; }
    bool visible(uint64_t candidateGeneration, uint32_t sequence) const
    {
        if (!active || candidateGeneration != generation)
            return false;
        for (const auto &credit : credits) {
            if (credit.generation == generation &&
                credit.sequence == sequence)
                return credit.state == CreditState::Visible ||
                    credit.state == CreditState::CpuReadable;
        }
        return false;
    }
    bool cpuReadable(const PermitIdentity &candidate) const
    {
        if (!active || candidate.generation != generation)
            return false;
        for (const auto &credit : credits) {
            if (credit.generation == generation &&
                credit.sequence == candidate.sequence)
                return credit.state == CreditState::CpuReadable &&
                    samePermit(credit.permit, candidate);
        }
        return false;
    }
    size_t deferredWaitCount() const
    {
        size_t count = 0;
        for (const auto &wait : deferredWaits)
            count += wait.occupied;
        return count;
    }
    size_t freeCredits() const
    {
        size_t free = 0;
        for (const auto &credit : credits)
            free += credit.state == CreditState::Free;
        return free;
    }

    static constexpr size_t CreditPayloadBytes = Credits * LineBytes;
    static constexpr size_t PackerPayloadBytes = LineBytes;
    static constexpr size_t CreditControlBytes = Credits * 16;
    static constexpr size_t DeferredWaitControlBytes = Credits * 24;
    static constexpr size_t GlobalControlBytes = 32;
    static constexpr size_t BulkModeControlBytes = 1;
    static constexpr size_t CountedModeControlBytes = 1;
    static constexpr size_t IncrementalSramBytes =
        CreditPayloadBytes + PackerPayloadBytes + CreditControlBytes +
        DeferredWaitControlBytes + GlobalControlBytes + BulkModeControlBytes;
    static constexpr size_t CountedIncrementalSramBytes =
        IncrementalSramBytes + CountedModeControlBytes;

  private:
    bool valid(uint8_t index) const { return index < credits.size(); }

    static bool validOwner(const WaitOwner &owner)
    {
        return owner.packet != 0 && owner.occupied &&
            owner.permit.generation != 0 &&
            owner.permit.sequence != UINT32_MAX &&
            owner.permit.lineAddress != 0 &&
            owner.permit.core != UINT16_MAX &&
            owner.permit.port != UINT16_MAX &&
            owner.permit.maa != UINT16_MAX && owner.permit.region >= 0;
    }

    static bool samePermit(const PermitIdentity &lhs,
                           const PermitIdentity &rhs)
    {
        return lhs.generation == rhs.generation &&
            lhs.sequence == rhs.sequence &&
            lhs.lineAddress == rhs.lineAddress && lhs.core == rhs.core &&
            lhs.port == rhs.port && lhs.maa == rhs.maa &&
            lhs.region == rhs.region;
    }

    Credit *findCredit(uint64_t candidateGeneration, uint32_t sequence)
    {
        for (auto &credit : credits)
            if (credit.generation == candidateGeneration &&
                credit.sequence == sequence)
                return &credit;
        return nullptr;
    }

    const WaitOwner *findDeferred(uint64_t candidateGeneration,
                                  uint32_t sequence) const
    {
        for (const auto &wait : deferredWaits)
            if (wait.occupied &&
                wait.permit.generation == candidateGeneration &&
                wait.permit.sequence == sequence)
                return &wait;
        return nullptr;
    }

    WaitOwner *findDeferred(uint64_t candidateGeneration,
                            uint32_t sequence)
    {
        return const_cast<WaitOwner *>(
            static_cast<const InlineOperandRetirementState *>(this)->
                findDeferred(candidateGeneration, sequence));
    }

    void grantReadPermit(Credit &credit, const WaitOwner &owner,
                         WaitOwner &ready)
    {
        credit.permit = owner.permit;
        credit.state = CreditState::CpuReadable;
        ready = owner;
        ++waitResponses;
    }

    bool bulkVisibilityReady() const
    {
        if (countedMode)
            return active && closed && writeIssues == nextSequence &&
                writeResponses == nextSequence && acks == nextSequence &&
                freeCredits() == Credits;
        return active && bulkMode && nextAck != 0 && acks >= nextAck;
    }

    bool releaseBulkWait(WaitOwner &ready)
    {
        if (!bulkVisibilityReady() || !deferredWaits[0].occupied)
            return false;
        ready = deferredWaits[0];
        if (countedMode)
            deferredWaits[1] = ready;
        deferredWaits[0] = WaitOwner();
        ++waitResponses;
        return true;
    }

    void advanceBulkResponsePrefix()
    {
        while (true) {
            auto response = std::find_if(
                credits.begin(), credits.end(), [this](const Credit &credit) {
                    return credit.state == CreditState::Visible &&
                        credit.generation == generation &&
                        credit.sequence == acks;
                });
            if (response == credits.end())
                return;
            *response = Credit();
            ++acks;
        }
    }

    std::array<Credit, Credits> credits{};
    std::array<WaitOwner, Credits> deferredWaits{};
    uint64_t generation = 0;
    uint32_t nextSequence = 0;
    uint32_t nextAck = 0;
    uint32_t records = 0;
    uint32_t writeIssues = 0;
    uint32_t writeResponses = 0;
    uint32_t waitRequests = 0;
    uint32_t waitResponses = 0;
    uint32_t acks = 0;
    size_t highWater = 0;
    bool active = false;
    bool closed = false;
    bool bulkMode = false;
    bool countedMode = false;
};

static_assert(InlineOperandRetirementState::IncrementalSramBytes == 929);
static_assert(InlineOperandRetirementState::IncrementalSramBytes <= 1024);
static_assert(InlineOperandRetirementState::BulkChunkLines == 512);
static_assert(InlineOperandRetirementState::BulkChunks == 4);

} // namespace gem5::maa

#endif // __MEM_MAA_INLINE_OPERAND_RETIREMENT_HH__
