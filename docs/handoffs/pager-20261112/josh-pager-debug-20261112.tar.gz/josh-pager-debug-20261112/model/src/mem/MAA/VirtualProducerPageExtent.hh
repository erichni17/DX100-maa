#ifndef __MEM_MAA_VIRTUAL_PRODUCER_PAGE_EXTENT_HH__
#define __MEM_MAA_VIRTUAL_PRODUCER_PAGE_EXTENT_HH__

#include <array>
#include <cstddef>
#include <cstdint>

namespace gem5::maa
{

// One byte per completion token; Unknown cannot authorize token reuse.
class VirtualProducerPageExtent
{
  public:
    static constexpr uint8_t Unknown = 255;

    void reset() { pages = Unknown; }
    unsigned count() const { return pages; }

    bool
    bind(unsigned words, unsigned logical, unsigned physical,
         unsigned capacity)
    {
        if (!physical || !logical || words > logical || capacity >= Unknown)
            return false;
        const unsigned count = words / physical + (words % physical != 0);
        if (count > capacity || (pages != Unknown && pages != count))
            return false;
        pages = count;
        return true;
    }

    bool contains(unsigned page) const
    {
        return pages != Unknown && page < pages;
    }

    template <std::size_t N>
    bool
    complete(const std::array<bool, N> &ready) const
    {
        if (pages == Unknown || pages > N)
            return false;
        for (unsigned page = 0; page < pages; ++page) {
            if (!ready[page])
                return false;
        }
        return true;
    }

  private:
    uint8_t pages = Unknown;
};

static_assert(sizeof(VirtualProducerPageExtent) == 1);

} // namespace gem5::maa

#endif // __MEM_MAA_VIRTUAL_PRODUCER_PAGE_EXTENT_HH__
