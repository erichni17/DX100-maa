#ifndef UME_DEFERRED_OWNER_POOL_HH
#define UME_DEFERRED_OWNER_POOL_HH
#include <array>
#include <cstdint>
namespace gem5::maa {
template<class RequestRef>
class DeferredOwnerPool {
 enum class Phase { Empty, Waiting, Dispatched, Handoff };
 struct Cell { std::uintptr_t packet=0;RequestRef request{};std::uint64_t token=0;unsigned tile=0,port=0;Phase phase=Phase::Empty; };
 std::array<Cell,64> cells{};unsigned used=0,nextReady=0;
 static bool same(const RequestRef&a,const RequestRef&b){return a&&b&&a.get()==b.get()&&!a.owner_before(b)&&!b.owner_before(a);}
 public:
 struct Handoff { bool valid=true,tracked=false;std::uintptr_t packet=0;RequestRef request{};std::uint64_t token=0;unsigned port=0; };
 bool accept(std::uintptr_t p,const RequestRef&r,std::uint64_t token,unsigned tile,unsigned port){
  if(!p||!r||!token||tile>=32||port>=4||used==cells.size())return false;
  for(const auto &c:cells)if(c.phase!=Phase::Empty&&(c.packet==p||c.token==token||c.request.get()==r.get()))return false;
  for(auto &c:cells)if(c.phase==Phase::Empty){c={p,r,token,tile,port,Phase::Waiting};++used;return true;}
  return false;
 }
 template<class Ready,class Dispatch>void ready(Ready test,Dispatch dispatch){
  for(auto &c:cells)if(c.phase==Phase::Waiting&&test(c.tile)){c.phase=Phase::Dispatched;dispatch(c.packet,c.port);}
 }
 Handoff begin(std::uintptr_t p,const RequestRef&r,unsigned port){
  for(auto &c:cells)if(c.phase!=Phase::Empty&&c.packet==p){
   Handoff h{true,true,p,c.request,c.token,port};
   if(c.phase!=Phase::Dispatched||c.port!=port||!same(c.request,r)){h.valid=false;return h;}
   c.phase=Phase::Handoff;return h;
  }
  return {};
 }
 bool finish(const Handoff&h,bool accepted){
  if(!h.valid)return false;
  if(!h.tracked)return true;
  for(auto &c:cells)if(c.phase==Phase::Handoff&&c.packet==h.packet&&c.token==h.token&&same(c.request,h.request)&&c.port==h.port){
   if(accepted){c={};--used;}else c.phase=Phase::Dispatched;return true;
  }
  return false;
 }
 bool hasWaiting()const{for(const auto&c:cells)if(c.phase==Phase::Waiting)return true;return false;}
 template<class Ready,class Dispatch>bool readyOne(Ready test,Dispatch dispatch){
  for(unsigned n=0;n<cells.size();++n){unsigned i=(nextReady+n)%cells.size();auto&c=cells[i];
   if(c.phase==Phase::Waiting&&test(c.tile)){c.phase=Phase::Dispatched;nextReady=(i+1)%cells.size();dispatch(c.packet,c.port);return true;}
  }
  return false;
 }
 unsigned size()const{return used;}
};
}
#endif
