#include <cassert>
#include <cstdint>
#include <limits>

#include "../../../include/gem5/maa_logical_spd_cache_abi.hh"
#include "../../../include/gem5/maa_page_fed_soa_abi.hh"
#include "base/addr_range.hh"
#include "base/logging.hh"
#include "base/trace.hh"
#include "debug/MAAController.hh"
#include "debug/MAACpuPort.hh"
#include "debug/MAAVirtualTrace.hh"
#include "mem/MAA/ALU.hh"
#include "mem/MAA/CpuSpdAperture.hh"
#include "mem/MAA/FullRequestEnable.hh"
#include "mem/MAA/FusedP16ProductState.hh"
#include "mem/MAA/IF.hh"
#include "mem/MAA/IndirectAccess.hh"
#include "mem/MAA/Invalidator.hh"
#include "mem/MAA/MAA.hh"
#include "mem/MAA/RangeFuser.hh"
#include "mem/MAA/SPD.hh"
#include "mem/MAA/SoaJitSafety.hh"
#include "mem/MAA/SoaJitScalarBroadcast.hh"
#include "mem/MAA/StreamAccess.hh"
#include "mem/packet.hh"
#include "mem/packet_access.hh"
#include "mem/request.hh"
#include "params/MAA.hh"

#ifndef TRACING_ON
#define TRACING_ON 1
#endif

namespace gem5 {

namespace
{

void
requireFullyEnabledRequest(PacketPtr packet, unsigned cacheLineSize)
{
    const auto &request = packet->req;
    panic_if(!request || !request->hasPaddr() || !request->hasSize(),
             "SPD/MMIO request lacks physical span");
    const bool lineRead = packet->cmd == MemCmd::ReadSharedReq ||
                          packet->cmd == MemCmd::ReadExReq;
    panic_if(!maa::fullRequestEnabled(request->getByteEnable(),
                 request->hasPaddr(), request->hasSize(),
                 request->getPaddr(), request->getSize(),
                 packet->getAddr(), packet->getSize(), lineRead, cacheLineSize),
             "SPD/MMIO request has disabled bytes or malformed/overflowing span");
}

bool
isDroppableBoundaryPrefetch(PacketPtr pkt)
{
    // Queued hardware prefetches begin as HardPFReq packets with a zero-flag
    // Request.  Cache::createMissPacket converts a miss to ReadSharedReq while
    // reusing that Request, whose Prefetcher task ID is the surviving
    // provenance.  Only a complete cache-line byte-enable mask may take the
    // harmless error-response path.  Do not generalize this to exclusive or
    // software prefetches.
    return pkt->cmd == MemCmd::ReadSharedReq &&
        pkt->req->taskId() == context_switch_task_id::Prefetcher &&
        maa::CpuSpdAperture::allBytesEnabled(
            pkt->req->getByteEnable(), pkt->getSize());
}

} // anonymous namespace

void MAA::recvTimingSnoopResp(PacketPtr pkt) {
    /// print the packet
    DPRINTF(MAACpuPort, "%s: received %s\n", __func__, pkt->print());
    switch (pkt->cmd.toInt()) {
    case MemCmd::ReadExResp: {
        assert(pkt->getSize() == 64);
        for (int i = 0; i < 64; i += 4) {
            panic_if(pkt->req->getByteEnable()[i] == false, "Byte enable [%d] is not set for the read response\n", i);
        }
        AddressRangeType address_range = AddressRangeType(pkt->getAddr(), addrRanges);
        panic_if(address_range.isValid() == false, "Invalid address range: %s\n", address_range.print());
        assert(address_range.getType() == AddressRangeType::Type::SPD_DATA_CACHEABLE_RANGE);
        Addr offset = address_range.getOffset();
        int tile_id = offset / (num_tile_elements * sizeof(uint32_t));
        int element_id = offset % (num_tile_elements * sizeof(uint32_t));
        assert(element_id % sizeof(uint32_t) == 0);
        element_id /= sizeof(uint32_t);
        invalidator->recvData(tile_id, element_id, pkt->getPtr<uint8_t>());
        break;
    }
    default:
        assert(false);
    }
}
bool MAA::CpuSidePort::recvTimingSnoopResp(PacketPtr pkt) {
    assert(pkt->isResponse());
    /// print the packet
    DPRINTF(MAACpuPort, "%s: received %s\n", __func__, pkt->print());
    maa.recvTimingSnoopResp(pkt);
    outstandingCpuSidePackets--;
    if (is_blocked) {
        is_blocked = false;
        maa.invalidator->scheduleExecuteInstructionEvent();
    }
    pkt->deleteData();
    delete pkt;
    return true;
}

bool MAA::CpuSidePort::tryTiming(PacketPtr pkt) {
    /// print the packet
    DPRINTF(MAACpuPort, "%s: received %s\n", __func__, pkt->print());

    if (mustRetryTileRequest) {
        return false;
    }

    if (pkt->cmd == MemCmd::ReadExReq ||
        pkt->cmd == MemCmd::ReadSharedReq ||
        (maa.devicePaging() && pkt->cmd == MemCmd::WritebackDirty)) {
        AddressRangeType address_range =
            AddressRangeType(pkt->getAddr(), maa.addrRanges);
        if (address_range.isValid() &&
            address_range.getType() ==
                AddressRangeType::Type::SPD_DATA_CACHEABLE_RANGE) {
            const Addr offset = address_range.getOffset();
            const int tile_id =
                offset / (maa.num_tile_elements * sizeof(uint32_t));
            panic_if(maa.logicalTileReservedLane(tile_id) ||
                         maa.logicalCompletionLaneOwned(tile_id),
                     "Guest cacheable read references reserved/owned SPD "
                     "lane %d\n", tile_id);
            const int element = (offset % (maa.num_tile_elements * 4)) / 4;
            const bool is_read = pkt->cmd != MemCmd::WritebackDirty;
            if ((is_read && !maa.spd->getTileReady(tile_id)) ||
                (maa.devicePaging() &&
                 !maa.spd->ensurePage(tile_id, element, false))) {
                assert(retryTileID == -1);
                assert(!tileRequestRetryOutstanding);
                mustRetryTileRequest = true;
                retryTileID = tile_id;
                maa.stats.cpu_spd_data_read_deferrals++;
                DPRINTF(MAACpuPort,
                        "%s: deferring cacheable read for tile[%d]\n",
                        __func__, tile_id);
                return false;
            }
        }
    }
    return true;
}

void MAA::recvTimingReq(PacketPtr pkt, int core_id) {
    /// print the packet
    DPRINTF(MAACpuPort, "%s: received %s, cmd: %s, isMaskedWrite: %d, size: %d\n",
            __func__,
            pkt->print(),
            pkt->cmdString(),
            pkt->isMaskedWrite(),
            pkt->getSize());
    AddressRangeType address_range = AddressRangeType(pkt->getAddr(), addrRanges);
    DPRINTF(MAACpuPort, "%s: address range type: %s\n", __func__, address_range.print());
    requireFullyEnabledRequest(pkt, system->cacheLineSize());
    switch (pkt->cmd.toInt()) {
    case MemCmd::CleanEvict:
    case MemCmd::WritebackClean: {
        // The paging aperture is a terminal coherent destination on tol3bus.
        // Clean notifications previously terminated in the LLC. As at
        // AbstractMemory, they do not change authoritative data, map a page,
        // or generate a response. In particular, never copy an old clean
        // cache line into a newly produced SPD generation.
        panic_if(!devicePaging() || address_range.getType() !=
                     AddressRangeType::Type::SPD_DATA_CACHEABLE_RANGE ||
                     pkt->needsResponse(),
                 "Unexpected clean notification at SPD endpoint: %s",
                 pkt->print());
        pendingDelete.reset(pkt);
        break;
    }
    case MemCmd::WritebackDirty: {
        assert(pkt->isMaskedWrite() == false);
        switch (address_range.getType()) {
        case AddressRangeType::Type::SPD_DATA_CACHEABLE_RANGE: {
            Addr offset = address_range.getOffset();
            int tile_id = offset / (num_tile_elements * sizeof(uint32_t));
            panic_if(logicalTileReservedLane(tile_id) ||
                         logicalCompletionLaneOwned(tile_id),
                     "Guest cacheable write references reserved/owned SPD "
                     "lane %d\n", tile_id);
            panic_if(pkt->getSize() != 64,
                     "Invalid size for SPD data: %d\n", pkt->getSize());
            int element_id =
                (offset % (num_tile_elements * sizeof(uint32_t))) /
                sizeof(uint32_t);
            for (int i = 0; i < 64 / sizeof(uint32_t); i++) {
                uint32_t data = pkt->getPtr<uint32_t>()[i];
                DPRINTF(MAACpuPort,
                        "%s: TILE[%d][%d] = %u\n", __func__, tile_id,
                        element_id + i, data);
                spd->setData<uint32_t>(tile_id, element_id + i, data);
            }
            assert(pkt->needsResponse() == false);
            pendingDelete.reset(pkt);
            break;
        }
        default:
            panic_if(true, "%s: Error: Range(%s) and cmd(%s) is illegal. Packet: %s\n", __func__, address_range.print(), pkt->cmdString(), pkt->print());
            assert(false);
        }
        break;
    }
    case MemCmd::WriteReq: {
        bool respond_immediately = true;
        assert(pkt->isMaskedWrite() == false);
        switch (address_range.getType()) {
        case AddressRangeType::Type::SCALAR_RANGE: {
            panic_if(core_id != 0, "Scalar range is only for the core 0\n");
            Addr offset = address_range.getOffset();
            int element_id = offset % (num_regs * sizeof(uint32_t));
            assert(element_id % sizeof(uint32_t) == 0);
            element_id /= sizeof(uint32_t);
            panic_if(pkt->getSize() != 4 && pkt->getSize() != 8, "Invalid size for RF data: %d\n", pkt->getSize());
            RegisterPtr current_register = new Register();
            current_register->size = pkt->getSize();
            current_register->register_id = element_id;
            if (my_RID_to_core_id.find(pkt->requestorId()) == my_RID_to_core_id.end()) {
                int num_received_cores = my_RID_to_core_id.size();
                panic_if(num_received_cores == num_cores, "received more than %d instructions\n", num_cores);
                my_RID_to_core_id[pkt->requestorId()] = num_received_cores;
                num_received_cores++;
            }
            current_register->core_id = my_RID_to_core_id[pkt->requestorId()];
            current_register->maa_id = current_register->core_id % num_maas;
            if (pkt->getSize() == 4) {
                uint32_t data_UINT32 = pkt->getPtr<uint32_t>()[0];
                int32_t data_INT32 = pkt->getPtr<int32_t>()[0];
                float data_FLOAT = pkt->getPtr<float>()[0];
                DPRINTF(MAACpuPort, "%s: REG[%d] = %u/%d/%f\n", __func__, element_id, data_UINT32, data_INT32, data_FLOAT);
                current_register->data_UINT32 = data_UINT32;
                // rf->setData<uint32_t>(element_id, data_UINT32);
            } else {
                uint64_t data_UINT64 = pkt->getPtr<uint64_t>()[0];
                int64_t data_INT64 = pkt->getPtr<int64_t>()[0];
                double data_DOUBLE = pkt->getPtr<double>()[0];
                DPRINTF(MAACpuPort, "%s: REG[%d] = %lu/%ld/%lf\n", __func__, element_id, data_UINT64, data_INT64, data_DOUBLE);
                current_register->data_UINT64 = data_UINT64;
                // rf->setData<uint64_t>(element_id, data_UINT64);
            }
            my_registers.push_back(current_register);
            my_register_pkts.push_back(pkt);
            assert(pkt->needsResponse());
            respond_immediately = false;
            scheduleDispatchRegisterEvent();
            break;
        }
        case AddressRangeType::Type::INSTRUCTION_RANGE: {
            panic_if(core_id != 0, "Instruction range is only for the core 0\n");
            Addr offset = address_range.getOffset();
            int element_id = offset % (num_instructions_total * sizeof(uint64_t));
            assert(element_id % sizeof(uint64_t) == 0);
            element_id /= sizeof(uint64_t);
            uint64_t data = pkt->getPtr<uint64_t>()[0];
            DPRINTF(MAACpuPort, "%s: IF[%d] = %ld\n", __func__, element_id, data);
            if (element_id == 7) {
                maa::VirtualCpuConsumerABI::Command cpu_consumer;
                if (maa::VirtualCpuConsumerABI::decode(data, cpu_consumer)) {
                    panic_if(!virtual_strict_two_phase,
                             "Strict CPU-consumer command is disabled\n");
                    const auto core = my_RID_to_core_id.find(
                        pkt->requestorId());
                    panic_if(core == my_RID_to_core_id.end(),
                             "CPU-consumer command arrived before its "
                             "producer established requestor identity\n");
                    panic_if(core->second < 0 || core->second >= num_cores,
                             "CPU-consumer command has invalid requester "
                             "core %d\n", core->second);
                    if (cpu_consumer.action ==
                        maa::VirtualCpuConsumerABI::Action::Begin) {
                        beginStrictTwoPhaseCpuConsumer(
                            core->second, cpu_consumer.token,
                            cpu_consumer.generation, curTick());
                    } else {
                        completeStrictTwoPhaseCpuConsumer(
                            core->second, cpu_consumer.token,
                            cpu_consumer.generation, curTick());
                    }
                    pkt->makeTimingResponse();
                    const Tick old_header_delay = pkt->headerDelay;
                    pkt->headerDelay = pkt->payloadDelay = 0;
                    cpuSidePorts[core_id]->schedTimingResp(
                        pkt, getClockEdge(Cycles(1)) + old_header_delay);
                    respond_immediately = false;
                    break;
                }
                panic_if(!page_fed_soa_jit,
                         "Page-fed command doorbell is disabled\n");
                maa::InlineOperandPageFedABI::Command inline_command;
                if (maa::InlineOperandPageFedABI::decode(
                        data, inline_command)) {
                    panic_if(!inline_operand_page_fed_rmw,
                             "Inline-operand page-fed command is disabled\n");
                    const auto core = my_RID_to_core_id.find(
                        pkt->requestorId());
                    panic_if(core == my_RID_to_core_id.end(),
                             "Inline page-fed command arrived before its "
                             "descriptor established requestor identity\n");
                    panic_if(core->second < 0 || core->second >= num_cores ||
                                 core_id < 0 ||
                                 core_id >=
                                     static_cast<int>(cpuSidePorts.size()),
                             "Inline page-fed command has invalid requester "
                             "core/port %d/%d\n", core->second, core_id);
                    const uint16_t requester_core = core->second;
                    const uint16_t requester_maa =
                        requester_core % num_maas;
                    const uint16_t requester_port = core_id;
                    IndirectAccessUnit *owner = nullptr;
                    for (unsigned int unit = 0;
                         unit < num_indirect_units_total; ++unit) {
                        if (!indirectAccessUnits[unit].
                                inlineOperandActiveGeneration(
                                    inline_command.generation) ||
                            !indirectAccessUnits[unit].
                                inlineOperandOwnedByMaa(requester_maa))
                            continue;
                        panic_if(owner != nullptr,
                                 "Core %d owns duplicate inline page-fed "
                                 "contexts\n", core->second);
                        owner = &indirectAccessUnits[unit];
                    }
                    panic_if(owner == nullptr,
                             "Core %d inline page-fed command has no active "
                             "context\n", core->second);
                    Cycles latency(1);
                    if (inline_command.action ==
                        maa::InlineOperandPageFedABI::Action::AdmitPair) {
                        latency = owner->admitPageFedSoaJitIndexValuePage(
                            inline_command.generation, inline_command.page,
                            inline_command.indexTile,
                            inline_command.valueTile);
                    } else if (inline_command.action ==
                               maa::InlineOperandPageFedABI::Action::Close) {
                        latency = owner->closePageFedSoaJit(
                            inline_command.generation);
                    } else if (inline_command.action ==
                               maa::InlineOperandPageFedABI::Action::
                                   WaitVisible) {
                        bool deferred = false;
                        maa::InlineOperandRetirementState::WaitOwner ready;
                        latency = owner->waitInlineRetirementLine(
                            pkt, requester_core, requester_maa,
                            requester_port, inline_command.generation,
                            inline_command.retirementLine, deferred, ready);
                        respond_immediately = false;
                        if (!deferred)
                            releaseInlineRetirementWait(ready, latency);
                        break;
                    } else {
                        panic_if(inline_command.action !=
                                     maa::InlineOperandPageFedABI::Action::
                                         ConsumedAck,
                                 "Unsupported inline retirement action\n");
                        latency = owner->ackInlineRetirementLine(
                            requester_core, requester_maa, requester_port,
                            inline_command.generation,
                            inline_command.retirementLine);
                    }
                    pkt->makeTimingResponse();
                    const Tick old_header_delay = pkt->headerDelay;
                    pkt->headerDelay = pkt->payloadDelay = 0;
                    cpuSidePorts[core_id]->schedTimingResp(
                        pkt, getClockEdge(latency) + old_header_delay);
                    respond_immediately = false;
                    break;
                }
                maa::PageFedSoaJitABI::Command command;
                panic_if(!maa::PageFedSoaJitABI::decode(data, command),
                         "Malformed page-fed command word 0x%016lx\n",
                         data);
                const auto core = my_RID_to_core_id.find(
                    pkt->requestorId());
                panic_if(core == my_RID_to_core_id.end(),
                         "Page-fed command arrived before its descriptor "
                         "established requestor identity\n");
                IndirectAccessUnit *owner = nullptr;
                for (unsigned int unit = 0;
                     unit < num_indirect_units_total; ++unit) {
                    if (!indirectAccessUnits[unit].pageFedActiveForCore(
                            core->second))
                        continue;
                    panic_if(owner != nullptr,
                             "Core %d owns duplicate page-fed contexts\n",
                             core->second);
                    owner = &indirectAccessUnits[unit];
                }
                panic_if(owner == nullptr,
                         "Core %d page-fed command has no active context; "
                         "open must reach Fill before page admission\n",
                         core->second);
                const Cycles latency =
                    command.action ==
                            maa::PageFedSoaJitABI::Action::Admit
                        ? owner->admitPageFedSoaJitIndexPage(
                              command.generation, command.page,
                              command.tile)
                        : owner->closePageFedSoaJit(
                              command.generation);
                pkt->makeTimingResponse();
                const Tick old_header_delay = pkt->headerDelay;
                pkt->headerDelay = pkt->payloadDelay = 0;
                cpuSidePorts[core_id]->schedTimingResp(
                    pkt, getClockEdge(latency) + old_header_delay);
                respond_immediately = false;
                break;
            }
            InstructionPtr current_instruction;
            int instruction_id = -1;
            for (int i = 0; i < my_instruction_RIDs.size(); i++) {
                if (my_instruction_RIDs[i] == pkt->requestorId()) {
                    panic_if(instruction_id != -1, "Received multiple instructions from the same requestor\n");
                    panic_if(my_instruction_recvs[i], "Received new instruction after unissued instruction!\n");
                    current_instruction = my_instructions[i];
                    instruction_id = i;
                    my_instruction_pkts[i] = pkt;
                }
            }
            if (instruction_id == -1) {
                current_instruction = new Instruction();
                my_instruction_pkts.push_back(pkt);
                my_instruction_RIDs.push_back(pkt->requestorId());
                my_instruction_recvs.push_back(false);
                if (my_RID_to_core_id.find(pkt->requestorId()) == my_RID_to_core_id.end()) {
                    int num_received_cores = my_RID_to_core_id.size();
                    panic_if(num_received_cores == num_cores, "received more than %d instructions\n", num_cores);
                    my_RID_to_core_id[pkt->requestorId()] = num_received_cores;
                    num_received_cores++;
                }
                current_instruction->core_id = my_RID_to_core_id[pkt->requestorId()];
                current_instruction->maa_id = current_instruction->core_id % num_maas;
                my_instructions.push_back(current_instruction);
            }
#define NA_UINT8 0xFF
            switch (element_id) {
            case 0: {
                panic_if(instruction_id != -1, "Received new instruction[0] after incomplete instruction!\n");
                const auto logical_header =
                    maa::LogicalSPDCacheABI::decodeWord0(data);
                panic_if(
                    logical_header.kind ==
                        maa::LogicalSPDCacheABI::HeaderKind::Unsupported,
                    "Unsupported logical high-byte encoding in instruction "
                    "word 0: 0x%016lx\n", data);
                current_instruction->dst2SpdID =
                    (data & NA_UINT8) == NA_UINT8 ? -1 : (data & NA_UINT8);
                data = data >> 8;
                const uint8_t raw_dst1 = data & NA_UINT8;
                current_instruction->soaJitOldResult =
                    raw_dst1 == SoaJitSafety::OldResultModeTag;
                current_instruction->soaJitPageFed =
                    raw_dst1 == maa::PageFedSoaJitABI::ModeTag;
                current_instruction->soaJitInlineOperand =
                    raw_dst1 == maa::InlineOperandPageFedABI::ModeTag;
                current_instruction->dst1SpdID =
                    (raw_dst1 == NA_UINT8 ||
                     current_instruction->soaJitOldResult ||
                     current_instruction->soaJitPageFed ||
                     current_instruction->soaJitInlineOperand)
                        ? -1 : raw_dst1;
                data = data >> 8;
                current_instruction->optype = (data & NA_UINT8) == NA_UINT8 ? Instruction::OPType::MAX : static_cast<Instruction::OPType>(data & NA_UINT8);
                data = data >> 8;
                current_instruction->datatype = (data & NA_UINT8) == NA_UINT8 ? Instruction::DataType::MAX : static_cast<Instruction::DataType>(data & NA_UINT8);
                assert(current_instruction->datatype != Instruction::DataType::MAX);
                data = data >> 8;
                current_instruction->opcode = (data & NA_UINT8) == NA_UINT8 ? Instruction::OpcodeType::MAX : static_cast<Instruction::OpcodeType>(data & NA_UINT8);
                assert(current_instruction->opcode != Instruction::OpcodeType::MAX);
                if (current_instruction->opcode ==
                    Instruction::OpcodeType::INDIR_LD_VIRTUAL_INDEX) {
                    panic_if(
                        current_instruction->optype !=
                                Instruction::OPType::MAX &&
                            !current_instruction->
                                 isFusedP16ProductCandidate(),
                        "INDIR_LD_VIRTUAL_INDEX accepts only legacy NA or "
                        "the guarded FP32/MUL product form\n");
                }
                panic_if(current_instruction->soaJitOldResult &&
                             current_instruction->opcode !=
                                 Instruction::OpcodeType::INDIR_RMW_VECTOR &&
                             current_instruction->opcode !=
                                 Instruction::OpcodeType::INDIR_RMW_SCALAR &&
                             current_instruction->opcode !=
                                 Instruction::OpcodeType::INDIR_ST_VECTOR &&
                             current_instruction->opcode !=
                                 Instruction::OpcodeType::INDIR_ST_SCALAR,
                         "Old-result tag requires guarded vector/scalar RMW "
                         "or assignment\n");
                panic_if(current_instruction->soaJitPageFed &&
                             current_instruction->opcode !=
                                 Instruction::OpcodeType::INDIR_RMW_VECTOR,
                         "Page-fed mode tag is only valid for guarded "
                         "INDIR_RMW_VECTOR\n");
                panic_if(current_instruction->soaJitInlineOperand &&
                             current_instruction->opcode !=
                                 Instruction::OpcodeType::INDIR_RMW_VECTOR,
                         "Inline-operand mode tag is only valid for guarded "
                         "INDIR_RMW_VECTOR\n");
                if (logical_header.kind ==
                    maa::LogicalSPDCacheABI::HeaderKind::LogicalALUScalar) {
                    panic_if(
                        current_instruction->opcode !=
                            Instruction::OpcodeType::ALU_SCALAR,
                        "Logical high-byte operands are only supported for "
                        "ALU_SCALAR, got opcode %d\n",
                        static_cast<int>(current_instruction->opcode));
                    current_instruction->src1LogicalID =
                        logical_header.src1LogicalID;
                    current_instruction->src2LogicalID =
                        logical_header.src2LogicalID;
                    current_instruction->dst1LogicalID =
                        logical_header.dst1LogicalID;
                } else if (
                    logical_header.kind == maa::LogicalSPDCacheABI::
                                               HeaderKind::LogicalALUVector) {
                    panic_if(
                        current_instruction->opcode !=
                            Instruction::OpcodeType::ALU_VECTOR,
                        "Logical high-byte operands are only supported for "
                        "ALU_SCALAR or ALU_VECTOR, got opcode %d\n",
                        static_cast<int>(current_instruction->opcode));
                    current_instruction->src1LogicalID =
                        logical_header.src1LogicalID;
                    current_instruction->src2LogicalID =
                        logical_header.src2LogicalID;
                    current_instruction->dst1LogicalID =
                        logical_header.dst1LogicalID;
                } else if (
                    logical_header.kind ==
                        maa::LogicalSPDCacheABI::HeaderKind::
                            LogicalStreamLoad ||
                    logical_header.kind ==
                        maa::LogicalSPDCacheABI::HeaderKind::
                            LogicalStreamStore) {
                    const bool is_load = logical_header.kind ==
                        maa::LogicalSPDCacheABI::HeaderKind::LogicalStreamLoad;
                    panic_if(
                        current_instruction->opcode !=
                            (is_load ? Instruction::OpcodeType::STREAM_LD :
                                       Instruction::OpcodeType::STREAM_ST),
                        "Logical stream high-byte operands do not match "
                        "STREAM_LD/STREAM_ST opcode %d\n",
                        static_cast<int>(current_instruction->opcode));
                    current_instruction->src1LogicalID =
                        logical_header.src1LogicalID;
                    current_instruction->src2LogicalID =
                        logical_header.src2LogicalID;
                    current_instruction->dst1LogicalID =
                        logical_header.dst1LogicalID;
                    current_instruction->logicalCompletionSpdID =
                        current_instruction->dst1SpdID;
                    current_instruction->dst1SpdID = -1;
                }
                if (current_instruction->opcode ==
                        Instruction::OpcodeType::STREAM_LD ||
                    current_instruction->opcode ==
                        Instruction::OpcodeType::STREAM_PREFETCH ||
                    current_instruction->opcode ==
                        Instruction::OpcodeType::INDIR_LD_VIRTUAL ||
                    current_instruction->opcode ==
                        Instruction::OpcodeType::INDIR_LD_VIRTUAL_INDEX ||
                    current_instruction->opcode ==
                        Instruction::OpcodeType::INDIR_LD_INDEX ||
                    current_instruction->opcode ==
                        Instruction::OpcodeType::INDIR_LD_SPD_STREAM ||
                    current_instruction->opcode ==
                        Instruction::OpcodeType::VIRTUAL_TILE_ALU_SCALAR ||
                    current_instruction->opcode ==
                        Instruction::OpcodeType::INDIR_LD) {
                    current_instruction->accessType =
                        Instruction::AccessType::READ;
                } else if (
                    current_instruction->opcode ==
                            Instruction::OpcodeType::STREAM_ST ||
                        current_instruction->opcode ==
                            Instruction::OpcodeType::INDIR_ST_SCALAR ||
                        current_instruction->opcode ==
                            Instruction::OpcodeType::INDIR_ST_VECTOR ||
                        current_instruction->opcode ==
                            Instruction::OpcodeType::INDIR_RMW_SCALAR ||
                        current_instruction->opcode ==
                            Instruction::OpcodeType::INDIR_RMW_VECTOR) {
                    current_instruction->accessType =
                        Instruction::AccessType::WRITE;
                } else {
                    current_instruction->accessType = Instruction::AccessType::COMPUTE;
                }
                break;
            }
            case 1: {
                panic_if(instruction_id == -1, "Received new instruction[1] before insturction[0]!\n");
                current_instruction->condSpdID = (data & NA_UINT8) == NA_UINT8 ? -1 : (data & NA_UINT8);
                data = data >> 8;
                current_instruction->src3RegID = (data & NA_UINT8) == NA_UINT8 ? -1 : (data & NA_UINT8);
                data = data >> 8;
                current_instruction->src2RegID = (data & NA_UINT8) == NA_UINT8 ? -1 : (data & NA_UINT8);
                data = data >> 8;
                current_instruction->src1RegID = (data & NA_UINT8) == NA_UINT8 ? -1 : (data & NA_UINT8);
                data = data >> 8;
                current_instruction->dst2RegID = (data & NA_UINT8) == NA_UINT8 ? -1 : (data & NA_UINT8);
                data = data >> 8;
                current_instruction->dst1RegID = (data & NA_UINT8) == NA_UINT8 ? -1 : (data & NA_UINT8);
                data = data >> 8;
                current_instruction->src2SpdID = (data & NA_UINT8) == NA_UINT8 ? -1 : (data & NA_UINT8);
                data = data >> 8;
                current_instruction->src1SpdID = (data & NA_UINT8) == NA_UINT8 ? -1 : (data & NA_UINT8);
                data = data >> 8;
                break;
            }
            case 2: {
                panic_if(instruction_id == -1, "Received new instruction[2] before insturction[0]!\n");
                current_instruction->state = Instruction::Status::Idle;
                current_instruction->CID = pkt->req->contextId();
                current_instruction->PC = pkt->req->getPC();
                if (current_instruction->isLogicalALUScalar() ||
                    current_instruction->isLogicalALUVector()) {
                    panic_if(
                        data != maa::LogicalSPDCacheABI::NoAddress,
                        "Logical ALU operand word 2 must use the no-address "
                        "sentinel, got 0x%016lx\n", data);
                    break;
                }
                if (current_instruction->isLogicalStream()) {
                    maa::LogicalSPDCacheABI::StreamOperandShape shape;
                    shape.datatype = static_cast<uint8_t>(
                        current_instruction->datatype);
                    shape.src1LogicalID = current_instruction->src1LogicalID;
                    shape.src2LogicalID = current_instruction->src2LogicalID;
                    shape.dst1LogicalID = current_instruction->dst1LogicalID;
                    shape.src1SpdID = current_instruction->src1SpdID;
                    shape.src2SpdID = current_instruction->src2SpdID;
                    shape.dst1SpdID = current_instruction->dst1SpdID;
                    shape.dst2SpdID = current_instruction->dst2SpdID;
                    shape.completionSpdID =
                        current_instruction->logicalCompletionSpdID;
                    shape.src1RegID = current_instruction->src1RegID;
                    shape.src2RegID = current_instruction->src2RegID;
                    shape.src3RegID = current_instruction->src3RegID;
                    shape.dst1RegID = current_instruction->dst1RegID;
                    shape.dst2RegID = current_instruction->dst2RegID;
                    shape.condSpdID = current_instruction->condSpdID;
                    shape.backingAddr = data;
                    const auto validation = current_instruction->
                        isLogicalStreamLoad() ?
                        maa::LogicalSPDCacheABI::validateLogicalStreamLoad(
                            shape, static_cast<uint8_t>(
                                current_instruction->opcode)) :
                        maa::LogicalSPDCacheABI::validateLogicalStreamStore(
                            shape, static_cast<uint8_t>(
                                current_instruction->opcode));
                    panic_if(validation != maa::LogicalSPDCacheABI::
                                               StreamValidation::Valid,
                             "Rejected logical STREAM ABI shape (%d) before "
                             "controller state mutation\n",
                             static_cast<int>(validation));
                    panic_if(shape.completionSpdID < 0 ||
                                 shape.completionSpdID >=
                                     static_cast<int>(num_tiles),
                             "Rejected logical STREAM completion identity "
                             "before controller state mutation\n");
                    const int range = getAddrRegion(data);
                    panic_if(range < 0,
                             "Logical STREAM backing address 0x%lx is not "
                             "in a registered memory region\n", data);
                    const auto span_validation =
                        maa::LogicalSPDCacheABI::validateBackingSpan(
                            data, shape.datatype, addrRegions[range].first,
                            addrRegions[range].second);
                    panic_if(span_validation !=
                                 maa::LogicalSPDCacheABI::
                                     DestinationValidation::Valid,
                             "Rejected logical STREAM backing span before "
                             "controller state mutation\n");
                    if (current_instruction->isLogicalStreamLoad()) {
                        current_instruction->logicalSourceBackingAddr = data;
                        current_instruction->logicalSourceAddrRangeID = range;
                        current_instruction->logicalSourceMinAddr =
                            addrRegions[range].first;
                        current_instruction->logicalSourceMaxAddr =
                            addrRegions[range].second;
                    } else {
                        current_instruction->logicalDestinationBackingAddr =
                            data;
                        current_instruction->logicalDestinationAddrRangeID =
                            range;
                        current_instruction->logicalDestinationMinAddr =
                            addrRegions[range].first;
                        current_instruction->logicalDestinationMaxAddr =
                            addrRegions[range].second;
                    }
                    panic_if(!logicalTilePageSchedulerEnabled(),
                             "Logical STREAM ABI is disabled unless the "
                             "logical tile page scheduler is enabled\n");
                    current_instruction->baseAddr = data;
                    current_instruction->addrRangeID = range;
                    current_instruction->minAddr = addrRegions[range].first;
                    current_instruction->maxAddr = addrRegions[range].second;
                    my_instruction_recvs[instruction_id] = true;
                    DPRINTF(MAAController,
                            "%s: %s received for logical page scheduling\n",
                            __func__, current_instruction->print());
                    respond_immediately = false;
                    scheduleDispatchInstructionEvent();
                    break;
                }
                current_instruction->baseAddr = data;
                if (current_instruction->isFusedP16ProductCandidate()) {
                    panic_if(
                        !current_instruction->hasValidFusedP16ProductShape() ||
                            current_instruction->src1RegID >= num_regs ||
                            current_instruction->src2RegID >= num_regs ||
                            current_instruction->src3RegID >= num_regs ||
                            current_instruction->dst1SpdID < 0 ||
                            current_instruction->dst1SpdID >=
                                static_cast<int>(num_tiles),
                        "Rejected malformed fused-p16 product shape before "
                        "address-word dispatch\n");
                }
                panic_if(current_instruction->soaJitOldResult &&
                             !current_instruction->hasSoaJitOldResult(),
                         "Old-result mode requires a guarded vector/store "
                         "or INT32 scalar ADD shape, not native SPD inputs\n");
                if (current_instruction->isSoaJitRmw()) {
                    panic_if(
                        !current_instruction->hasValidSoaJitRmwShape(),
                        "Rejected SoA/JIT RMW ABI shape: dst1 must be the "
                        "no-result sentinel or old-result mode tag, "
                        "dst2(completion) must be present, register "
                        "destinations must be absent, and ordinary modes "
                        "must carry all three range registers\n");
                    panic_if(
                        (!current_instruction->isSoaJitPageFedRmw() &&
                         (current_instruction->src1RegID >= num_regs ||
                          current_instruction->src2RegID >= num_regs ||
                          current_instruction->src3RegID >= num_regs)) ||
                            (!current_instruction->
                                  isSoaJitInlineOperandRmw() &&
                             (current_instruction->dst2SpdID < 0 ||
                              current_instruction->dst2SpdID >=
                                  static_cast<int>(num_tiles))),
                        "Rejected SoA/JIT RMW register or completion-token "
                        "range before address-word dispatch\n");
                    const bool wide_vector_store =
                        current_instruction->opcode ==
                            Instruction::OpcodeType::INDIR_ST_VECTOR &&
                        (current_instruction->datatype ==
                             Instruction::DataType::UINT64_TYPE ||
                         current_instruction->datatype ==
                             Instruction::DataType::INT64_TYPE ||
                         current_instruction->datatype ==
                             Instruction::DataType::FLOAT64_TYPE);
                    panic_if(
                        current_instruction->isSoaJitStore() &&
                            (current_instruction->soaJitPageFed ||
                             current_instruction->soaJitInlineOperand ||
                             current_instruction->optype !=
                                 Instruction::OPType::MAX ||
                             (current_instruction->datatype !=
                                  Instruction::DataType::INT32_TYPE &&
                              !wide_vector_store)),
                        "SoA/JIT store requires INT32 or vector64 and NA "
                        "optype (no arithmetic substitution)\n");
                    panic_if(
                        !current_instruction->isSoaJitStore() &&
                        current_instruction->optype !=
                                Instruction::OPType::ADD_OP &&
                            current_instruction->optype !=
                                Instruction::OPType::MIN_OP &&
                            current_instruction->optype !=
                                Instruction::OPType::MAX_OP,
                        "SoA/JIT RMW supports only ADD/MIN/MAX\n");
                    panic_if(
                        current_instruction->isSoaJitPageFedRmw() &&
                            (!page_fed_soa_jit ||
                             current_instruction->datatype !=
                                 Instruction::DataType::FLOAT32_TYPE),
                        "Page-fed SoA/JIT requires the default-off enable "
                        "and FP32 vector operands\n");
                    panic_if(
                        current_instruction->isSoaJitInlineOperandRmw() &&
                            (!inline_operand_page_fed_rmw ||
                             current_instruction->optype !=
                                 Instruction::OPType::MIN_OP),
                        "Inline-operand prototype requires its default-off "
                        "selector and typed MIN\n");
                }
                if (current_instruction->accessType !=
                    Instruction::AccessType::COMPUTE) {
                    current_instruction->addrRangeID =
                        getAddrRegion(current_instruction->baseAddr);
                    panic_if(current_instruction->addrRangeID < 0,
                             "Base address 0x%lx is not in a registered "
                             "memory region\n",
                             current_instruction->baseAddr);
                    current_instruction->minAddr =
                        addrRegions[current_instruction->addrRangeID].first;
                    current_instruction->maxAddr =
                        addrRegions[current_instruction->addrRangeID].second;
                }
                if (current_instruction->opcode ==
                        Instruction::OpcodeType::INDIR_LD_VIRTUAL ||
                    current_instruction->opcode ==
                        Instruction::OpcodeType::INDIR_LD_VIRTUAL_INDEX ||
                    current_instruction->opcode ==
                        Instruction::OpcodeType::INDIR_LD_INDEX ||
                    current_instruction->opcode ==
                        Instruction::OpcodeType::INDIR_LD_SPD_STREAM ||
                    current_instruction->opcode ==
                        Instruction::OpcodeType::VIRTUAL_TILE_ALU_SCALAR)
                    break;
                if (current_instruction->isSoaJitRmw())
                    break;
                my_instruction_recvs[instruction_id] = true;
                DPRINTF(MAAController, "%s: %s received!\n", __func__, current_instruction->print());
                respond_immediately = false;
                scheduleDispatchInstructionEvent();
                break;
            }
            case 3: {
                panic_if(instruction_id == -1,
                         "Received backing address before instruction header!\n");
                panic_if(
                    current_instruction->opcode !=
                            Instruction::OpcodeType::INDIR_LD_VIRTUAL &&
                        current_instruction->opcode !=
                            Instruction::OpcodeType::INDIR_LD_VIRTUAL_INDEX &&
                        current_instruction->opcode !=
                            Instruction::OpcodeType::INDIR_LD_SPD_STREAM &&
                        current_instruction->opcode !=
                            Instruction::OpcodeType::VIRTUAL_TILE_ALU_SCALAR &&
                        !current_instruction->isSoaJitRmw() &&
                        !current_instruction->isLogicalALUScalar() &&
                        !current_instruction->isLogicalALUVector(),
                    "Backing address is only valid for virtual or fused "
                    "indirect loads or logical ALU_SCALAR!\n");
                if (current_instruction->isLogicalALUScalar()) {
                    current_instruction->backingAddr = data;
                    current_instruction->backingAddrRangeID =
                        getAddrRegion(data);
                    panic_if(current_instruction->backingAddrRangeID < 0,
                             "Logical destination backing address 0x%lx is "
                             "not in a registered memory region\n", data);
                    current_instruction->backingMinAddr = addrRegions[
                        current_instruction->backingAddrRangeID].first;
                    current_instruction->backingMaxAddr = addrRegions[
                        current_instruction->backingAddrRangeID].second;
                    break;
                }
                if (current_instruction->isLogicalALUVector()) {
                    // Staged only: this incomplete instruction is never
                    // admitted or dispatched until word five validates it.
                    current_instruction->logicalDestinationBackingAddr = data;
                    break;
                }
                if (current_instruction->isSoaJitScalarRmw()) {
                    panic_if(
                        data > static_cast<uint64_t>(
                                   std::numeric_limits<int16_t>::max()),
                        "Rejected SoA/JIT scalar register encoding 0x%lx\n",
                        data);
                    current_instruction->soaJitScalarRegID =
                        static_cast<int16_t>(data);
                    const auto validation =
                        SoaJitScalarBroadcast::validateRegisters(
                            current_instruction->soaJitScalarRegID,
                            current_instruction->WordSize() /
                                sizeof(uint32_t),
                            current_instruction->src1RegID,
                            current_instruction->src2RegID,
                            current_instruction->src3RegID, num_regs);
                    panic_if(
                        validation !=
                            SoaJitScalarBroadcast::Status::Accepted ||
                            !SoaJitScalarBroadcast::datatypeMatchesWidth(
                                static_cast<uint8_t>(
                                    current_instruction->datatype),
                                current_instruction->WordSize()),
                        "Rejected SoA/JIT scalar width/type/register alias "
                        "shape (%d) before timed request dispatch\n",
                        static_cast<int>(validation));
                    break;
                }
                current_instruction->backingAddr = data;
                current_instruction->backingAddrRangeID = getAddrRegion(data);
                panic_if(current_instruction->backingAddrRangeID < 0,
                         "Backing address 0x%lx is not in a registered "
                         "memory region\n",
                         data);
                current_instruction->backingMinAddr =
                    addrRegions[current_instruction->backingAddrRangeID].first;
                current_instruction->backingMaxAddr = addrRegions[
                    current_instruction->backingAddrRangeID].second;
                if (current_instruction->isSoaJitInlineOperandRmw()) {
                    panic_if(
                        (data & 63) != 0 ||
                            current_instruction->backingMaxAddr - data <
                                maa::InlineOperandPageFedABI::
                                    RetirementRingBytes,
                        "Inline retirement ring must be 64-byte aligned and "
                        "provide exactly bounded 32-KiB backing\n");
                }
                if (current_instruction->isSoaJitRmw())
                    break;
                if (current_instruction->opcode ==
                        Instruction::OpcodeType::INDIR_LD_VIRTUAL_INDEX)
                    break;
                my_instruction_recvs[instruction_id] = true;
                DPRINTF(
                    MAAController,
                    "%s: %s received with backing address 0x%lx!\n",
                    __func__, current_instruction->print(),
                    current_instruction->backingAddr);
                respond_immediately = false;
                scheduleDispatchInstructionEvent();
                break;
            }
            case 4: {
                panic_if(instruction_id == -1,
                         "Received index address before instruction "
                         "header!\n");
                panic_if(
                    current_instruction->opcode !=
                            Instruction::OpcodeType::INDIR_LD_VIRTUAL_INDEX &&
                        current_instruction->opcode !=
                            Instruction::OpcodeType::INDIR_LD_INDEX &&
                        !current_instruction->isSoaJitRmw() &&
                        !current_instruction->isLogicalALUScalar() &&
                        !current_instruction->isLogicalALUVector(),
                    "Instruction word four is only valid for direct-index "
                    "loads or logical ALU_SCALAR source backing!\n");
                if (current_instruction->isLogicalALUScalar()) {
                    maa::LogicalSPDCacheABI::ScalarOperandShape shape;
                    shape.datatype = static_cast<uint8_t>(
                        current_instruction->datatype);
                    shape.optype = static_cast<uint8_t>(
                        current_instruction->optype);
                    shape.src1LogicalID = current_instruction->src1LogicalID;
                    shape.src2LogicalID = current_instruction->src2LogicalID;
                    shape.dst1LogicalID = current_instruction->dst1LogicalID;
                    shape.src1SpdID = current_instruction->src1SpdID;
                    shape.src2SpdID = current_instruction->src2SpdID;
                    shape.dst1SpdID = current_instruction->dst1SpdID;
                    shape.dst2SpdID = current_instruction->dst2SpdID;
                    shape.src1RegID = current_instruction->src1RegID;
                    shape.src2RegID = current_instruction->src2RegID;
                    shape.src3RegID = current_instruction->src3RegID;
                    shape.dst1RegID = current_instruction->dst1RegID;
                    shape.dst2RegID = current_instruction->dst2RegID;
                    shape.condSpdID = current_instruction->condSpdID;
                    shape.baseAddr = current_instruction->baseAddr;
                    shape.sourceBackingAddr = data;
                    shape.destinationBackingAddr =
                        current_instruction->backingAddr;
                    const auto validation =
                        maa::LogicalSPDCacheABI::validateLogicalALUScalar(
                            shape, static_cast<uint8_t>(
                                       current_instruction->opcode),
                            num_regs);
                    panic_if(validation != maa::LogicalSPDCacheABI::
                                               ScalarValidation::Valid,
                             "Rejected logical ALU_SCALAR ABI shape (%d) "
                             "before controller state mutation\n",
                             static_cast<int>(validation));
                    const int source_range = getAddrRegion(data);
                    panic_if(source_range < 0,
                             "Logical source backing address 0x%lx is not "
                             "in a registered memory region\n", data);
                    const auto source_validation =
                        maa::LogicalSPDCacheABI::validateSourceSpan(
                            data, shape.datatype,
                            addrRegions[source_range].first,
                            addrRegions[source_range].second);
                    const auto destination_validation =
                        maa::LogicalSPDCacheABI::validateDestinationSpan(
                            current_instruction->backingAddr, shape.datatype,
                            current_instruction->backingMinAddr,
                            current_instruction->backingMaxAddr);
                    panic_if(source_validation != maa::LogicalSPDCacheABI::
                                                      DestinationValidation::Valid,
                             "Rejected logical ALU_SCALAR source backing "
                             "(%d) before controller state mutation\n",
                             static_cast<int>(source_validation));
                    panic_if(destination_validation !=
                                 maa::LogicalSPDCacheABI::
                                     DestinationValidation::Valid,
                             "Rejected logical ALU_SCALAR destination "
                             "backing (%d) before controller state mutation\n",
                             static_cast<int>(destination_validation));
                    // The accepted legacy bridge remains exactly two
                    // descriptors wide.  IDs 2..6 exist only for the opt-in
                    // production page scheduler and must not reach it.
                    panic_if(
                        !logicalTilePageSchedulerEnabled() &&
                            (current_instruction->src1LogicalID >= 2 ||
                             current_instruction->dst1LogicalID >= 2),
                        "Logical ALU_SCALAR descriptor IDs 2..6 require the "
                        "logical tile page scheduler; legacy IDs 0/1 are "
                        "unchanged\n");
                    current_instruction->logicalSourceBackingAddr = data;
                    current_instruction->logicalSourceAddrRangeID =
                        source_range;
                    current_instruction->logicalSourceMinAddr =
                        addrRegions[source_range].first;
                    current_instruction->logicalSourceMaxAddr =
                        addrRegions[source_range].second;
                    my_instruction_recvs[instruction_id] = true;
                    DPRINTF(MAAController,
                            "%s: %s received with logical source backing "
                            "0x%lx and destination backing 0x%lx!\n",
                            __func__, current_instruction->print(), data,
                            current_instruction->backingAddr);
                    respond_immediately = false;
                    scheduleDispatchInstructionEvent();
                    break;
                }
                if (current_instruction->isLogicalALUVector()) {
                    current_instruction->logicalSourceBackingAddr = data;
                    break;
                }
                if (current_instruction->isSoaJitPageFedRmw()) {
                    panic_if(
                        data != maa::PageFedSoaJitABI::NoIndexBacking,
                        "Page-fed SoA/JIT word four must carry the zero-"
                        "backing sentinel, got 0x%lx\n", data);
                    current_instruction->indexAddr =
                        maa::PageFedSoaJitABI::NoIndexBacking;
                    break;
                }
                current_instruction->indexAddr = data;
                current_instruction->indexAddrRangeID = getAddrRegion(data);
                panic_if(current_instruction->indexAddrRangeID < 0,
                         "Index address 0x%lx is not in a registered memory "
                         "region\n",
                         data);
                current_instruction->indexMinAddr =
                    addrRegions[current_instruction->indexAddrRangeID].first;
                current_instruction->indexMaxAddr =
                    addrRegions[current_instruction->indexAddrRangeID].second;
                if (current_instruction->isSoaJitRmw())
                    break;
                if (current_instruction->isFusedP16ProductCandidate())
                    break;
                my_instruction_recvs[instruction_id] = true;
                DPRINTF(MAAController,
                        "%s: %s received with index address 0x%lx!\n",
                        __func__, current_instruction->print(),
                        current_instruction->indexAddr);
                respond_immediately = false;
                scheduleDispatchInstructionEvent();
                break;
            }
            case 5: {
                panic_if(instruction_id == -1,
                         "Received predicate address before instruction "
                         "header!\n");
                if (current_instruction->isFusedP16ProductCandidate()) {
                    using Contract = maa::FusedP16ProductContract;
                    panic_if(
                        !current_instruction->hasValidFusedP16ProductShape() ||
                            current_instruction->
                                fusedP16CoefficientWordReceived ||
                            current_instruction->addrRangeID < 0 ||
                            current_instruction->backingAddrRangeID < 0 ||
                            current_instruction->indexAddrRangeID < 0 ||
                            !Contract::aligned(data),
                        "Malformed fused-p16 coefficient closure\n");
                    current_instruction->predicateAddr = data;
                    current_instruction->predicateAddrRangeID =
                        getAddrRegion(data);
                    panic_if(current_instruction->predicateAddrRangeID < 0,
                             "Fused-p16 coefficient address 0x%lx is not "
                             "registered\n", data);
                    current_instruction->predicateMinAddr = addrRegions[
                        current_instruction->predicateAddrRangeID].first;
                    current_instruction->predicateMaxAddr = addrRegions[
                        current_instruction->predicateAddrRangeID].second;
                    panic_if(
                        !Contract::spanFits(
                            current_instruction->backingAddr,
                            current_instruction->backingMinAddr,
                            current_instruction->backingMaxAddr) ||
                            !Contract::spanFits(
                                current_instruction->indexAddr,
                                current_instruction->indexMinAddr,
                                current_instruction->indexMaxAddr) ||
                            !Contract::spanFits(
                                current_instruction->predicateAddr,
                                current_instruction->predicateMinAddr,
                                current_instruction->predicateMaxAddr) ||
                            !Contract::registeredWordFits(
                                current_instruction->baseAddr,
                                current_instruction->minAddr,
                                current_instruction->maxAddr),
                        "Fused-p16 requires an aligned p word in its "
                        "registered region and full 16K aligned "
                        "product/colidx/coefficient spans\n");
                    const Addr p_begin = current_instruction->minAddr;
                    const Addr product = current_instruction->backingAddr;
                    const Addr index = current_instruction->indexAddr;
                    const Addr coefficient =
                        current_instruction->predicateAddr;
                    panic_if(
                        !Contract::registeredRegionsDisjoint(
                            p_begin, current_instruction->maxAddr,
                            product, index, coefficient),
                        "Fused-p16 registered p region and exact 16K "
                        "product/colidx/coefficient spans must be pairwise "
                        "disjoint\n");
                    current_instruction->fusedP16CoefficientWordReceived =
                        true;
                    my_instruction_recvs[instruction_id] = true;
                    DPRINTF(MAAController,
                            "%s: %s received guarded fused-p16 product "
                            "coefficient=0x%lx\n",
                            __func__, current_instruction->print(), data);
                    respond_immediately = false;
                    scheduleDispatchInstructionEvent();
                    break;
                }
                if (current_instruction->isLogicalALUVector()) {
                    current_instruction->logicalSource2BackingAddr = data;
                    maa::LogicalSPDCacheABI::VectorOperandShape shape;
                    shape.datatype = static_cast<uint8_t>(
                        current_instruction->datatype);
                    shape.optype = static_cast<uint8_t>(
                        current_instruction->optype);
                    shape.src1LogicalID = current_instruction->src1LogicalID;
                    shape.src2LogicalID = current_instruction->src2LogicalID;
                    shape.dst1LogicalID = current_instruction->dst1LogicalID;
                    shape.src1SpdID = current_instruction->src1SpdID;
                    shape.src2SpdID = current_instruction->src2SpdID;
                    shape.dst1SpdID = current_instruction->dst1SpdID;
                    shape.dst2SpdID = current_instruction->dst2SpdID;
                    shape.src1RegID = current_instruction->src1RegID;
                    shape.src2RegID = current_instruction->src2RegID;
                    shape.src3RegID = current_instruction->src3RegID;
                    shape.dst1RegID = current_instruction->dst1RegID;
                    shape.dst2RegID = current_instruction->dst2RegID;
                    shape.condSpdID = current_instruction->condSpdID;
                    shape.baseAddr = current_instruction->baseAddr;
                    shape.source1BackingAddr =
                        current_instruction->logicalSourceBackingAddr;
                    shape.source2BackingAddr = data;
                    shape.destinationBackingAddr =
                        current_instruction->logicalDestinationBackingAddr;
                    const auto validation =
                        maa::LogicalSPDCacheABI::validateLogicalALUVector(
                            shape, static_cast<uint8_t>(
                                       current_instruction->opcode));
                    panic_if(validation != maa::LogicalSPDCacheABI::
                                               VectorValidation::Valid,
                             "Rejected logical ALU_VECTOR ABI shape (%d) "
                             "before controller state mutation\n",
                             static_cast<int>(validation));
                    const int source1_range = getAddrRegion(
                        shape.source1BackingAddr);
                    const int source2_range = getAddrRegion(
                        shape.source2BackingAddr);
                    const int destination_range = getAddrRegion(
                        shape.destinationBackingAddr);
                    panic_if(source1_range < 0 || source2_range < 0 ||
                                 destination_range < 0,
                             "Rejected logical ALU_VECTOR unregistered "
                             "backing span before controller state "
                             "mutation\n");
                    const auto source1_validation =
                        maa::LogicalSPDCacheABI::validateSourceSpan(
                            shape.source1BackingAddr, shape.datatype,
                            addrRegions[source1_range].first,
                            addrRegions[source1_range].second);
                    const auto source2_validation =
                        maa::LogicalSPDCacheABI::validateSourceSpan(
                            shape.source2BackingAddr, shape.datatype,
                            addrRegions[source2_range].first,
                            addrRegions[source2_range].second);
                    const auto destination_validation =
                        maa::LogicalSPDCacheABI::validateDestinationSpan(
                            shape.destinationBackingAddr, shape.datatype,
                            addrRegions[destination_range].first,
                            addrRegions[destination_range].second);
                    const auto valid_span = maa::LogicalSPDCacheABI::
                        DestinationValidation::Valid;
                    panic_if(source1_validation != valid_span ||
                                 source2_validation != valid_span ||
                                 destination_validation != valid_span,
                             "Rejected logical ALU_VECTOR backing span "
                             "before controller state mutation\n");
                    const bool sources_must_be_disjoint =
                        shape.src1LogicalID != shape.src2LogicalID;
                    panic_if(
                        maa::LogicalSPDCacheABI::backingSpansOverlap(
                            shape.destinationBackingAddr,
                            shape.source1BackingAddr, shape.datatype) ||
                        maa::LogicalSPDCacheABI::backingSpansOverlap(
                            shape.destinationBackingAddr,
                            shape.source2BackingAddr, shape.datatype) ||
                        (sources_must_be_disjoint &&
                         maa::LogicalSPDCacheABI::backingSpansOverlap(
                             shape.source1BackingAddr,
                             shape.source2BackingAddr, shape.datatype)),
                        "Rejected logical ALU_VECTOR overlapping backing "
                        "spans before controller state mutation\n");
                    panic_if(!logicalTilePageSchedulerEnabled(),
                             "Logical ALU_VECTOR ABI is disabled unless the "
                             "logical tile page scheduler is enabled\n");
                    current_instruction->logicalSourceAddrRangeID =
                        source1_range;
                    current_instruction->logicalSourceMinAddr =
                        addrRegions[source1_range].first;
                    current_instruction->logicalSourceMaxAddr =
                        addrRegions[source1_range].second;
                    current_instruction->logicalSource2AddrRangeID =
                        source2_range;
                    current_instruction->logicalSource2MinAddr =
                        addrRegions[source2_range].first;
                    current_instruction->logicalSource2MaxAddr =
                        addrRegions[source2_range].second;
                    current_instruction->logicalDestinationAddrRangeID =
                        destination_range;
                    current_instruction->logicalDestinationMinAddr =
                        addrRegions[destination_range].first;
                    current_instruction->logicalDestinationMaxAddr =
                        addrRegions[destination_range].second;
                    my_instruction_recvs[instruction_id] = true;
                    DPRINTF(MAAController,
                            "%s: %s received for logical vector page "
                            "scheduling\n",
                            __func__, current_instruction->print());
                    respond_immediately = false;
                    scheduleDispatchInstructionEvent();
                    break;
                }
                panic_if(!current_instruction->isSoaJitRmw(),
                         "Instruction word five is only valid for the "
                         "guarded SoA/JIT RMW shape\n");
                if (current_instruction->isSoaJitInlineOperandRmw()) {
                    panic_if(data != maa::InlineOperandPageFedABI::
                                         RetirementRingRecords,
                             "Inline-operand word five must declare the "
                             "bounded 4096-record retirement ring\n");
                    current_instruction->soaJitRetirementRecords =
                        static_cast<uint32_t>(data);
                    current_instruction->predicateAddr = 0;
                    current_instruction->soaJitPredicateWordReceived = true;
                    break;
                }
                panic_if(current_instruction->soaJitPredicateWordReceived,
                         "Received duplicate SoA/JIT predicate word\n");
                panic_if(!current_instruction->hasValidSoaJitRmwOperands(),
                         "Rejected malformed SoA/JIT RMW before word-five "
                         "dispatch\n");
                panic_if(current_instruction->isSoaJitScalarRmw() &&
                             data == SoaJitSafety::MaskedIndexModeTag,
                         "Scalar-broadcast SoA/JIT requires a null or "
                         "registered predicate span; masked-index mode is "
                         "vector-only\n");
                panic_if(current_instruction->isSoaJitStore() && data != 0,
                         "SoA/JIT store requires unpredicated "
                         "destinations; predicate/masked mode unsupported\n");
                current_instruction->soaJitMaskedIndex =
                    current_instruction->isSoaJitVectorRmw() &&
                    data == SoaJitSafety::MaskedIndexModeTag;
                current_instruction->predicateAddr =
                    current_instruction->soaJitMaskedIndex ? 0 : data;
                current_instruction->soaJitPredicateWordReceived = true;
                const int soa_word_size = current_instruction->WordSize();
                const bool operands_aligned =
                    current_instruction->isSoaJitPageFedRmw()
                        ? current_instruction->baseAddr % soa_word_size == 0 &&
                              current_instruction->backingAddr %
                                      soa_word_size ==
                                  0 &&
                              data == 0
                        : current_instruction->isSoaJitScalarRmw()
                        ? SoaJitSafety::scalarOperandsAligned(
                              current_instruction->baseAddr,
                              current_instruction->indexAddr,
                              current_instruction->predicateAddr,
                              soa_word_size)
                        : SoaJitSafety::typedOperandsAligned(
                              current_instruction->baseAddr,
                              current_instruction->backingAddr,
                              current_instruction->indexAddr,
                              current_instruction->predicateAddr,
                              soa_word_size);
                panic_if(
                    !operands_aligned,
                    "Rejected misaligned typed SoA/JIT A, value, index, or "
                    "predicate operand before timed request dispatch\n");
                if (current_instruction->predicateAddr != 0) {
                    current_instruction->predicateAddrRangeID =
                        getAddrRegion(current_instruction->predicateAddr);
                    panic_if(current_instruction->predicateAddrRangeID < 0,
                             "Predicate address 0x%lx is not in a "
                             "registered memory region\n",
                             current_instruction->predicateAddr);
                    current_instruction->predicateMinAddr = addrRegions[
                        current_instruction->predicateAddrRangeID].first;
                    current_instruction->predicateMaxAddr = addrRegions[
                        current_instruction->predicateAddrRangeID].second;
                }
                if (current_instruction->hasSoaJitOldResult() ||
                    current_instruction->isSoaJitPageFedRmw())
                    break;
                my_instruction_recvs[instruction_id] = true;
                DPRINTF(MAAController,
                        "%s: %s received with values=0x%lx indices=0x%lx "
                        "predicates=0x%lx masked_index=%d!\n",
                        __func__, current_instruction->print(),
                        current_instruction->backingAddr,
                        current_instruction->indexAddr,
                        current_instruction->predicateAddr,
                        current_instruction->soaJitMaskedIndex);
                respond_immediately = false;
                scheduleDispatchInstructionEvent();
                break;
            }
            case 6: {
                panic_if(instruction_id == -1,
                         "Received SoA/JIT extension word before instruction "
                         "header!\n");
                if (current_instruction->isSoaJitPageFedRmw()) {
                    const uint64_t generation_mask =
                        current_instruction->isSoaJitInlineOperandRmw()
                            ? maa::InlineOperandPageFedABI::GenerationMask
                            : maa::PageFedSoaJitABI::GenerationMask;
                    panic_if(
                        !current_instruction->
                             hasValidSoaJitRmwOperands() ||
                            !current_instruction->
                                 soaJitPredicateWordReceived ||
                            current_instruction->soaJitResultWordReceived ||
                            current_instruction->addrRangeID < 0 ||
                            current_instruction->backingAddrRangeID < 0 ||
                            current_instruction->indexAddrRangeID != -1 ||
                            current_instruction->predicateAddrRangeID != -1 ||
                            data == 0 ||
                            data > generation_mask ||
                            (current_instruction->
                                 isSoaJitInlineOperandRmw() &&
                             current_instruction->
                                 soaJitRetirementRecords !=
                                 maa::InlineOperandPageFedABI::
                                     RetirementRingRecords),
                        "Malformed page-fed SoA/JIT generation/operand "
                        "closure\n");
                    current_instruction->soaJitPageFedGeneration = data;
                    current_instruction->soaJitResultWordReceived = true;
                    my_instruction_recvs[instruction_id] = true;
                    DPRINTF(MAAController,
                            "%s: %s received for page-fed generation=%lu "
                            "with no index backing\n",
                            __func__, current_instruction->print(), data);
                    respond_immediately = false;
                    scheduleDispatchInstructionEvent();
                    break;
                }
                panic_if(!current_instruction->hasSoaJitOldResult() ||
                             !current_instruction->
                                  hasValidSoaJitRmwOperands(),
                         "Instruction word six is only valid for the "
                         "guarded vector old-result SoA/JIT shape\n");
                panic_if(!current_instruction->soaJitPredicateWordReceived ||
                             current_instruction->soaJitResultWordReceived ||
                             current_instruction->addrRangeID < 0 ||
                             (!current_instruction->isSoaJitScalarRmw() &&
                              current_instruction->backingAddrRangeID < 0) ||
                             current_instruction->indexAddrRangeID < 0,
                         "Old-result word requires one complete, ordered "
                         "A/value/index/predicate staging sequence\n");
                panic_if(current_instruction->datatype !=
                             Instruction::DataType::UINT32_TYPE &&
                             current_instruction->datatype !=
                             Instruction::DataType::INT32_TYPE &&
                             current_instruction->datatype !=
                             Instruction::DataType::FLOAT32_TYPE,
                         "SoA/JIT old-result mode supports only 32-bit "
                         "UINT32, INT32, or FP32 operands\n");
                panic_if(!SoaJitSafety::oldResultAligned(data),
                         "SoA/JIT old-result backing 0x%lx must be a "
                         "non-null aligned cache-line span\n", data);
                current_instruction->resultAddr = data;
                current_instruction->resultAddrRangeID = getAddrRegion(data);
                panic_if(current_instruction->resultAddrRangeID < 0,
                         "Old-result address 0x%lx is not in a registered "
                         "memory region\n", data);
                current_instruction->resultMinAddr = addrRegions[
                    current_instruction->resultAddrRangeID].first;
                current_instruction->resultMaxAddr = addrRegions[
                    current_instruction->resultAddrRangeID].second;
                constexpr Addr result_bytes =
                    16 * 1024 * sizeof(uint32_t);
                panic_if(data < current_instruction->resultMinAddr ||
                             data >= current_instruction->resultMaxAddr ||
                             current_instruction->resultMaxAddr - data <
                                 result_bytes,
                         "SoA/JIT old-result full logical-16K span exceeds "
                         "its registered region\n");
                panic_if(
                    current_instruction->resultAddrRangeID ==
                            current_instruction->addrRangeID ||
                        current_instruction->resultAddrRangeID ==
                            current_instruction->backingAddrRangeID ||
                        current_instruction->resultAddrRangeID ==
                            current_instruction->indexAddrRangeID ||
                        (current_instruction->predicateAddr != 0 &&
                         current_instruction->resultAddrRangeID ==
                             current_instruction->predicateAddrRangeID),
                    "Old-result backing must not alias an input or target "
                    "memory region\n");
                current_instruction->soaJitResultWordReceived = true;
                my_instruction_recvs[instruction_id] = true;
                DPRINTF(MAAController,
                        "%s: %s received with old-result backing=0x%lx!\n",
                        __func__, current_instruction->print(),
                        current_instruction->resultAddr);
                respond_immediately = false;
                scheduleDispatchInstructionEvent();
                break;
            }
            default:
                assert(false);
            }
            assert(pkt->needsResponse());
            if (respond_immediately) {
                pkt->makeTimingResponse();
                // Here we reset the timing of the packet.
                Tick old_header_delay = pkt->headerDelay;
                pkt->headerDelay = pkt->payloadDelay = 0;
                cpuSidePorts[core_id]->schedTimingResp(pkt, getClockEdge(Cycles(1)) + old_header_delay);
            }
            break;
        }
        default:
            // Write to SPD_DATA_CACHEABLE_RANGE not possible. All SPD writes must be to SPD_DATA_NONCACHEABLE_RANGE
            // Write to SPD_SIZE_RANGE not possible. Size is read-only.
            // Write to SPD_READY_RANGE not possible. Ready is read-only.
            panic_if(true, "%s: Error: Range(%s) and cmd(%s) is illegal. Packet: %s\n", __func__, address_range.print(), pkt->cmdString(), pkt->print());
            assert(false);
        }
        break;
    }
    case MemCmd::ReadReq: {
        // all read responses have a data payload
        assert(pkt->hasRespData());
        switch (address_range.getType()) {
        case AddressRangeType::Type::INSTRUCTION_RANGE: {
            panic_if(!inline_variable_retirement || core_id < 0 ||
                         core_id >= static_cast<int>(cpuSidePorts.size()) ||
                         pkt->getSize() != sizeof(uint64_t) ||
                         address_range.getOffset() != 7 * sizeof(uint64_t),
                     "Invalid variable retirement count MMIO read\n");
            const auto requester = my_RID_to_core_id.find(pkt->requestorId());
            panic_if(requester == my_RID_to_core_id.end() ||
                         requester->second < 0 ||
                         requester->second >= num_cores,
                     "Unknown retirement count MMIO requester\n");
            const uint16_t requester_core = requester->second;
            const uint16_t requester_maa = requester_core % num_maas;
            IndirectAccessUnit *owner = nullptr;
            for (unsigned int unit = 0;
                 unit < num_indirect_units_total; ++unit) {
                if (!indirectAccessUnits[unit].inlineOperandOwnedByMaa(
                        requester_maa))
                    continue;
                panic_if(owner != nullptr,
                         "Ambiguous retirement count owner\n");
                owner = &indirectAccessUnits[unit];
            }
            panic_if(owner == nullptr, "Missing retirement count owner\n");
            const uint64_t response = owner->readInlineRetirementCount(
                requester_core, requester_maa, core_id);
            pkt->setLE<uint64_t>(response);
            pkt->makeTimingResponse();
            const Tick old_header_delay = pkt->headerDelay;
            pkt->headerDelay = pkt->payloadDelay = 0;
            cpuSidePorts[core_id]->schedTimingResp(
                pkt, getClockEdge(Cycles(1)) + old_header_delay);
            break;
        }
        case AddressRangeType::Type::SPD_SIZE_RANGE: {
            panic_if(core_id != 0, "Size range is only for the core 0\n");
            panic_if(pkt->getSize() != sizeof(uint16_t), "%s: Error: Invalid size for SPD size: %d, packet: %s\n", __func__, pkt->getSize(), pkt->print());
            Addr offset = address_range.getOffset();
            assert(offset % sizeof(uint16_t) == 0);
            int element_id = offset / sizeof(uint16_t);
            panic_if(logicalTileReservedLane(element_id),
                     "Guest size read references reserved SPD lane "
                     "%d\n", element_id);
            int full_size = spd->getSize(element_id);
            uint16_t data = (full_size > static_cast<int>(std::numeric_limits<uint16_t>::max()))
                                ? std::numeric_limits<uint16_t>::max()
                                : static_cast<uint16_t>(full_size);
            uint8_t *dataPtr = (uint8_t *)(&data);
            pkt->setData(dataPtr);
            assert(pkt->needsResponse());
            pkt->makeTimingResponse();
            // Here we reset the timing of the packet.
            Tick old_header_delay = pkt->headerDelay;
            pkt->headerDelay = pkt->payloadDelay = 0;
            cpuSidePorts[core_id]->schedTimingResp(pkt, getClockEdge(Cycles(1)) + old_header_delay);
            break;
        }
        case AddressRangeType::Type::SPD_READY_RANGE: {
            panic_if(core_id != 0, "Ready range is only for the core 0\n");
            panic_if(pkt->getSize() != sizeof(uint16_t), "%s: Error: Invalid size for SPD ready: %d, packet: %s\n", __func__, pkt->getSize(), pkt->print());
            Addr offset = address_range.getOffset();
            assert(offset % sizeof(uint16_t) == 0);
            int ready_tile_id = offset / sizeof(uint16_t);
            panic_if(logicalTileReservedLane(ready_tile_id),
                     "Guest readiness read references reserved SPD "
                     "lane %d\n", ready_tile_id);
            const uint16_t one = 1;
            pkt->setData((const uint8_t *)&one);
            assert(pkt->needsResponse());
            if (spd->getTileReady(ready_tile_id)) {
                pkt->makeTimingResponse();
                // Here we reset the timing of the packet.
                Tick old_header_delay = pkt->headerDelay;
                pkt->headerDelay = pkt->payloadDelay = 0;
                cpuSidePorts[core_id]->schedTimingResp(pkt, getClockEdge(Cycles(1)) + old_header_delay);
            } else {
                // We need to respond to this packet later
                my_ready_pkts.push_back(pkt);
                my_ready_tile_ids.push_back(ready_tile_id);
            }
            break;
        }
        case AddressRangeType::Type::VIRTUAL_PAGE_READY_RANGE: {
            panic_if(core_id != 0,
                     "Virtual-page ready range is only for core 0\n");
            panic_if(pkt->getSize() != sizeof(uint16_t),
                     "%s: invalid virtual-page ready read size %d\n",
                     __func__, pkt->getSize());
            const Addr offset = address_range.getOffset();
            panic_if(offset % sizeof(uint16_t) != 0,
                     "unaligned virtual-page ready offset 0x%lx\n", offset);
            const int virtualID = offset / sizeof(uint16_t);
            const int tokenTileID = virtualID / MAA::MaxVirtualPages;
            const int pageID = virtualID % MAA::MaxVirtualPages;
            const int readyID =
                num_tiles + tokenTileID * MAA::MaxVirtualPages + pageID;
            const uint16_t one = 1;
            pkt->setData((const uint8_t *)&one);
            assert(pkt->needsResponse());
            stats.virtual_page_wait_reads++;
            if (getVirtualPageReady(tokenTileID, pageID)) {
                DPRINTF(MAAVirtualTrace,
                        "event=page_wait_immediate token=%d page=%d\n",
                        tokenTileID, pageID);
                pkt->makeTimingResponse();
                Tick oldHeaderDelay = pkt->headerDelay;
                pkt->headerDelay = pkt->payloadDelay = 0;
                cpuSidePorts[core_id]->schedTimingResp(
                    pkt, getClockEdge(Cycles(1)) + oldHeaderDelay);
                stats.virtual_page_wait_responses++;
            } else {
                DPRINTF(MAAVirtualTrace,
                        "event=page_wait_deferred token=%d page=%d "
                        "ready_id=%d\n",
                        tokenTileID, pageID, readyID);
                my_ready_pkts.push_back(pkt);
                my_ready_tile_ids.push_back(readyID);
                stats.virtual_page_wait_deferrals++;
            }
            break;
        }
        case AddressRangeType::Type::SCALAR_RANGE: {
            panic_if(core_id != 0, "Scalar range is only for the core 0\n");
            panic_if(pkt->getSize() != 4 && pkt->getSize() != 8, "Invalid size for SPD data: %d\n", pkt->getSize());
            Addr offset = address_range.getOffset();
            int element_id = offset % (num_regs * sizeof(uint32_t));
            assert(element_id % sizeof(uint32_t) == 0);
            element_id /= sizeof(uint32_t);
            uint8_t *dataPtr = rf->getDataPtr(element_id);
            pkt->setData(dataPtr);
            assert(pkt->needsResponse());
            pkt->makeTimingResponse();
            // Here we reset the timing of the packet.
            Tick old_header_delay = pkt->headerDelay;
            pkt->headerDelay = pkt->payloadDelay = 0;
            cpuSidePorts[core_id]->schedTimingResp(pkt, getClockEdge(Cycles(1)) + old_header_delay);
            break;
        }
        default: {
            // Read from SPD_DATA_CACHEABLE_RANGE uses ReadSharedReq command.
            // Read from SPD_DATA_NONCACHEABLE_RANGE not possible. All SPD reads must be from SPD_DATA_CACHEABLE_RANGE.
            panic_if(true, "%s: Error: Range(%s) and cmd(%s) is illegal. Packet: %s\n", __func__, address_range.print(), pkt->cmdString(), pkt->print());
            assert(false);
        }
        }
        break;
    }
    case MemCmd::ReadExReq:
    case MemCmd::ReadSharedReq: {
        // all read responses have a data payload
        assert(pkt->hasRespData());
        switch (address_range.getType()) {
        case AddressRangeType::Type::SPD_DATA_CACHEABLE_RANGE: {
            Addr offset = address_range.getOffset();
            int tile_id = offset / (num_tile_elements * sizeof(uint32_t));
            panic_if(logicalTileReservedLane(tile_id) ||
                         logicalCompletionLaneOwned(tile_id),
                     "Guest cacheable data request references "
                     "reserved/owned SPD lane %d\n", tile_id);
            int element_id = offset % (num_tile_elements * sizeof(uint32_t));
            assert(element_id % sizeof(uint32_t) == 0);
            element_id /= sizeof(uint32_t);
            spd->setTileDirty(tile_id, 4);
            if (pkt->cmd == MemCmd::ReadSharedReq) {
                invalidator->read(tile_id, element_id);
            } else {
                invalidator->write(tile_id, element_id);
            }
            uint8_t *dataPtr = spd->getDataPtr(tile_id, element_id);
            pkt->setData(dataPtr);
            assert(pkt->needsResponse());
            pkt->makeTimingResponse();
            // Here we reset the timing of the packet.
            Tick old_header_delay = pkt->headerDelay;
            pkt->headerDelay = pkt->payloadDelay = 0;
            cpuSidePorts[core_id]->schedTimingResp(pkt, getClockEdge(devicePaging() ? spd->getDataLatency(1) : Cycles(1)) + old_header_delay);
            break;
        }
        default:
            panic_if(true, "%s: Error: Range(%s) and cmd(%s) is illegal. Packet: %s\n", __func__, address_range.print(), pkt->cmdString(), pkt->print());
            assert(false);
        }
        break;
    }
    default:
        panic("Unsupported MAA CPU request: %s", pkt->print());
    }
}
bool MAA::CpuSidePort::recvTimingReq(PacketPtr pkt) {
    panic_if(core_id >= maa.num_cores,
             "Demand reached snoop-only MAA port: %s", pkt->print());
    assert(pkt->isRequest());
    /// print the packet
    DPRINTF(MAACpuPort, "%s: received %s\n", __func__, pkt->print());

    // A timing retry grants the source port another attempt; gem5 does not
    // require that attempt to carry the same logical request.
    const bool is_retry_attempt = tileRequestRetryOutstanding;
    if (is_retry_attempt) {
        assert(!mustRetryTileRequest);
        tileRequestRetryOutstanding = false;
        maa.stats.cpu_spd_data_read_retry_attempts++;
    }
    if (!mustRetryTileRequest) {
        const AddressRangeType address_range(
            pkt->getAddr(), maa.addrRanges);
        if (address_range.isValid() &&
            address_range.getType() ==
                AddressRangeType::Type::SPD_DATA_CACHEABLE_RANGE) {
            const Addr logical_tile_bytes =
                static_cast<Addr>(maa.num_tile_elements) * sizeof(uint32_t);
            const int tile_id =
                address_range.getOffset() / logical_tile_bytes;
            panic_if(maa.logicalTileReservedLane(tile_id) ||
                         maa.logicalCompletionLaneOwned(tile_id),
                     "Guest cacheable access references reserved/owned SPD "
                     "lane %d before aperture classification\n", tile_id);
            const bool packet_prefetch = pkt->cmd.isPrefetch();
            const bool request_prefetch = pkt->req->isPrefetch();
            const bool task_prefetch = pkt->req->taskId() ==
                context_switch_task_id::Prefetcher;
            const bool all_bytes_enabled =
                gem5::maa::CpuSpdAperture::allBytesEnabled(
                    pkt->req->getByteEnable(), pkt->getSize());
            const bool droppable_prefetch =
                isDroppableBoundaryPrefetch(pkt);
            const auto decision = gem5::maa::CpuSpdAperture::classify(
                address_range.getOffset(), pkt->getSize(),
                maa.system->cacheLineSize(), maa.num_tile_elements,
                maa.devicePaging() ? maa.num_tile_elements : maa.physical_tile_elements,
                sizeof(uint32_t),
                droppable_prefetch);
            if (decision.disposition ==
                gem5::maa::CpuSpdAperture::Disposition::
                    DropBoundaryPrefetch) {
                if (is_retry_attempt) {
                    maa.stats.cpu_spd_data_read_retry_acceptances++;
                }
                maa.stats.cpu_spd_boundary_prefetch_drops++;
                DPRINTF(MAAVirtualTrace,
                        "event=cpu_spd_boundary_prefetch_drop schema=1 "
                        "addr=0x%lx tile=%lu tile_offset=%lu size=%u "
                        "physical_payload_bytes=%lu logical_tile_bytes=%lu "
                        "packet_prefetch=%d request_prefetch=%d "
                        "task_prefetch=%d all_bytes_enabled=%d cmd=%s "
                        "response=BadAddress "
                        "spd_touched=0 invalidator_touched=0\n",
                        pkt->getAddr(), decision.tile,
                        decision.tileOffset, pkt->getSize(),
                        decision.physicalPayloadBytes,
                        decision.logicalTileBytes, packet_prefetch,
                        request_prefetch, task_prefetch,
                        all_bytes_enabled,
                        pkt->cmdString());
                // The logical aperture is address reservation, not padded
                // SPD storage.  Elements at and beyond physical capacity are
                // permanently invalid host-SPD addresses; virtual pages live
                // in coherent backing memory.  An error response therefore
                // prevents cache installation, and any coalesced demand also
                // fails closed instead of observing fabricated padding.
                pkt->makeTimingResponse();
                pkt->setBadAddress();
                const Tick old_header_delay = pkt->headerDelay;
                pkt->headerDelay = pkt->payloadDelay = 0;
                schedTimingResp(
                    pkt, maa.getClockEdge(Cycles(1)) + old_header_delay);
                return true;
            }
            if (decision.disposition !=
                gem5::maa::CpuSpdAperture::Disposition::Valid) {
                maa.stats.cpu_spd_out_of_range_rejections++;
                panic("CPU SPD aperture rejected %s access: addr=0x%lx "
                      "tile=%lu tile_offset=%lu size=%u physical_bytes=%lu "
                      "logical_bytes=%lu speculative=%d\n",
                      gem5::maa::CpuSpdAperture::name(decision.disposition),
                      pkt->getAddr(), decision.tile, decision.tileOffset,
                      pkt->getSize(), decision.physicalPayloadBytes,
                      decision.logicalTileBytes, droppable_prefetch);
            }
        }
    }
    requireFullyEnabledRequest(pkt, maa.system->cacheLineSize());
    // This insertion follows the original complete aperture/reserved-lane
    // classification. No data is touched until original readiness is true.
    if (maa.progressCreditOwner &&
        (pkt->cmd == MemCmd::ReadExReq || pkt->cmd == MemCmd::ReadSharedReq)) {
        const AddressRangeType range(pkt->getAddr(), maa.addrRanges);
        if (range.isValid() && range.getType() ==
            AddressRangeType::Type::SPD_DATA_CACHEABLE_RANGE) {
            const unsigned tile = range.getOffset() /
                (maa.num_tile_elements * sizeof(uint32_t));
            { // Selected shared policy queues ready reads too; original backend latency is retained.
                panic_if(mustRetryTileRequest || is_retry_attempt,
                         "Legacy retry cannot cross new progress cohort");
                const uint64_t token = maa.progressCreditOwner->authorizeSpdReceive(
                    pkt->req, pkt->getBlockAddr(maa.system->cacheLineSize()), core_id);
                panic_if(!token, "Unready SPD packet lacks in-flight/accepted permit");
                panic_if(!pkt->needsResponse(), "Deferred SPD has no response");
                // The broker claim records ownership inside synchronous send.
                // A false downstream return may not roll back this ownership.
                maa.progressCreditOwner->claimDeferredReceiver(pkt->req, token, core_id);
                panic_if(!maa.deferredSpdOwners.accept(
                             reinterpret_cast<std::uintptr_t>(pkt), pkt->req,
                             token, tile, core_id),
                         "Deferred SPD ownership/capacity inconsistency");
                maa.scheduleProgressDeferred();
                return true;
            }
        }
    }
    if (tryTiming(pkt)) {
        if (is_retry_attempt) {
            maa.stats.cpu_spd_data_read_retry_acceptances++;
        }
        maa.recvTimingReq(pkt, core_id);
        return true;
    }
    return false;
}
void MAA::CpuSidePort::recvFunctional(PacketPtr pkt) {
    assert(false);
}
Tick MAA::recvAtomic(PacketPtr pkt) {
    /// print the packet
    DPRINTF(MAACpuPort, "%s: received %s\n", __func__, pkt->print());
    assert(false);
    return 0;
}
Tick MAA::CpuSidePort::recvAtomic(PacketPtr pkt) {
    /// print the packet
    DPRINTF(MAACpuPort, "%s: received %s\n", __func__, pkt->print());
    assert(false);
    return maa.recvAtomic(pkt);
}

AddrRangeList MAA::CpuSidePort::getAddrRanges() const {
    if (core_id >= maa.num_cores) return {};
    return maa.getAddrRanges(core_id);
}

bool MAA::CpuSidePort::sendSnoopInvalidatePacket(PacketPtr pkt) {
    /// print the packet
    DPRINTF(MAACpuPort, "%s: sending invalidation %s\n", __func__, pkt->print());
    int pkt_core_id = maa.core_addr(pkt->getAddr());
    panic_if(pkt_core_id != core_id % maa.num_cores,
             "%s: packet is for core %d\n", __func__, pkt_core_id);
    panic_if(is_blocked, "%s: port is blocked\n", __func__);
    if (outstandingCpuSidePackets == maxOutstandingCpuSidePackets) {
        // XBAR is full
        DPRINTF(MAACpuPort, "%s Send failed because XBAR is full...\n", __func__);
        is_blocked = true;
        return false;
    }
    sendTimingSnoopReq(pkt);
    DPRINTF(MAACpuPort, "%s Send is successfull...\n", __func__);
    if (pkt->cacheResponding())
        outstandingCpuSidePackets++;
    return true;
}
void MAA::CpuSidePort::retryTileRequest() {
    if (!mustRetryTileRequest) {
        return;
    }
    assert(retryTileID >= 0);
    if (!maa.spd->getTileReady(retryTileID)) {
        return;
    }

    assert(!tileRequestRetryOutstanding);
    const int tile_id = retryTileID;
    DPRINTF(MAACpuPort, "%s: retrying request for tile[%d]\n", __func__,
            tile_id);
    mustRetryTileRequest = false;
    tileRequestRetryOutstanding = true;
    retryTileID = -1;
    maa.stats.cpu_spd_data_read_retry_signals++;
    sendRetryReq();
}
bool MAA::sendSnoopInvalidateCpu(PacketPtr pkt) {
    panic_if(pkt->isExpressSnoop() == false, "Packet is not an express snoop packet\n");
    int pkt_core_id = core_addr(pkt->getAddr());
    const AddressRangeType range(pkt->getAddr(), addrRanges);
    if (devicePaging() && (!range.isValid() || range.getType() !=
            AddressRangeType::Type::SPD_DATA_CACHEABLE_RANGE))
        pkt_core_id += num_cores;
    return cpuSidePorts[pkt_core_id]->sendSnoopInvalidatePacket(pkt);
}

void MAA::sendSnoopPacketCpu(PacketPtr pkt) {
    panic_if(pkt->isExpressSnoop() == false, "Packet is not an express snoop packet\n");
    int pkt_core_id = core_addr(pkt->getAddr());
    const AddressRangeType range(pkt->getAddr(), addrRanges);
    if (devicePaging() && (!range.isValid() || range.getType() !=
            AddressRangeType::Type::SPD_DATA_CACHEABLE_RANGE))
        pkt_core_id += num_cores;
    cpuSidePorts[pkt_core_id]->sendTimingSnoopReq(pkt);
}

void MAA::CpuSidePort::allocate(int _core_id, int _maxOutstandingCpuSidePackets) {
    outstandingCpuSidePackets = 0;
    core_id = _core_id;
    maxOutstandingCpuSidePackets = _maxOutstandingCpuSidePackets - 16;
    // Split the old per-core snoop budget across the two physical banks;
    // topology separation must not manufacture additional response credits.
    if (maa.devicePaging()) maxOutstandingCpuSidePackets /= 2;
    panic_if(maxOutstandingCpuSidePackets <= 0, "Empty CPU snoop budget");
    is_blocked = false;
    mustRetryTileRequest = false;
    tileRequestRetryOutstanding = false;
    retryTileID = -1;
}

MAA::CpuSidePort::CpuSidePort(const std::string &_name, MAA &_maa,
                              const std::string &_label)
    : MAAResponsePort(_name, _maa, _label) {
}
} // namespace gem5
