#ifndef __MEM_MAA_SPD_HH__
#define __MEM_MAA_SPD_HH__

#include <cassert>
#include <cstdint>
#include <cstring>
#include <array>
#include <vector>
#include "base/logging.hh"
#include "base/trace.hh"
#include "base/types.hh"
#include "mem/packet.hh"
#include "debug/SPD.hh"

namespace gem5 {
class MAA;

class SPD {
public:
    enum class TileStatus : uint8_t {
        Idle = 0,
        Service = 1,
        Finished = 2,
        MAX
    };
    std::string tile_status_names[4] = {
        "Idle",
        "Service",
        "Finished",
        "MAX"};

protected:
    uint8_t *tiles_data;
    TileStatus *tiles_status;
    bool *tiles_dirty;
    uint16_t *tiles_ready;
    uint32_t *tiles_size;
    std::vector<bool> element_finished;
    std::vector<uint8_t> *waiting_units_funcs;
    std::vector<int> *waiting_units_ids;
    unsigned int visible_tile_count;
    unsigned int num_tile_elements;
    unsigned int physical_tile_elements;
    Tick *read_port_busy_until;
    Tick *write_port_busy_until;
    const Cycles read_latency, write_latency;
    const int num_read_ports, num_write_ports;
    MAA *maa;

    // Payload remains exclusively in tiles_data: 32 x 4096 x 4 bytes.
    // One finite directory entry per architectural page; one page transfer.
    struct Page
    {
        int frame = -1;
        uint64_t generation = 1;
        bool backed = false;
    };
    struct Frame {
        int page = -1;
        uint64_t generation = 0;
        bool dirty = false;
        uint8_t pinned = 0; // per-engine owner bits; never a shared release bit
        uint64_t age = 0;
    };
    std::vector<Page> pages;
    std::array<Frame, 32> frames{};
    unsigned frameBudget = 0;
    uint64_t pageClock = 0;
    int requestedPage = -1;
    int transferFrame = -1;
    int transferLine = 0;
    uint8_t requestedOwners = 0;
    bool stableCore0Fit = false;
    bool spilling = false;
    bool lineReadReserved = false;
    // Credits cover both coherent response ownership and SPD fill completion.
    // Packets refer directly to distinct lines of the pinned existing frame.
    struct PageLine
    {
        int line = -1;
        bool waiting = false;
        Tick ready = 0;
    };
    std::vector<PageLine> pageLines;
    bool creditFull = false;
    Tick creditFullSince = 0, creditFullTicks = 0;
    Tick firstAcceptedTick = 0, lastAcceptedTick = 0;
    uint64_t acceptedLines = 0;
    unsigned transferOutstanding = 0, peakTransferOutstanding = 0;
    uint64_t transferRetries = 0;
    unsigned mappedFramePeak = 0;
    Tick pageWaitStart = 0, pageWaitTicks = 0;
    Tick transferReady = 0;
    uint64_t transferGeneration = 0;
    uint64_t lookupCycles = 0;
    uint64_t directoryLookups = 0, pageMisses = 0;
    uint64_t spillLines = 0, fillLines = 0, dirtyEvictions = 0;

    int pageIndex(int tile, int element) const;
    uint8_t *payload(int tile, int element, int bytes = 4);
    int readyIndex(int tile, int element, int bytes) const;
    void resetPages(int tile, bool preservePayload = false);
    void setTileIdleImpl(int tile, int wordSize, bool preservePayload);
    void publishPage();


public:
    void check_tile_id(int tile_id, int word_size) {
        panic_if(tile_id < 0 || tile_id >= visible_tile_count,
                 "Invalid visible tile_id: %d (visible count %u)\n",
                 tile_id, visible_tile_count);
        panic_if(word_size != 4 && word_size != 8,
                 "Invalid data type size: %d\n", word_size);
        panic_if(word_size == 8 &&
                     tile_id >= static_cast<int>(visible_tile_count) - 1,
                 "Invalid visible tile_id for 8-byte data type: %d\n",
                 tile_id);
    }
    void check_tile_element_id(int tile_id, int element_id, int word_size) {
        check_tile_id(tile_id, word_size);
        panic_if(paged() && word_size != 4,
                 "Device SPD paging supports 32-bit data only");
        panic_if(element_id < 0 || element_id >= (paged() ? num_tile_elements : physical_tile_elements),
                 "SPD element %d exceeds physical tile capacity %u "
                 "(logical capacity %u)\n",
                 element_id, physical_tile_elements, num_tile_elements);
    }
    template <typename T>
    T getData(int tile_id, int element_id) {
        check_tile_element_id(tile_id, element_id, sizeof(T));
        return *reinterpret_cast<T *>(payload(tile_id, element_id, sizeof(T)));
    }
    uint8_t *getDataPtr(int tile_id, int element_id) {
        check_tile_element_id(tile_id, element_id, sizeof(uint32_t));
        return payload(tile_id, element_id);
    }
    template <typename T>
    void setData(int tile_id, int element_id, T _data) {
        check_tile_element_id(tile_id, element_id, sizeof(T));
        *reinterpret_cast<T *>(payload(tile_id, element_id, sizeof(T))) = _data;
        if (paged())
            frames[pages[pageIndex(tile_id, element_id)].frame].dirty = true;
        int tile_element_id = readyIndex(tile_id, element_id, sizeof(T));
        element_finished[tile_element_id] = true;
        DPRINTF(SPD,
                "%s: tile[%d] element[%d] tile_element[%d] finished\n",
                __func__, tile_id, element_id, tile_element_id);
    }
    // Hidden materializer stores use the existing SPD payload array but must
    // not publish element readiness.  The page-ready path remains the sole
    // architectural visibility authority.
    template <typename T>
    void stageData(int tile_id, int element_id, T _data) {
        check_tile_element_id(tile_id, element_id, sizeof(T));
        *reinterpret_cast<T *>(payload(tile_id, element_id, sizeof(T))) = _data;
        if (paged())
            frames[pages[pageIndex(tile_id, element_id)].frame].dirty = true;
    }
    void setFakeData(int tile_id, int element_id, int word_size) {
        check_tile_element_id(tile_id, element_id, word_size);
        int tile_element_id = readyIndex(tile_id, element_id, word_size);
        element_finished[tile_element_id] = true;
        DPRINTF(SPD,
                "%s: tile[%d] element[%d] tile_element[%d] fake finished\n",
                __func__, tile_id, element_id, tile_element_id);
    }
    void wakeup_waiting_units(int tile_id);
    Cycles getDataLatency(int num_accesses);
    Cycles setDataLatency(int tile_id, int num_accesses);
    TileStatus getTileStatus(int tile_id);
    bool getElementFinished(int tile_id, int element_id, int word_size,
                            uint8_t func, int id);
    void setTileIdle(int tile_id, int word_size);
    void setTileIdleMasked(int tile_id, int word_size);
    void setTileService(int tile_id, int word_size);
    void setTileFinished(int tile_id, int word_size);
    void setTileDirty(int tile_id, int word_size);
    void setTileClean(int tile_id, int word_size);
    bool getTileDirty(int tile_id);
    void setTileReady(int tile_id, int word_size);
    void setTileNotReady(int tile_id, int word_size);
    bool getTileReady(int tile_id);
    int getSize(int tile_id);
    int getSizeForReadyElement(int tile_id, int element_id, int word_size);
    void setSize(int tile_id, int size);
    void setVirtualSize(int tile_id, int size);

public:
    enum class PageResult { Ready, Pending, NoVictim };
    PageResult lastPageResult = PageResult::Ready;
    bool paged() const { return frameBudget != 0; }
    void enablePaging(unsigned budget, bool stableFit = false);
    bool ensurePage(int tile, int element, bool pin = true);
    bool leasePage(int tile, int element, bool pin, uint8_t owner);
    void releaseOwnerPages(uint8_t owner);
    bool pageTransferPending(int tile) const;
    uint64_t tileGeneration(int tile) const { return pages.at(tile * 4).generation; }
    void releasePages();
    void servicePager();
    bool pagerResponse(PacketPtr pkt);
    void reportPaging() const;
    bool pagingHasState() const { return pageMisses != 0; }

    SPD(MAA *_maa,
        unsigned int _visible_tile_count,
        unsigned int _num_tile_elements,
        unsigned int _physical_tile_elements,
        Cycles _read_latency,
        Cycles _write_latency,
        int _num_read_ports,
        int _num_write_ports);

    ~SPD();
};

struct Register {
public:
    int register_id;
    int size;
    int maa_id;
    int core_id;
    uint32_t data_UINT32;
    uint64_t data_UINT64;
};

class RF {
protected:
    uint8_t *data;
    unsigned int num_regs;

public:
    template <typename T>
    void check_reg_id(int reg_id) {
        panic_if(reg_id < 0 || reg_id >= num_regs, "Invalid reg_id: %d\n", reg_id);
        panic_if(sizeof(T) != 4 && sizeof(T) != 8, "Invalid data type size: %d\n", sizeof(T));
        panic_if(sizeof(T) == 8 && reg_id >= num_regs - 1, "Invalid reg_id for 8-byte data type: %d\n", reg_id);
    }
    template <typename T>
    T getData(int reg_id) {
        check_reg_id<T>(reg_id);
        return *((T *)(data + reg_id * 4));
    }
    uint8_t *getDataPtr(int reg_id) {
        check_reg_id<uint32_t>(reg_id);
        return (uint8_t *)(data + reg_id * 4);
    }
    template <typename T>
    void setData(int reg_id, T _data) {
        check_reg_id<T>(reg_id);
        *((T *)(data + reg_id * 4)) = _data;
    }

public:
    RF(unsigned int _num_regs);
    ~RF();
};
} // namespace gem5
#endif // __MEM_MAA_SPD_HH__
