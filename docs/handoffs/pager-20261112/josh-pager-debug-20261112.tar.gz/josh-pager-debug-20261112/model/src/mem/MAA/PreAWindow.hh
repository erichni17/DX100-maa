#ifndef __MEM_MAA_PRE_A_WINDOW_HH__
#define __MEM_MAA_PRE_A_WINDOW_HH__

#include <array>
#include <cstdint>
#include <limits>

namespace gem5::maa {

// Optional address-only RowTable. A single finite pool serves every bank:
// no grow/slice skew can exhaust it before the 16K OffsetTable does.
// Payload, index values, predicates and response data are never stored here.
// OffsetTable owns the ordinal/word-ID chains, as in the legacy RowTable.
class PreAWindow
{
  public:
    static constexpr uint32_t Capacity = 16384;
    static constexpr uint32_t HashSlots = 32768;
    static constexpr uint32_t MaxSlices = 1024;
    // Fixed conservative transfer budget for record/hash/list/Offset updates
    // beyond hash-slot and occupied Line reads; charged per admission.
    static constexpr uint32_t AdmissionTransfers = 8;
    static constexpr uint32_t None = std::numeric_limits<uint32_t>::max();
    struct Line
    {
        uint64_t address = 0;
        uint64_t grow = 0;
        int32_t head = -1;
        int32_t tail = -1;
        uint32_t words = 0;
        uint32_t slice = 0;
        uint32_t next = None;
        uint32_t claimed = 0;
    };
    static_assert(sizeof(Line) == 40);
    struct Lookup
    {
        uint32_t slot = None;
        uint32_t probes = 0;
        uint32_t occupiedLineReads = 0;
        uint64_t metadataReads() const {
            return uint64_t(probes) + occupiedLineReads;
        }
    };

    enum class Policy : uint32_t { Sorted = 0, RowGroup = 2 };
    Policy policy() const { return Policy(slices_ >> 30); }
    const char *policyName() const {
        return policy() == Policy::RowGroup ? "row_group" : "sorted";
    }
    bool begin(uint32_t logical, uint32_t slices,
               Policy selected = Policy::Sorted) {
        if (active_ || logical > Capacity ||
            slices == 0 || slices > MaxSlices ||
            (selected != Policy::Sorted && selected != Policy::RowGroup))
            return false;
        hash.fill(None);
        heads.fill(None);
        tails.fill(None);
        cursors.fill(None);
        logical_ = logical;
        slices_ = slices | (uint32_t(selected) << 30);
        lines_ = descriptors_ = rejected_ = claimed_ = 0;
        probes_ = occupied_line_reads_ = 0;
        comparisons_ = swaps_ = 0;
        closed_ = false;
        active_ = true;
        return true;
    }
    Lookup lookup(uint64_t address, uint64_t grow, uint32_t slice) const {
        Lookup result;
        if (!active_ || closed_ || slice >= (slices_ & 0x3fffffff))
            return result;
        // Only translated physical line addresses are keys. Slice/grow are
        // checked too, so a changed mapping cannot append to another owner.
        uint64_t key = address >> 6;
        key ^= key >> 30;
        key *= 0xbf58476d1ce4e5b9ULL;
        key ^= key >> 27;
        key *= 0x94d049bb133111ebULL;
        key ^= key >> 31;
        uint32_t slot = key & (HashSlots - 1);
        for (uint32_t n = 0; n < HashSlots; ++n) {
            ++result.probes;
            const uint32_t id = hash[slot];
            // One hash-ID transfer, then one dependent packed Line read.
            // Empty slots do not perform the second transfer. A collision
            // cannot hide arbitrarily many Line reads in a fixed budget.
            if (id != None)
                ++result.occupiedLineReads;
            if (id == None || (records[id].address == address &&
                records[id].grow == grow && records[id].slice == slice)) {
                result.slot = slot;
                return result;
            }
            slot = (slot + 1) & (HashSlots - 1);
        }
        return result;
    }
    int lastOffset(const Lookup &found) const {
        if (found.slot >= HashSlots || hash[found.slot] == None)
            return -1;
        return records[hash[found.slot]].tail;
    }
    // Call only after the existing OffsetTable insertion succeeds. The
    // preflight ensures commit cannot fail after mutating that chain.
    bool canInsert(const Lookup &found) const {
        return active_ && !closed_ && descriptors_ + rejected_ < logical_ &&
            found.slot < HashSlots && found.probes != 0 &&
            (hash[found.slot] != None || lines_ < Capacity);
    }
    bool insert(const Lookup &found, uint64_t address, uint64_t grow,
                uint32_t slice, int offset, bool &first) {
        first = false;
        if (!canInsert(found) || slice >= (slices_ & 0x3fffffff) || offset < 0)
            return false;
        uint32_t id = hash[found.slot];
        if (id == None) {
            first = true;
            id = lines_++;
            hash[found.slot] = id;
            records[id] = Line{address, grow, offset, offset, 1, slice,
                               None, 0};
            if (tails[slice] == None)
                heads[slice] = id;
            else
                records[tails[slice]].next = id;
            tails[slice] = id;
        } else {
            auto &line = records[id];
            if (line.address != address || line.grow != grow ||
                line.slice != slice || line.claimed)
                return false;
            line.tail = offset;
            ++line.words;
        }
        ++descriptors_;
        probes_ += found.probes;
        occupied_line_reads_ += found.occupiedLineReads;
        return true;
    }
    bool reject() {
        if (!active_ || closed_ || descriptors_ + rejected_ >= logical_)
            return false;
        ++rejected_;
        return true;
    }
    bool close(uint32_t offsets, bool feederEmpty) {
        if (!active_ || closed_ || !feederEmpty ||
            descriptors_ + rejected_ != logical_ || offsets != descriptors_)
            return false;
        if (policy() == Policy::RowGroup) {
        // Reuse the no-longer-needed address hash as a finite grow hash.
        // No record moves: Offset heads/tails and ordinal chains stay intact.
        comparisons_ = swaps_ = 0;
        for (uint32_t i = 0; i < HashSlots; ++i) writeGroupHash(i, None);
        for (uint32_t id = 0; id < lines_; ++id) {
            Line line = readGroupLine(id);
            line.next = None;
            line.claimed = 0;
            uint64_t key = line.grow ^ (uint64_t(line.slice) << 32);
            key ^= key >> 30; key *= 0xbf58476d1ce4e5b9ULL;
            key ^= key >> 27; key *= 0x94d049bb133111ebULL;
            key ^= key >> 31;
            uint32_t slot = key & (HashSlots - 1);
            bool linked = false;
            for (uint32_t probe = 0; probe < HashSlots; ++probe) {
                const uint32_t first = readGroupHash(slot);
                if (first == None) {
                    // Only group headers temporarily hold tail+1 in claimed.
                    line.claimed = id + 1;
                    writeGroupHash(slot, id);
                    linked = true;
                    break;
                }
                Line head = readGroupLine(first);
                if (head.slice == line.slice && head.grow == line.grow) {
                    const uint32_t tail = head.claimed - 1;
                    if (tail == first) {
                        head.next = id;
                    } else {
                        Line last = readGroupLine(tail);
                        last.next = id;
                        writeGroupLine(tail, last);
                    }
                    head.claimed = id + 1;
                    writeGroupLine(first, head);
                    linked = true;
                    break;
                }
                slot = (slot + 1) & (HashSlots - 1);
            }
            if (!linked) return false; // At most Capacity groups/HashSlots=2C.
            writeGroupLine(id, line);
        }
        for (uint32_t s = 0; s < MaxSlices; ++s) {
            heads[s] = tails[s] = cursors[s] = None;
            swaps_ += 3;
        }
        for (uint32_t id = 0; id < lines_; ++id) {
            Line head = readGroupLine(id);
            if (head.claimed == 0) continue;
            const uint32_t tail = head.claimed - 1;
            const uint32_t previous = tails[head.slice];
            ++comparisons_;
            if (previous == None) {
                heads[head.slice] = id;
                ++swaps_;
            } else {
                Line last = readGroupLine(previous);
                last.next = id;
                writeGroupLine(previous, last);
            }
            tails[head.slice] = tail;
            ++swaps_;
            head.claimed = 0;
            writeGroupLine(id, head);
        }
        for (uint32_t s = 0; s < MaxSlices; ++s) {
            cursors[s] = heads[s];
            ++comparisons_; ++swaps_;
        }
            closed_ = true;
            return true;
        }
        // In-place bounded heapsort exposes the complete admitted window to
        // bank/DRAM-row-directed scheduling. It uses one Line of scratch,
        // no recursion and no separate index or address copy.
        for (uint32_t root = lines_ / 2; root > 0; --root)
            sift(root - 1, lines_);
        for (uint32_t end = lines_; end > 1; --end) {
            swap(0, end - 1);
            sift(0, end - 1);
        }
        heads.fill(None);
        tails.fill(None);
        cursors.fill(None);
        for (uint32_t id = 0; id < lines_; ++id) {
            auto &line = records[id];
            line.next = None;
            if (tails[line.slice] == None)
                heads[line.slice] = id;
            else
                records[tails[line.slice]].next = id;
            tails[line.slice] = id;
        }
        cursors = heads;
        closed_ = true;
        return true;
    }
    bool claim(uint32_t slice, uint64_t &address, int &head, int &words,
               bool commit) {
        if (!active_ || !closed_ || slice >= (slices_ & 0x3fffffff) ||
            cursors[slice] == None)
            return false;
        auto &line = records[cursors[slice]];
        if (line.claimed)
            return false;
        address = line.address;
        head = line.head;
        words = line.words;
        if (commit) {
            line.claimed = 1;
            claimed_ += line.words;
            cursors[slice] = line.next;
        }
        return true;
    }
    // Caller also checks existing source reservations, OffsetTable closure,
    // result payload limits and exact backing WriteResp gates before finish.
    bool finish() {
        if (!active_ || !closed_ || claimed_ != descriptors_)
            return false;
        active_ = false;
        return true;
    }
    bool active() const { return active_; }
    bool closed() const { return closed_; }
    uint32_t descriptors() const { return descriptors_; }
    uint32_t rejected() const { return rejected_; }
    uint32_t lines() const { return lines_; }
    uint64_t probes() const { return probes_; }
    uint64_t occupiedLineReads() const { return occupied_line_reads_; }
    uint64_t lookupReads() const { return probes_ + occupied_line_reads_; }
    uint64_t sortComparisons() const { return policy() == Policy::Sorted ? comparisons_ : 0; }
    uint64_t sortSwaps() const { return policy() == Policy::Sorted ? swaps_ : 0; }
    uint64_t policyCloseReads() const {
        return policy() == Policy::RowGroup ? comparisons_ : 0;
    }
    uint64_t policyCloseWrites() const {
        return policy() == Policy::RowGroup ? swaps_ : 0;
    }
    // Same new-model reservation for both policies, before line count is known.
    static constexpr uint64_t reservedScratchBytes() { return 3 * sizeof(Line); }
    uint64_t usedScratchBytes() const {
        return policy() == Policy::RowGroup ? 3 * sizeof(Line) : sizeof(Line);
    }
    uint64_t closeAccesses() const {
        if (policy() != Policy::Sorted)
            return policyCloseReads() + policyCloseWrites();
        // One serial metadata port: two record reads per comparison,
        // six transfers per swap including the charged scratch record;
        // Historical 4S convention: two necessary heads/tails clears plus
        // one head read and one cursor write per slice. The close-time
        // cursors.fill(None) in the unchanged sorted path is dead:
        // no legal read precedes cursors=heads, and claim rejects !closed_.
        // Keep both the historical C++ clear and its accepted timing formula.
        return 2 * comparisons_ + 6 * swaps_ + 4 * MaxSlices + 6 * lines_;
    }
    static constexpr uint64_t scratchBytes() { return sizeof(Line); }
    static constexpr uint64_t arrayBytes() {
        return sizeof(Line) * Capacity + sizeof(uint32_t) * HashSlots +
            3 * sizeof(uint32_t) * MaxSlices;
    }

  private:
    // Reuse the existing counter words only while the selected policy does not
    // sort. Policy is packed in unused high bits of slices_: no extra SRAM.
    // Each full record transfer also charges its scratch write/read, matching
    // the existing heap scratch convention. At most three Line scratch slots.
    Line readGroupLine(uint32_t id) {
        ++comparisons_; ++swaps_; return records[id];
    }
    void writeGroupLine(uint32_t id, const Line &line) {
        ++comparisons_; ++swaps_; records[id] = line;
    }
    uint32_t readGroupHash(uint32_t id) {
        ++comparisons_; return hash[id];
    }
    void writeGroupHash(uint32_t id, uint32_t value) {
        ++swaps_; hash[id] = value;
    }
    bool less(uint32_t a, uint32_t b) {
        ++comparisons_;
        const auto &x = records[a];
        const auto &y = records[b];
        if (x.slice != y.slice) return x.slice < y.slice;
        if (x.grow != y.grow) return x.grow < y.grow;
        return x.address < y.address;
    }
    void swap(uint32_t a, uint32_t b) {
        const Line scratch = records[a];
        records[a] = records[b];
        records[b] = scratch;
        ++swaps_;
    }
    void sift(uint32_t root, uint32_t end) {
        while (root < end / 2) {
            uint32_t child = root * 2 + 1;
            if (child + 1 < end && less(child, child + 1)) ++child;
            if (!less(root, child)) break;
            swap(root, child);
            root = child;
        }
    }
    std::array<Line, Capacity> records{};
    std::array<uint32_t, HashSlots> hash{};
    std::array<uint32_t, MaxSlices> heads{}, tails{}, cursors{};
    uint64_t probes_ = 0, occupied_line_reads_ = 0;
    uint64_t comparisons_ = 0, swaps_ = 0;
    uint32_t logical_ = 0, slices_ = 0, lines_ = 0, descriptors_ = 0;
    uint32_t rejected_ = 0, claimed_ = 0;
    bool active_ = false, closed_ = false;
};
} // namespace gem5::maa
#endif
