#ifndef UME_SHARED_PROGRESS_STATE_HH
#define UME_SHARED_PROGRESS_STATE_HH
#include <array>
#include <cstdint>
#include <limits>
namespace gem5::maa {
// Fixed transaction storage; existing physical cache capacity remains 4x64.
// MSHR ownership survives early responses, clones and deferred/locked targets.
template<class Ref> class SharedProgressState {
 public:
 using Token=std::uint64_t;
 enum class Phase { Empty, Reserved, Sending, Accepted };
 enum class Result { Granted, Pressure, Invalid, HandoffBusy };
 static constexpr unsigned Banks=4, Entries=2048, Deferred=64, Targets=7;
 struct Cell {
  Ref request{},clone{};Token token=0,parent=0;std::uint64_t line=0;
  std::uintptr_t mshr=0;unsigned bank=0,port=0;
  Phase phase=Phase::Empty;
  bool secure=false,producer=false,spd=false,physical=false,receiver=false,handoff=false;
  bool response=false,responseBeforeHandoff=false,clonePending=false,internal=false,delivering=false;
 };
 private:
 std::array<Cell,Entries> cells{};
 std::array<unsigned,Banks> physical{},ordinary{};
 std::array<bool,16> waiters{};
 unsigned deferred=0,used=0,ordinaryTransactions=0,handoffs=0,deliveries=0;
 Token next=1;bool wake=false;
 static bool same(const Ref&a,const Ref&b){return a&&b&&a.get()==b.get()&&!a.owner_before(b)&&!b.owner_before(a);}
 bool bound(const Cell&c,const Ref&r)const{return same(c.request,r)||same(c.clone,r);}
 Cell*find(Token t){for(auto&c:cells)if(t&&c.token==t)return &c;return nullptr;}
 const Cell*find(Token t)const{for(const auto&c:cells)if(t&&c.token==t)return &c;return nullptr;}
 void releasePhysical(Cell&c){if(c.physical){--physical[c.bank];if(!c.producer)--ordinary[c.bank];c.physical=false;wake=true;}}
 void erase(Cell&c){releasePhysical(c);if(c.spd)--deferred;if(!c.producer)--ordinaryTransactions;--used;c={};wake=true;}
 void settle(){if(handoffs||deliveries)return;for(auto&c:cells)if(c.phase==Phase::Accepted&&c.response&&!c.receiver&&!c.handoff&&!c.mshr&&!c.clonePending)erase(c);}
 public:
 Result reserve(const Ref&r,unsigned bank,std::uint64_t line,bool producer,bool spd,unsigned port,Token parent,bool continuation,bool internal,Token&out,bool secure=false){
  out=0;if(!r||bank>=Banks||port>=Banks||line%64||(producer&&spd))return Result::Invalid;
  if(handoffs||deliveries)return Result::HandoffBusy;
  const Cell*pc=parent?find(parent):nullptr;
  if(parent&&(!pc||!pc->mshr||pc->bank!=bank||pc->line!=line||pc->secure!=secure))return Result::Invalid;
  // A locked write releases its existing target; it is not another deferred read.
  if(continuation){if(!pc)return Result::Invalid;if(!pc->response)return Result::Pressure;spd=false;}
  for(const auto&c:cells)if(c.phase!=Phase::Empty&&bound(c,r)){
   if(!(continuation&&parent==c.token&&c.response&&c.mshr))return Result::Invalid;
  }
  if(used==Entries||(!producer&&!continuation&&ordinaryTransactions>=Entries-4))return Result::Pressure;
  if(!parent&&(physical[bank]>=64||(!producer&&ordinary[bank]>=63)))return Result::Pressure;
  if(spd&&deferred==Deferred)return Result::Pressure;
  unsigned targets=0;for(const auto&c:cells)if(c.phase!=Phase::Empty&&c.spd&&c.line==line&&c.secure==secure)++targets;
  if(spd&&targets>=Targets)return Result::Pressure;
  if(next==std::numeric_limits<Token>::max())return Result::Invalid;
  for(auto&c:cells)if(c.phase==Phase::Empty){
   c.request=r;c.token=next++;c.parent=parent;c.line=line;c.bank=bank;c.port=port;
   c.phase=Phase::Reserved;c.secure=secure;c.producer=producer;c.spd=spd;c.physical=!parent;c.internal=internal;
   ++used;if(!producer)++ordinaryTransactions;if(spd)++deferred;
   if(c.physical){++physical[bank];if(!producer)++ordinary[bank];}
   out=c.token;return Result::Granted;
  }
  return Result::Invalid;
 }
 Token active(const Ref&r)const{
  Token found=0;for(const auto&c:cells)if(c.phase!=Phase::Empty&&bound(c,r)&&!c.response){if(found)return 0;found=c.token;}return found;
 }
 Result beginSend(Token t){auto*c=find(t);if(!c||c->phase!=Phase::Reserved)return Result::Invalid;c->phase=Phase::Sending;return Result::Granted;}
 Result finishSend(Token t,bool accepted){auto*c=find(t);if(!c||c->phase!=Phase::Sending)return Result::Invalid;
  if(!accepted){if(c->receiver||c->handoff||c->delivering||c->response||c->mshr||c->clonePending)return Result::Invalid;erase(*c);return Result::Granted;}
  c->phase=Phase::Accepted;settle();return Result::Granted;
 }
 Result attachClone(const Ref&original,const Ref&clone){auto*c=find(active(original));if(!c||!clone||c->clone||c->clonePending||(c->phase!=Phase::Sending&&c->phase!=Phase::Accepted))return Result::Invalid;c->clone=clone;c->clonePending=true;return Result::Granted;}
 Result bindMshr(const Ref&r,std::uintptr_t mshr){Cell*c=nullptr;
  for(auto&x:cells)if((x.phase==Phase::Sending||x.phase==Phase::Accepted)&&bound(x,r)&&x.physical&&!x.mshr){if(c)return Result::Invalid;c=&x;}
  if(!c||!mshr)return Result::Invalid;
  for(const auto&x:cells)if(x.mshr==mshr)return Result::Invalid;
  c->mshr=mshr;c->clonePending=false;return Result::Granted;
 }
 Token mshrOwner(std::uintptr_t mshr)const{for(const auto&c:cells)if(c.mshr==mshr&&mshr)return c.token;return 0;}
 Result releaseMshr(std::uintptr_t mshr){auto*c=find(mshrOwner(mshr));if(!c)return Result::Invalid;c->mshr=0;releasePhysical(*c);settle();return Result::Granted;}
 Token authorize(const Ref&r,std::uint64_t line,unsigned port)const{
  for(const auto&c:cells)if(bound(c,r)&&c.spd&&c.line==line&&c.port==port&&!c.receiver&&(c.phase==Phase::Sending||c.phase==Phase::Accepted))return c.token;
  return 0;
 }
 Result receiverOwns(const Ref&r,Token t,unsigned port){auto*c=find(t);if(!c||!bound(*c,r)||!c->spd||c->port!=port||c->receiver||(c->phase!=Phase::Sending&&c->phase!=Phase::Accepted))return Result::Invalid;c->receiver=true;return Result::Granted;}
 Result beginResponse(const Ref&r,Token t,unsigned port){auto*c=find(t);if(!c||!bound(*c,r)||c->port!=port||!c->receiver||c->handoff)return Result::Invalid;c->handoff=true;c->responseBeforeHandoff=c->response;++handoffs;return Result::Granted;}
 Result endResponse(const Ref&r,Token t,unsigned port,bool accepted){auto*c=find(t);if(!c||!bound(*c,r)||c->port!=port||!c->handoff||!handoffs||(!accepted&&c->response&&!c->responseBeforeHandoff))return Result::Invalid;
  if(accepted)c->receiver=false;
  c->handoff=false;--handoffs;settle();
  if(!handoffs&&!deliveries)for(bool w:waiters)if(w){wake=true;break;}
  return Result::Granted;
 }
 // General response delivery may reenter admission before the peer returns.
 // Retain the original Request and token until success/refusal is known. Neither
 // local receiver capacity nor shared credits may retire during either barrier.
 Result beginDelivery(const Ref&r,Token t){auto*c=find(t);
  if(!c||!bound(*c,r)||c->response||c->delivering||(c->phase!=Phase::Sending&&c->phase!=Phase::Accepted))return Result::Invalid;
  c->delivering=true;++deliveries;return Result::Granted;
 }
 Result finishDelivery(const Ref&r,Token t,bool accepted){auto*c=find(t);
  if(!c||!bound(*c,r)||!c->delivering||!deliveries||c->response)return Result::Invalid;
  if(accepted)c->response=true;
  c->delivering=false;--deliveries;settle();
  // Refusal also ends a barrier that may have registered a reentrant waiter.
  if(!handoffs&&!deliveries&&hasWaiters())wake=true;
  return Result::Granted;
 }
 Result responseAccepted(const Ref&r,Token t){auto*c=find(t);if(!c||!bound(*c,r)||c->response||c->delivering||(c->phase!=Phase::Sending&&c->phase!=Phase::Accepted))return Result::Invalid;c->response=true;settle();return Result::Granted;}
 Result internalComplete(const Ref&r){auto*c=find(active(r));if(!c||!c->internal)return Result::Invalid;return responseAccepted(r,c->token);}
 bool isInternal(const Ref&r)const{const auto*c=find(active(r));return c&&c->internal;}
 bool setWaiter(unsigned i){if(i>=waiters.size())return false;waiters[i]=true;return true;}
 bool waiting(unsigned i)const{return i<waiters.size()&&waiters[i];}
 bool takeWaiter(unsigned i){if(!waiting(i))return false;waiters[i]=false;return true;}
 bool hasWaiters()const{for(bool w:waiters)if(w)return true;return false;}
 void changed(){if(hasWaiters())wake=true;}
 bool wakeNeeded()const{return wake&&!handoffs&&!deliveries;}
 bool consumeWake(){if(handoffs||deliveries)return false;wake=false;return true;}
 bool quiescent()const{return !used&&!handoffs&&!deliveries&&!wake&&!hasWaiters();}
 unsigned bankUsed(unsigned i)const{return physical.at(i);}
 unsigned deferredUsed()const{return deferred;}
 unsigned transactionCount()const{return used;}
};
}
#endif
