#ifndef UME_DEFERRED_SPD_OWNERS_HH
#define UME_DEFERRED_SPD_OWNERS_HH
#include "mem/request.hh"
#include "mem/MAA/DeferredOwnerPool.hh"
namespace gem5::maa { using DeferredSpdOwners = DeferredOwnerPool<RequestPtr>; }
#endif
