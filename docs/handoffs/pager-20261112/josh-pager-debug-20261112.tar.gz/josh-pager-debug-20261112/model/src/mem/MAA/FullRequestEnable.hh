#ifndef UME_FULL_REQUEST_ENABLE_HH
#define UME_FULL_REQUEST_ENABLE_HH
#include <cstdint>
#include <limits>
namespace gem5::maa {
template<class Mask>
bool fullRequestEnabled(const Mask &mask,bool hasPaddr,bool hasSize,
    std::uint64_t requestAddr,std::uint64_t requestSize,
    std::uint64_t packetAddr,std::uint64_t packetSize,
    bool cacheLineRead,std::uint64_t cacheLineSize)
{
 if(!hasPaddr||!hasSize||!requestSize||!packetSize||mask.size()!=requestSize)return false;
 for(bool enabled:mask)if(!enabled)return false;
 const auto max=std::numeric_limits<std::uint64_t>::max();
 if(requestSize-1>max-requestAddr||packetSize-1>max-packetAddr)return false;
 if(cacheLineRead){if(!cacheLineSize||packetSize!=cacheLineSize||packetAddr%cacheLineSize)return false;}
 else if(requestSize!=packetSize||requestAddr!=packetAddr)return false;
 return requestAddr>=packetAddr&&requestSize<=packetSize&&requestAddr-packetAddr<=packetSize-requestSize;
}
}
#endif
