#ifndef __MEM_MAA_INLINE_LOGICAL_ROW_TAG_HH__
#define __MEM_MAA_INLINE_LOGICAL_ROW_TAG_HH__

#include <cstdint>

namespace gem5
{
namespace maa
{

/**
 * Packs physical and logical cache-line identity into the existing 64-bit
 * RowTable line tag. The fixed 2-GiB/64-byte geometry needs 25 bits for each
 * identity, so inline retirement does not add another hardware field.
 */
class InlineLogicalRowTag
{
  public:
    static constexpr uint8_t LineShift = 6;
    static constexpr uint8_t PhysicalLineBits = 25;
    static constexpr uint8_t LogicalLineBits = 25;
    static constexpr uint64_t PhysicalLineMask =
        (uint64_t{1} << PhysicalLineBits) - 1;
    static constexpr uint64_t LogicalLineMask =
        (uint64_t{1} << LogicalLineBits) - 1;
    static constexpr uint64_t EncodedMask =
        PhysicalLineMask | (LogicalLineMask << PhysicalLineBits);
    static constexpr uint64_t IncrementalStorageBytes = 0;

    static bool
    encode(uint64_t physical_address, uint64_t logical_line,
           uint64_t &tag)
    {
        if ((physical_address & ((uint64_t{1} << LineShift) - 1)) != 0 ||
            (physical_address >> LineShift) > PhysicalLineMask ||
            logical_line > LogicalLineMask) {
            return false;
        }
        tag = (logical_line << PhysicalLineBits) |
            (physical_address >> LineShift);
        return true;
    }

    static bool valid(uint64_t tag) { return (tag & ~EncodedMask) == 0; }

    static uint64_t
    physicalAddress(uint64_t tag)
    {
        return (tag & PhysicalLineMask) << LineShift;
    }

    static uint32_t
    logicalLine(uint64_t tag)
    {
        return static_cast<uint32_t>(
            (tag >> PhysicalLineBits) & LogicalLineMask);
    }

    static bool
    logicalWord(uint64_t tag, uint16_t word, uint16_t words_per_line,
                uint16_t base_word_offset, uint64_t logical_words,
                uint32_t &destination)
    {
        if (!valid(tag) || words_per_line == 0 || word >= words_per_line ||
            base_word_offset >= words_per_line) {
            return false;
        }
        const uint64_t aligned_word =
            static_cast<uint64_t>(logicalLine(tag)) * words_per_line + word;
        if (aligned_word < base_word_offset)
            return false;
        const uint64_t logical_word = aligned_word - base_word_offset;
        if (logical_word >= logical_words || logical_word > UINT32_MAX)
            return false;
        destination = static_cast<uint32_t>(logical_word);
        return true;
    }
};

static_assert(InlineLogicalRowTag::PhysicalLineBits +
                  InlineLogicalRowTag::LogicalLineBits <=
              64);
static_assert(InlineLogicalRowTag::IncrementalStorageBytes == 0);

} // namespace maa
} // namespace gem5

#endif // __MEM_MAA_INLINE_LOGICAL_ROW_TAG_HH__
