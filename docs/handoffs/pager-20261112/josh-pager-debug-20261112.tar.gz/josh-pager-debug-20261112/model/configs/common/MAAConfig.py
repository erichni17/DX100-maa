from common import ObjectList
from common.MAA import *

import m5
from m5.objects import *

from gem5.isas import ISA


def _get_maa_opts(options):
    opts = {}

    if hasattr(options, "maa_num_tiles_per_core"):
        opts["num_tiles_per_core"] = getattr(options, "maa_num_tiles_per_core")

    if hasattr(options, "maa_num_tile_elements"):
        opts["num_tile_elements"] = getattr(options, "maa_num_tile_elements")

    if hasattr(options, "maa_physical_tile_elements"):
        opts["physical_tile_elements"] = getattr(
            options, "maa_physical_tile_elements"
        )

    if hasattr(options, "maa_transparent_spd_mode"):
        opts["transparent_spd_mode"] = getattr(
            options, "maa_transparent_spd_mode"
        )

    if hasattr(options, "maa_logical_spd_cache_mode"):
        opts["logical_spd_cache_mode"] = getattr(
            options, "maa_logical_spd_cache_mode"
        )

    if getattr(options, "maa_device_owned_spd_paging", False):
        assert opts.get("logical_spd_cache_mode", 0) == 0
        assert 3 <= options.maa_device_owned_spd_frames <= 32
        opts["logical_spd_cache_mode"] = (
            options.maa_device_owned_spd_frames + 1
        )
        if getattr(options, "maa_device_owned_spd_fixed_map", False):
            assert options.maa_device_owned_spd_frames == 32
            assert not getattr(options, "maa_device_owned_spd_overlap", False)
            opts["logical_spd_cache_mode"] = 65
        if getattr(options, "maa_device_owned_spd_overlap", False):
            assert options.maa_device_owned_spd_frames == 32
            opts["logical_spd_cache_mode"] = 97
    else:
        assert not getattr(options, "maa_device_owned_spd_overlap", False)
        assert not getattr(options, "maa_device_owned_spd_fixed_map", False)

    if hasattr(options, "maa_logical_tile_page_scheduler"):
        opts["logical_tile_page_scheduler"] = getattr(
            options, "maa_logical_tile_page_scheduler"
        )

    if hasattr(options, "maa_page_fed_soa_jit"):
        opts["page_fed_soa_jit"] = getattr(options, "maa_page_fed_soa_jit")

    if hasattr(options, "maa_inline_variable_retirement"):
        opts[
            "inline_variable_retirement"
        ] = options.maa_inline_variable_retirement
    if hasattr(options, "maa_inline_operand_page_fed_rmw"):
        opts["inline_operand_page_fed_rmw"] = getattr(
            options, "maa_inline_operand_page_fed_rmw"
        )

    if hasattr(options, "maa_num_regs_per_core"):
        opts["num_regs_per_core"] = getattr(options, "maa_num_regs_per_core")

    if hasattr(options, "maa_num_instructions_per_core"):
        opts["num_instructions_per_core"] = getattr(
            options, "maa_num_instructions_per_core"
        )

    if hasattr(options, "maa_num_row_table_rows_per_slice"):
        opts["num_row_table_rows_per_slice"] = getattr(
            options, "maa_num_row_table_rows_per_slice"
        )

    if hasattr(options, "maa_num_offset_table_entries"):
        opts["num_offset_table_entries"] = getattr(
            options, "maa_num_offset_table_entries"
        )

    if hasattr(options, "maa_num_offset_table_epoch_entries"):
        opts["num_offset_table_epoch_entries"] = getattr(
            options, "maa_num_offset_table_epoch_entries"
        )

    if hasattr(options, "maa_num_row_table_entries_per_subslice_row"):
        opts["num_row_table_entries_per_subslice_row"] = getattr(
            options, "maa_num_row_table_entries_per_subslice_row"
        )

    if hasattr(options, "maa_num_row_table_config_cache_entries"):
        opts["num_row_table_config_cache_entries"] = getattr(
            options, "maa_num_row_table_config_cache_entries"
        )

    if hasattr(options, "maa_reconfigure_row_table"):
        opts["reconfigure_row_table"] = getattr(
            options, "maa_reconfigure_row_table"
        )

    if hasattr(options, "maa_no_reorder"):
        opts["no_reorder"] = getattr(options, "maa_no_reorder")

    if hasattr(options, "maa_force_cache_access"):
        opts["force_cache_access"] = getattr(options, "maa_force_cache_access")

    if hasattr(options, "maa_num_initial_row_table_slices"):
        opts["num_initial_row_table_slices"] = getattr(
            options, "maa_num_initial_row_table_slices"
        )

    if hasattr(options, "maa_virtual_combine_slots"):
        opts["virtual_combine_slots"] = getattr(
            options, "maa_virtual_combine_slots"
        )

    if hasattr(options, "maa_virtual_combine_words"):
        opts["virtual_combine_words"] = getattr(
            options, "maa_virtual_combine_words"
        )

    if hasattr(options, "maa_virtual_shared_result_payload"):
        opts["virtual_shared_result_payload"] = getattr(
            options, "maa_virtual_shared_result_payload"
        )

    if hasattr(options, "maa_virtual_combine_ways"):
        opts["virtual_combine_ways"] = getattr(
            options, "maa_virtual_combine_ways"
        )

    if hasattr(options, "maa_virtual_combine_set_xor_shift"):
        opts["virtual_combine_set_xor_shift"] = getattr(
            options, "maa_virtual_combine_set_xor_shift"
        )

    if hasattr(options, "maa_virtual_combine_victim_policy"):
        opts["virtual_combine_victim_policy"] = getattr(
            options, "maa_virtual_combine_victim_policy"
        )

    if hasattr(options, "maa_virtual_page_ordered_combiner_drain"):
        opts["virtual_page_ordered_combiner_drain"] = getattr(
            options, "maa_virtual_page_ordered_combiner_drain"
        )

    if hasattr(options, "maa_virtual_complete_line_drain_lines_per_cycle"):
        opts["virtual_complete_line_drain_lines_per_cycle"] = getattr(
            options, "maa_virtual_complete_line_drain_lines_per_cycle"
        )

    if hasattr(options, "maa_virtual_complete_line_payload_words_per_cycle"):
        opts["virtual_complete_line_payload_words_per_cycle"] = getattr(
            options, "maa_virtual_complete_line_payload_words_per_cycle"
        )

    if hasattr(options, "maa_virtual_complete_line_payload_active_lines"):
        opts["virtual_complete_line_payload_active_lines"] = getattr(
            options, "maa_virtual_complete_line_payload_active_lines"
        )

    if hasattr(options, "maa_virtual_complete_line_payload_banks"):
        opts["virtual_complete_line_payload_banks"] = getattr(
            options, "maa_virtual_complete_line_payload_banks"
        )

    if hasattr(options, "maa_virtual_complete_line_payload_stage_partial"):
        opts["virtual_complete_line_payload_stage_partial"] = getattr(
            options, "maa_virtual_complete_line_payload_stage_partial"
        )

    if hasattr(options, "maa_virtual_combine_banks"):
        opts["virtual_combine_banks"] = getattr(
            options, "maa_virtual_combine_banks"
        )

    if hasattr(options, "maa_virtual_response_slots"):
        opts["virtual_response_slots"] = getattr(
            options, "maa_virtual_response_slots"
        )

    if hasattr(options, "maa_virtual_response_words"):
        opts["virtual_response_words"] = getattr(
            options, "maa_virtual_response_words"
        )

    if hasattr(options, "maa_virtual_response_word_pool"):
        opts["virtual_response_word_pool"] = getattr(
            options, "maa_virtual_response_word_pool"
        )

    if hasattr(options, "maa_virtual_combine_lookup_capacity"):
        opts["virtual_combine_lookup_capacity"] = getattr(
            options, "maa_virtual_combine_lookup_capacity"
        )

    if hasattr(options, "maa_virtual_combine_lookup_latency_cycles"):
        opts["virtual_combine_lookup_latency_cycles"] = getattr(
            options, "maa_virtual_combine_lookup_latency_cycles"
        )

    if hasattr(options, "maa_virtual_words_per_cycle"):
        opts["virtual_words_per_cycle"] = getattr(
            options, "maa_virtual_words_per_cycle"
        )

    if hasattr(options, "maa_virtual_max_outstanding_writes"):
        opts["virtual_max_outstanding_writes"] = getattr(
            options, "maa_virtual_max_outstanding_writes"
        )

    if hasattr(options, "maa_virtual_masked_writes"):
        opts["virtual_masked_writes"] = getattr(
            options, "maa_virtual_masked_writes"
        )

    if hasattr(options, "maa_virtual_dense_write_allocate"):
        opts["virtual_dense_write_allocate"] = getattr(
            options, "maa_virtual_dense_write_allocate"
        )

    if hasattr(options, "maa_virtual_complete_line_only"):
        opts["virtual_complete_line_only"] = getattr(
            options, "maa_virtual_complete_line_only"
        )

    if hasattr(options, "maa_virtual_idealized_write_ack"):
        opts["virtual_idealized_write_ack"] = getattr(
            options, "maa_virtual_idealized_write_ack"
        )

    if hasattr(options, "maa_direct_retirement_line_handoff"):
        opts["direct_retirement_line_handoff"] = getattr(
            options, "maa_direct_retirement_line_handoff"
        )

    if hasattr(options, "maa_page_materialization_wakeup_batches"):
        opts["page_materialization_wakeup_batches"] = getattr(
            options, "maa_page_materialization_wakeup_batches"
        )

    if hasattr(options, "maa_page_materialization_fragment_buffers"):
        opts["page_materialization_fragment_buffers"] = getattr(
            options, "maa_page_materialization_fragment_buffers"
        )

    if hasattr(options, "maa_page_materialization_direct_spd_fragments"):
        opts["page_materialization_direct_spd_fragments"] = getattr(
            options, "maa_page_materialization_direct_spd_fragments"
        )

    if hasattr(options, "maa_inactive_page_payload_capture_lines"):
        opts["inactive_page_payload_capture_lines"] = getattr(
            options, "maa_inactive_page_payload_capture_lines"
        )

    if hasattr(options, "maa_inactive_page_payload_capture_conflict_policy"):
        opts["inactive_page_payload_capture_conflict_policy"] = getattr(
            options, "maa_inactive_page_payload_capture_conflict_policy"
        )

    if hasattr(options, "maa_inactive_page_masked_fragment_retention_lines"):
        opts["inactive_page_masked_fragment_retention_lines"] = getattr(
            options, "maa_inactive_page_masked_fragment_retention_lines"
        )

    if hasattr(options, "maa_soa_jit_predicate_active_credits"):
        opts["soa_jit_predicate_active_credits"] = getattr(
            options, "maa_soa_jit_predicate_active_credits"
        )

    if hasattr(options, "maa_virtual_index_buffer_lines"):
        opts["virtual_index_buffer_lines"] = getattr(
            options, "maa_virtual_index_buffer_lines"
        )

    if hasattr(options, "maa_virtual_index_issue_lines_per_cycle"):
        opts["virtual_index_issue_lines_per_cycle"] = getattr(
            options, "maa_virtual_index_issue_lines_per_cycle"
        )

    if hasattr(options, "maa_soa_jit_active_contexts"):
        opts["soa_jit_active_contexts"] = getattr(
            options, "maa_soa_jit_active_contexts"
        )

    if hasattr(options, "maa_soa_jit_old_result_partial_credits"):
        opts["soa_jit_old_result_partial_credits"] = getattr(
            options, "maa_soa_jit_old_result_partial_credits"
        )

    if hasattr(options, "maa_soa_jit_old_result_pressure_policy"):
        opts["soa_jit_old_result_pressure_policy"] = getattr(
            options, "maa_soa_jit_old_result_pressure_policy"
        )

    if hasattr(options, "maa_soa_jit_value_lookahead"):
        opts["soa_jit_value_lookahead"] = getattr(
            options, "maa_soa_jit_value_lookahead"
        )

    if hasattr(options, "maa_soa_jit_value_cache_enable"):
        opts["soa_jit_value_cache_enable"] = getattr(
            options, "maa_soa_jit_value_cache_enable"
        )

    if hasattr(options, "maa_soa_jit_pre_a_value_lookahead"):
        opts["soa_jit_pre_a_value_lookahead"] = getattr(
            options, "maa_soa_jit_pre_a_value_lookahead"
        )

    if hasattr(options, "maa_soa_jit_value_prefetch_credits"):
        opts["soa_jit_value_prefetch_credits"] = getattr(
            options, "maa_soa_jit_value_prefetch_credits"
        )

    if hasattr(options, "maa_soa_jit_active_value_owners"):
        opts["soa_jit_active_value_owners"] = getattr(
            options, "maa_soa_jit_active_value_owners"
        )

    if hasattr(options, "maa_soa_jit_stock_service"):
        opts["soa_jit_stock_service"] = getattr(
            options, "maa_soa_jit_stock_service"
        )

    if hasattr(options, "maa_soa_jit_apply_lanes"):
        opts["soa_jit_apply_lanes"] = getattr(
            options, "maa_soa_jit_apply_lanes"
        )

    if hasattr(options, "maa_virtual_index_force_cache"):
        opts["virtual_index_force_cache"] = getattr(
            options, "maa_virtual_index_force_cache"
        )

    if hasattr(options, "maa_virtual_index_partitions"):
        opts["virtual_index_partitions"] = getattr(
            options, "maa_virtual_index_partitions"
        )

    if hasattr(options, "maa_virtual_index_range_passes"):
        opts["virtual_index_range_passes"] = getattr(
            options, "maa_virtual_index_range_passes"
        )

    if hasattr(options, "maa_virtual_index_descriptor_spool"):
        opts["virtual_index_descriptor_spool"] = getattr(
            options, "maa_virtual_index_descriptor_spool"
        )

    if hasattr(options, "maa_virtual_descriptor_spool_read_ahead"):
        opts["virtual_descriptor_spool_read_ahead"] = getattr(
            options, "maa_virtual_descriptor_spool_read_ahead"
        )

    if hasattr(options, "maa_virtual_descriptor_spool_read_credits"):
        opts["virtual_descriptor_spool_read_credits"] = getattr(
            options, "maa_virtual_descriptor_spool_read_credits"
        )

    if hasattr(options, "maa_virtual_descriptor_spool_write_credits"):
        opts["virtual_descriptor_spool_write_credits"] = getattr(
            options, "maa_virtual_descriptor_spool_write_credits"
        )

    if hasattr(options, "maa_virtual_descriptor_spool_source_bypass_cache"):
        opts["virtual_descriptor_spool_source_bypass_cache"] = getattr(
            options, "maa_virtual_descriptor_spool_source_bypass_cache"
        )

    if hasattr(options, "maa_virtual_bounded_global_merge"):
        opts["virtual_bounded_global_merge"] = getattr(
            options, "maa_virtual_bounded_global_merge"
        )

    if hasattr(options, "maa_virtual_pre_a_policy"):
        opts["virtual_pre_a_policy"] = options.maa_virtual_pre_a_policy
    if hasattr(options, "maa_virtual_pre_a_window"):
        opts["virtual_pre_a_window"] = options.maa_virtual_pre_a_window

    if hasattr(options, "maa_virtual_strict_two_phase"):
        opts["virtual_strict_two_phase"] = getattr(
            options, "maa_virtual_strict_two_phase"
        )

    if hasattr(options, "maa_virtual_index_range_policy"):
        opts["virtual_index_range_policy"] = getattr(
            options, "maa_virtual_index_range_policy"
        )

    if hasattr(options, "maa_virtual_index_range_boundaries"):
        opts["virtual_index_range_boundaries"] = getattr(
            options, "maa_virtual_index_range_boundaries"
        )

    if hasattr(options, "maa_virtual_index_filter_words_per_cycle"):
        opts["virtual_index_filter_words_per_cycle"] = getattr(
            options, "maa_virtual_index_filter_words_per_cycle"
        )

    if hasattr(options, "maa_virtual_partition_keep_combiner"):
        opts["virtual_partition_keep_combiner"] = getattr(
            options, "maa_virtual_partition_keep_combiner"
        )

    if hasattr(options, "maa_virtual_grow_order"):
        opts["virtual_grow_order"] = getattr(options, "maa_virtual_grow_order")

    if hasattr(options, "maa_virtual_native_issue_order"):
        opts["virtual_native_issue_order"] = getattr(
            options, "maa_virtual_native_issue_order"
        )

    if hasattr(options, "maa_num_request_table_addresses"):
        opts["num_request_table_addresses"] = getattr(
            options, "maa_num_request_table_addresses"
        )

    if hasattr(options, "maa_num_request_table_entries_per_address"):
        opts["num_request_table_entries_per_address"] = getattr(
            options, "maa_num_request_table_entries_per_address"
        )

    if hasattr(options, "maa_spd_read_latency"):
        opts["spd_read_latency"] = getattr(options, "maa_spd_read_latency")

    if hasattr(options, "maa_spd_write_latency"):
        opts["spd_write_latency"] = getattr(options, "maa_spd_write_latency")

    if hasattr(options, "maa_num_spd_read_ports_per_maa"):
        opts["num_spd_read_ports_per_maa"] = getattr(
            options, "maa_num_spd_read_ports_per_maa"
        )

    if hasattr(options, "maa_num_spd_write_ports_per_maa"):
        opts["num_spd_write_ports_per_maa"] = getattr(
            options, "maa_num_spd_write_ports_per_maa"
        )

    if hasattr(options, "maa_rowtable_latency"):
        opts["rowtable_latency"] = getattr(options, "maa_rowtable_latency")

    if hasattr(options, "maa_ALU_lane_latency"):
        opts["ALU_lane_latency"] = getattr(options, "maa_ALU_lane_latency")

    if hasattr(options, "maa_num_ALU_lanes"):
        opts["num_ALU_lanes"] = getattr(options, "maa_num_ALU_lanes")

    if hasattr(options, "maa_num_maas"):
        opts["num_maas"] = getattr(options, "maa_num_maas")

    if hasattr(options, "maa_num_indirect_units_per_maa"):
        opts["num_indirect_units_per_maa"] = getattr(
            options, "maa_num_indirect_units_per_maa"
        )

    opts["num_memory_channels"] = options.mem_channels
    opts["num_cores"] = options.num_cpus

    addr_ranges = []
    start = options.mem_size

    SPD_data_size = (
        opts["num_tiles_per_core"]
        * opts["num_cores"]
        * opts["num_tile_elements"]
        * 4
    )

    # scratchpad data (cacheable) (4 bytes each)
    addr_ranges.append(AddrRange(start=start, size=SPD_data_size))
    start = addr_ranges[-1].end

    # scratchpad data (noncacheable) (4 bytes each)
    addr_ranges.append(AddrRange(start=start, size=SPD_data_size))
    start = addr_ranges[-1].end

    # scratchpad size (noncacheable) (2 bytes each)
    SPD_size_size = opts["num_tiles_per_core"] * opts["num_cores"] * 2
    addr_ranges.append(AddrRange(start=start, size=SPD_size_size))
    start = addr_ranges[-1].end

    # scratchpad ready (noncacheable) (2 bytes each)
    SPD_ready_size = opts["num_tiles_per_core"] * opts["num_cores"] * 2
    addr_ranges.append(AddrRange(start=start, size=SPD_ready_size))
    start = addr_ranges[-1].end

    # scalar registers (noncacheable) (4 bytes each)
    scalar_regs_size = opts["num_regs_per_core"] * opts["num_cores"] * 4
    addr_ranges.append(AddrRange(start=start, size=scalar_regs_size))
    start = addr_ranges[-1].end

    # instruction file (noncacheable)
    instruction_file_size = 64
    addr_ranges.append(AddrRange(start=start, size=instruction_file_size))
    start = addr_ranges[-1].end

    # Per-completion-token readiness for up to sixteen virtual pages.
    virtual_page_ready_size = (
        opts["num_tiles_per_core"] * opts["num_cores"] * 16 * 2
    )
    addr_ranges.append(AddrRange(start=start, size=virtual_page_ready_size))
    start = addr_ranges[-1].end

    opts["addr_ranges"] = addr_ranges

    return opts


def _get_cache_opts(level, options):
    opts = {}

    size_attr = f"{level}_size"
    if hasattr(options, size_attr):
        opts["size"] = getattr(options, size_attr)

    return opts


def get_maa_address(options):
    opts = _get_maa_opts(options)
    start_cacheable_addr = opts["addr_ranges"][0].start
    start_noncacheable_addr = opts["addr_ranges"][1].start
    end_cacheable_addr = Addr(opts["addr_ranges"][0].end)
    end_noncacheable_addr = Addr(opts["addr_ranges"][-1].end)
    size_cacheable_addr = end_cacheable_addr - start_cacheable_addr
    size_noncacheable_addr = end_noncacheable_addr - start_noncacheable_addr
    print(
        f"MAA Address: cacheable ({start_cacheable_addr}-{end_cacheable_addr} : {size_cacheable_addr}), noncacheable ({start_noncacheable_addr}-{end_noncacheable_addr} : {size_noncacheable_addr})"
    )
    return (
        start_cacheable_addr,
        size_cacheable_addr,
        start_noncacheable_addr,
        size_noncacheable_addr,
    )


def config_maa(options, system):
    assert options.l3cache
    opts = _get_maa_opts(options)
    # Backward-compat: a config script can be newer than the compiled gem5 binary
    # (e.g. an A/B baseline built before a param like num_indirect_units_per_maa
    # existed). Drop opts the compiled SharedMAA does not declare so old binaries
    # still restore instead of AttributeError-ing at config time.
    _valid = set(SharedMAA._params.keys())
    assert (
        "virtual_pre_a_policy" in _valid
    ), "new compiled policy parameter missing"
    assert opts.get("virtual_pre_a_policy") in (
        "sorted",
        "row_group",
    ), "fixed policy missing or unknown"
    assert (
        opts.get("virtual_pre_a_window", False)
        or opts["virtual_pre_a_policy"] == "sorted"
    ), "row_group requires pre-A"
    _dropped = [k for k in list(opts.keys()) if k not in _valid]
    for _k in _dropped:
        del opts[_k]
    if _dropped:
        print(
            f"warn: MAAConfig dropping opts not in this binary's SharedMAA: {_dropped}"
        )
    system.maa = SharedMAA(clk_domain=system.cpu_clk_domain, **opts)

    has_retirement_ports = "retirement_sides" in SharedMAA._ports
    retirement_cache_size = getattr(
        options, "maa_retirement_cache_size", "1kB"
    )
    if has_retirement_ports and not getattr(
        options, "maa_device_owned_spd_paging", False
    ):
        retirement_cache_assoc = getattr(
            options, "maa_retirement_cache_assoc", 4
        )
        retirement_cache_response_latency = getattr(
            options, "maa_retirement_cache_response_latency", 1
        )
        retirement_cache_mshrs = getattr(
            options, "maa_retirement_cache_mshrs", 16
        )
        retirement_cache_targets_per_mshr = getattr(
            options, "maa_retirement_cache_targets_per_mshr", 16
        )
        retirement_cache_write_buffers = getattr(
            options, "maa_retirement_cache_write_buffers", 16
        )
        retirement_cache_positive_options = {
            "maa_retirement_cache_response_latency": retirement_cache_response_latency,
            "maa_retirement_cache_mshrs": retirement_cache_mshrs,
            "maa_retirement_cache_targets_per_mshr": retirement_cache_targets_per_mshr,
            "maa_retirement_cache_write_buffers": retirement_cache_write_buffers,
        }
        for (
            option_name,
            option_value,
        ) in retirement_cache_positive_options.items():
            if option_value <= 0:
                raise ValueError(f"{option_name} must be positive")
        system.maa_retirement_caches = [
            Cache(
                size=retirement_cache_size,
                assoc=retirement_cache_assoc,
                tag_latency=1,
                data_latency=1,
                response_latency=retirement_cache_response_latency,
                mshrs=retirement_cache_mshrs,
                tgts_per_mshr=retirement_cache_targets_per_mshr,
                write_buffers=retirement_cache_write_buffers,
                sequential_access=False,
                clk_domain=system.cpu_clk_domain,
            )
            for _ in range(options.num_cpus)
        ]
        if getattr(options, "maa_retirement_cache_bank_aware_index", False):
            banks = options.num_cpus
            if banks <= 0 or banks & (banks - 1):
                raise ValueError(
                    "Bank-aware retirement indexing requires power-of-two ports"
                )
            if "BankAwareSetAssociative" not in globals():
                raise ValueError("This binary lacks BankAwareSetAssociative")
            for cache in system.maa_retirement_caches:
                cache.tags.indexing_policy = BankAwareSetAssociative(
                    bank_bits=banks.bit_length() - 1
                )
        retirement_cache_total = (
            MemorySize(retirement_cache_size).value * options.num_cpus
        )
        print(
            "MAA virtual-retirement caches: "
            f"{options.num_cpus} address banks x {retirement_cache_size} "
            f"= {retirement_cache_total} data bytes, "
            f"response latency {retirement_cache_response_latency} cycles, "
            f"{retirement_cache_mshrs} MSHRs, "
            f"{retirement_cache_targets_per_mshr} targets/MSHR, "
            f"{retirement_cache_write_buffers} write buffers per bank"
        )

    # Increasing LLC side packets to accommodate the MAA routing table.
    # Accommodate one stream unit plus the configured indirect units per MAA.
    num_maas = opts.get("num_maas", 1)
    num_indirect_units_per_maa = opts.get("num_indirect_units_per_maa", 1)
    num_requesting_units = num_maas * (1 + num_indirect_units_per_maa)
    max_tol3_routing_table_size = num_requesting_units
    max_tol3_routing_table_size *= opts.get("num_tile_elements", 1)
    max_tol3_routing_table_size = max(512, max_tol3_routing_table_size)
    print(f"MAA max tol3bus routing table size: {max_tol3_routing_table_size}")
    system.maa.max_outstanding_cache_side_packets = max_tol3_routing_table_size
    system.tol3bus.max_routing_table_size = max_tol3_routing_table_size

    # Accommodate one invalidator path plus the configured indirect units per MAA.
    max_mem_routing_table_size = num_requesting_units
    max_mem_routing_table_size *= opts.get("num_tile_elements", 1)
    max_mem_routing_table_size = max(512, max_mem_routing_table_size)
    print(f"MAA max membus routing table size: {max_mem_routing_table_size}")
    system.maa.max_outstanding_cpu_side_packets = max_mem_routing_table_size
    system.membus.max_routing_table_size = max_mem_routing_table_size

    # Increasing snoop filter size to accommodate all LLC and MAA's SPD cachelines
    max_capacity = MemorySize("0")
    max_capacity.value += int(opts["addr_ranges"][-1].end) - int(
        opts["addr_ranges"][0].start
    )
    max_capacity.value += MemorySize(
        _get_cache_opts("l3", options)["size"]
    ).value
    max_capacity.value += (
        MemorySize(_get_cache_opts("l2", options)["size"]).value
        * options.num_cpus
    )
    max_capacity.value += (
        MemorySize(_get_cache_opts("l1i", options)["size"]).value
        * options.num_cpus
    )
    max_capacity.value += (
        MemorySize(_get_cache_opts("l1d", options)["size"]).value
        * options.num_cpus
    )
    if has_retirement_ports:
        retirement_data_bytes = (
            512
            if getattr(options, "maa_device_owned_spd_paging", False)
            else MemorySize(retirement_cache_size).value
        )
        max_capacity.value += retirement_data_bytes * options.num_cpus
    system.membus.snoop_filter.max_capacity = max_capacity
    system.tol3bus.snoop_filter.max_capacity = max_capacity
    print(
        f"MAA max snoop filter capacity: {system.tol3bus.snoop_filter.max_capacity}/{system.membus.snoop_filter.max_capacity}"
    )

    if getattr(options, "maa_device_owned_spd_paging", False):
        # Device demands must not own the LLC's memory-side retry while
        # waiting for coherent backing traffic through that same LLC.
        # Route the aperture to a distinct tol3bus destination. Keep backing
        # traffic, including dirty-owner acquisition, on the stock LLC path.
        aperture_start = int(opts["addr_ranges"][0].start)
        aperture_end = int(opts["addr_ranges"][-1].end)
        llc_ranges = []
        for region in system.l3.addr_ranges:
            assert not region.masks, "LLC aperture split requires plain ranges"
            start, end = int(region.start), int(region.end)
            if end <= aperture_start or start >= aperture_end:
                llc_ranges.append(region)
            else:
                if start < aperture_start:
                    llc_ranges.append(AddrRange(start, aperture_start))
                if end > aperture_end:
                    llc_ranges.append(AddrRange(aperture_end, end))
        system.l3.addr_ranges = llc_ranges
        for _ in range(options.num_cpus):
            system.maa.cpu_sides = system.tol3bus.mem_side_ports
        # Retain the original below-LLC snoop path for ordinary memory.
        # These ports advertise no demand ranges; native region invalidation
        # and cached/uncached probes must still see dirty LLC owners.
        for _ in range(options.num_cpus):
            system.maa.cpu_sides = system.membus.mem_side_ports
    else:
        for _ in range(options.num_cpus):
            system.maa.cpu_sides = system.membus.mem_side_ports

    # Native cache-like ReadEx/Writeback traffic keeps its original path.
    for _ in range(options.num_cpus):
        system.maa.cache_sides = system.tol3bus.cpu_side_ports

    if getattr(options, "maa_device_owned_spd_paging", False):
        assert has_retirement_ports, "Paging requires a dedicated backing bank"
        # A raw device WriteReq is not a cache-coherence ownership request.
        # Stock cache miss handling acquires ownership before upward fanout,
        # copies accepted store bytes, and returns the original WriteResp.
        # Four-core cost: 2KiB data, 32 MSHRs, and 32 normal plus
        # 32 MSHR-reserve write-buffer entries (stock Queue accounting).
        system.maa_coherent_frontends = [
            Cache(
                size="512B",
                assoc=8,
                tag_latency=1,
                data_latency=1,
                response_latency=1,
                mshrs=8,
                tgts_per_mshr=8,
                write_buffers=8,
                clk_domain=system.maa.clk_domain,
            )
            for _ in range(options.num_cpus)
        ]
        for frontend in system.maa_coherent_frontends:
            frontend.cpu_sides = system.maa.retirement_sides
            frontend.mem_sides = system.tol3bus.cpu_side_ports

    if has_retirement_ports and not getattr(
        options, "maa_device_owned_spd_paging", False
    ):
        for cache in system.maa_retirement_caches:
            system.maa.retirement_sides = cache.cpu_sides
            cache.mem_sides = system.tol3bus.cpu_side_ports

    for _ in range(options.mem_channels):
        system.membusnc.cpu_side_ports = system.maa.mem_sides

    if options.maa_l2_uncacheable:
        print("MAA L2 uncacheable")
        for i in range(options.num_cpus):
            for addr_range in opts["addr_ranges"]:
                system.cpu[i].l2cache.excl_addr_ranges.append(addr_range)
    if options.maa_l3_uncacheable:
        print("MAA L3 uncacheable")
        for addr_range in opts["addr_ranges"]:
            system.l3.excl_addr_ranges.append(addr_range)
