# Range/default32 and coherent SPD protocol integration

Source commit `79a65854` applies the selected00ba056c protocol change and the
required c0d27d10 serialized multiworker admission/destination-transfer guard.
The merge preserves four operand leases, the fourth Range engine owner,
independent Range row/output page cursors and native last_i/last_j carry.
Default shared spill/fill credits remain32 with explicit8/128 overrides.
Only MAA and CpuSidePort were rebuilt with the existing incremental recipe;
unchanged compatible objects were reused. No cold SCons build was used.

Stable executable: `build/protocol-integrated/objects/gem5.opt`, SHA256
`36833eddb18ea5ebf016b73c2b8b7399604cad67eb951ada180a2b2342dd9250`.
Frozen config root: `build/protocol-integrated/source`; Python config manifest
SHA256 `be6a3da3a016d08a2b064259891f27c91a54546c697a02e844e2de3f22af1321`.
`identity.json` records exact paths, config file hashes and limits. Actual loaded
Ramulator SHA256 is86ac860ca25c90b5b25524e5e224e4313b51465958133ec3bccfb71ef8a64749.
The preceding bee838 default32 artifact remains untouched for existing jobs.
Fresh launches must pair the new executable with the new frozen config root;
the new two-bank config is incompatible with an old one-bank executable.

## Protocol and costs

Paged SPD demands terminate above LLC. The aperture is excluded from LLC
ranges; backing region31 remains coherent through LLC. The lower CPU port bank
advertises empty demand ranges and retains ordinary-memory snoop visibility.
CleanEvict/WritebackClean terminate without copying stale bytes into a new SPD
generation. Dirty writeback, existing masks/native operations and frame/WriteResp
ownership are retained. Serialized CPU destination-transfer completion wakes
instruction admission. Overlap/fixed mapping keep their worker0 restriction.

Four-core emitted topology has eight CPU-side MAA ports. tol3bus is12 sources
by5 destinations; membus is6 by5. At the65536 CPU budget parameter, each bank
has32760 usable credits per core, aggregate65520, equal to the prior one-bank
aggregate. Cache-side parameter remains65536. The additional four physical MAA
ports and crossbar destinations/control state are real model changes; area,
frequency, wiring and added port/xbar costs are unmodeled. No payload bank is
added. Lower-bank dirty-response saturation is not separately logged, so there
is no universal-coherence or saturation claim.

## Combined evidence

All tests start fresh without old-topology checkpoints, use32 usable frames,
default32 shared line credits and single-command serialization. Core5/6 were
occupied by owned application runs, so user approved verified-free spare cores.
Tiny4 and GZZ2 use9; independent original PR uses10. All services deploy an
infinite runtime limit,8GiB memory,32GiB file limit and16GiB disk reserve. PID
and start ticks, commands, actual loaded DSO hashes and callbacks are retained.
The original PR driver explicitly forces one OpenMP worker; the reused generic
launcher environment is2, which the driver overrides. GZZ uses two workers and
tiny4 explicitly forces four. No blanket four-worker original GZZ claim follows.

Emitted route checks pass in each run: SPD aliases/control aperture are uniquely
routed above LLC; physical memory is fully LLC routed and aperture-disjoint;
ordinary-memory snoops use the empty-range lower bank. Observed region31 line
addresses are checked against LLC ranges in the trace analysis when present.
Tiny4 fits at32 and has no backing traffic; its CPU R/W/mask/output PASS is not
an SRAM exhaustion proof. Original PR is the maintained original pr.cc driver
on the6000-row/18000-edge regular graph, with original initialization, two
iterations and full CPU oracle. The regular uniform fixed point is a limitation;
it is not the larger irregular workload owned by p7Z.

Result directories under `build/protocol-integrated/`:

- `tiny4-pool32`: full output/guards/CPU tile generations PASS; delivered callback,
  no remaining CPU holds or network requests.
- `original-pr-6000-pool32`: PR_ORIGINAL_ORACLE PASS vertices=6000; delivered
  callback, no remaining CPU holds or network requests.
- `gzz2-32768-pool32`: full original GZZ2 PASS, zero volume/gradient/CPU
  tile errors, input stable and max_abs0; delivered callback. All43 CPU holds
  close and each contains backing responses. All25088 network responses drain;
  no CPU hold or network owner remains. All9216 observed region31 line addresses
  are LLC routed and aperture-disjoint. Peak network occupancy32. There are
  15861 terminal clean notifications in this execution.

No native performance comparison is made here. Any later native comparison
must use the same new executable and explicitly record its emitted topology;
old-topology numbers cannot isolate paging or equal-area performance. The prior
21.12% whole-transport result is not a paging gain and is not promoted here.


The combined checks are complete. This supports scheduling a subsequent matched
four-worker original GZZ experiment, not claiming it has passed. All comparisons
must use fresh setup and the selected matching new model/config identity. No
four-worker original GZZ run, new native performance pair, saturation proof or
universal coherence claim was collected here. The old bee838 executable was not
modified. Both spare cores are free after successful service termination.
