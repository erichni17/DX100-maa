# Device pager pressure investigation, 2026-11-10

This investigation uses the original seven-command FP32/u32 UME **motif**,
not the full UME application. Its full output, guards, immutable input and six
late logical tile views are independently checked. Raw artifacts are in this
session's `build/` directory, outside Git. No benchmark-owner files are changed.

## Baseline treatments and timing interpretation

The primary sweep uses the exact accepted r14 executable
`c5a7e9f5cf861b74a5eedb68de1837cfb7e84d16b2700752e196d8fc3084483d`,
the same accepted T16384 guest
`d631c71c9e229190c3e0b3855389067fa1ba391ada671e99254739e03dd79594`,
and identical input hash `699187acb1024178`. All three arms serialize commands
and use the dynamic free/oldest-age victim scan; usable frames are 32, 16, 8.
The payload allocation remains **524288 bytes in every arm**, including reserved
frames. Reducing the budget does not reduce allocated hardware payload.

The accepted `overlap32` result (8413440 ticks) uses **fixed**
`frame = tile * 4 + page` mapping and concurrent native engines. It changes
both mapping and scheduling relative to dynamic serialized paging. It does not
measure dynamic allocator overhead. Same-r14 native16 is 8486369 ticks;
the overlap result's 0.86% smaller time is one favorable observation, not a
proven gain. Native16 also allocates larger physical tiles, so it is not an
equal-area control.

Exact-r14 primary results (one observation each, all full oracles PASS):

| Usable frames | Kernel ticks | Fill lines (bytes) | Spill lines (bytes) | Dirty evictions | Misses |
|---|---:|---:|---:|---:|---:|
| 32 | 9,214,407 | 0 (0) | 0 (0) | 0 | 24 |
| 16 | 52,636,897 | 0 (0) | 2,048 (131,072) | 8 | 24 |
| 8 | 128,373,820 | 2,560 (163,840) | 4,864 (311,296) | 19 | 34 |

Including post-ROI late views, fill/spill lines are respectively 0/0,
5120/5120, and 8960/6144. Late-view traffic is excluded from kernel ticks.
Artifacts: `build/r14-sweep{32,16,8}/pager-analysis.json`, `result.json`,
`run.json`, `loaded-libraries.json`, `scores.bin`, `tile-views.bin` and
`gem5/commands.trace.gz`. The exact r14 binary does not expose transfer-wait or
mapping-high-water counters; these are measured separately with trace-only
source instrumentation and the candidate, rather than invented for r14.

The trace-only r14 pressure8 clone reproduced **128373820 ticks exactly** and
passed the same full oracle. Its 34 page-unavailable intervals totaled
104592706 ticks (81.48% of the ROI). The 7424 coherent send-to-response intervals
totaled 102243328 ticks (79.64%); every measured backing response took 13772 ticks
(44 device cycles). Spill and fill response sums were 66987008 and 35256320 ticks.
SPD read and write reservation latency sums were only 1536204 and 801280 ticks
(1.82% combined). Peak mapped frames was eight, peak coherent obligations one.
This directly identifies serialized coherent latency as the dominant pressure
cost, rather than SPD port charges. The remaining 23781114 ticks are outside
page-unavailable intervals, not an exclusive native-work attribution: native
drain work can overlap a pager interval. Artifacts: `build/r14-trace8/`.
The guest zeroes its2MiB backing before the ROI and this configuration has an
8MiB LLC. The uniform44-cycle transfers are setup/locality-dependent coherent
latencies; this experiment does not establish cold-DRAM paging cost.

The trace-only 16-frame clone also reproduced its exact baseline ticks:
28858913 page-unavailable ticks, of which 28205056 were coherent response waits,
with 646345 ticks of SPD read reservations. Peak mapped frames was 16. Its
23777984 ticks outside pager intervals closely match pressure8's 23781114;
the extra pressure8 time is overwhelmingly additional backing traffic, while
the common residual includes the smaller-pool page-drain policy. These two
observations isolate transport without pretending that the 32-frame scheduling
policy is unchanged. Artifacts: `build/r14-trace16/`.

The separate three-round r14 reuse test passed all 16400 output/guard words,
98304 final view words and 21 original commands. It took 557623272 kernel ticks,
with 16896 fill lines, 17664 spill lines, 69 dirty evictions and 138 misses.
This confirms repeated dirty reuse under eight usable frames, including
generation changes; the logical live set still comprises only six values.
Artifacts: `build/r14-rolling8/` and `build/rolling-build/rolling.elf`.

Even within the serialized sweep, `deviceFit32()` retains pins across page
boundaries and allows native indirect admissions to span 16K. Smaller pools
drain admitted native work at 4K page boundaries. Thus the sweep measures
the implemented capacity **and page-epoch policy**, not capacity alone.

Actual r14 cost charging (`SPD::leasePage`, `servicePager`, `getDataLatency`):

* A resident hit returns immediately. A newly acquired owner pin, or an unpinned
  CPU access, increments `lookupCycles`; repeated hits under the same pin do not.
  The next SPD read adds accumulated lookups to its port access count. This is
  deferred contention accounting, not a synchronous directory-hit latency.
* A miss schedules one MAA clock cycle before service. First allocation of an
  unbacked page also adds one deferred lookup charge. A fill does not manufacture
  initial payload, and backing is actual guest RAM.
* The dynamic scan visits up to the usable frame budget, skipping pinned frames
  and selecting a free/oldest-age victim. Comparisons, age updates, pin checks,
  and fixed-map indexing have **no distinct modeled delay or energy**. There is
  no synthesized area estimate for either mapping policy.
* Each spill line reserves/completes one existing SPD read-port access before
  its coherent WriteReq. Frame reuse waits for all WriteResp acknowledgments.
  Each fill ReadResp charges a write-port access before publishing residency.
  The tested configuration has four read and four write ports, each with one
  cycle base latency. Lookup charges and existing native accesses contend there.
* r14 permits one response-bearing backing line at a time, one page transfer,
  and one command in pressure mode. This is a prototype transport restriction,
  not a consequence of having one physical port. Page spill, reassignment and
  fill are sequential. Native RowTable behavior is retained.

## Coverage limits identified before the GZZ extension

`MAA::admitDeviceInstruction` rejects any worker other than core0 and any operand
ID >=8. Eight 16K values occupy at most 32 4K frames. A live working set exceeding
the entire intended shared 32-frame pool is therefore **unrepresentable** in the
accepted implementation. The six-value motif occupies only 24 pages. No test
here increases IDs/payload, enables another worker, or weakens that guard.

`tests/maa/device_pager_rolling.cpp` repeats the unchanged seven original API
calls three times, with the same six logical values and an accumulated CPU
oracle. It exercises generation replacement and repeated dirty eviction/reuse
under a smaller pool. It is not evidence for a >512KiB live set or production
multicore throughput. The 32 frames are one intended **shared pool**, not 32 per
worker; four workers' eight values each would require 128 resident pages.

The smallest useful full-UME same-kernel slice is the original FP32 gradzatp
corner loop (`benchmarks/UME/gradzatp.cpp`, ordinary branch): preserve its actual
corner-type mask, c-to-z/p maps, corner-volume and surface loads, point-volume
RMW, zone-field gather, multiply and point-gradient RMW. Use at least two
successive 16K chunks plus a tail, real mask density/locality and collision
structure, initialization-only backing provisioning, and the original complete
CPU reference for both outputs outside the ROI. Do not substitute this motif,
CPU-expanded descriptors, a sorter, or a different hot loop.

Before that slice is legal, implement and test predicate page leases, per-lane
readiness and inactive-lane/generation semantics across page boundaries for
Stream, Indirect, ALU and RMW. Cover zero/full/mixed masks and masked tails. The
ordinary gradzatp slice uses 32-bit integer indices and FP32 data already; FP64
is a separate unsupported type, not the immediate obstacle for this variant.

PageRank's ordinary `pr.cc` path additionally needs native Range with both
outputs and `last_i/last_j` carry preserved across pages. BC additionally uses
predicates and `maa_indirect_store_scalar`, which is rejected by the current
opcode whitelist. This checkout uses int32 `SGOffset`, float `CountT`; wider
variants need explicit width support. Original in-place operand aliases also
remain unsupported. Multicore requires per-worker instruction ownership,
cross-engine generation/pin lifetime, fair admission and eviction across the
single shared pool, and coherent CPU access testing. None is established by
four configured CPUs with only worker0 active. Range, wider types, predicated
ALU and multicore remain follow-up work. The separately authorized GZZ predicate
subset and actual same-kernel slice acceptance are recorded below.

## Mapping recommendation

Fixed resident mapping is a useful low-cost fast path when an explicitly
admitted worker's whole live set fits. Reserving the whole pool that way cannot
represent four workers' logical values, and a fixed per-worker partition can
strand capacity when activity is uneven. Dynamic shared mapping is needed for
oversubscription and lending unused capacity across workers, but its arbitration,
lookup and replacement timing must be modeled before claiming a hardware win.
Current fixed-vs-dynamic observations are confounded by engine scheduling; they
do not justify choosing fixed mapping as the general architecture. Keep the
resident profile labeled separately, retain dynamic ownership for pressure,
and first address the measured transport restriction. Later compare policies
under the same schedule and actual shared-pool working sets/locality.

## Controlled mapping-only result

One candidate build (`80228c73d2584c6402a5d2cd7e842a2123b8eb76108c6726beb83e4879d9e9d7`)
adds `--maa-device-owned-spd-fixed-map` (mode65). It requires32 frames and keeps
commands serialized, including the same fit32 pin retention/RowTable policy as
dynamic mode33. It is distinct from overlap mode97. The same candidate also
contains the independently measured eight-line transport change below; neither
mapping arm generates backing traffic, so that change is inactive here.

Both same-build/same-d631-guest arms passed the complete oracle, took exactly
**9214407 ticks**, transferred **0 fill / 0 spill bytes**, and peaked at **24
mapped frames (393216 bytes)** within the same524288-byte payload allocation.
Misses/lookups were24/48; page-unavailable ticks7512 in both. Artifacts:
`build/candidate-fit32-r2/`, `build/candidate-fixed32/`, and
`build/mapping-config-diff.json`. Apart from output/cwd redirect paths, only
`logical_spd_cache_mode` changes. This shows no resident mapping advantage under
the implemented timing model; scan cost remains unmodeled. Uneven multicore
capacity sharing cannot be measured under the current ID/worker contract.

The first `build/candidate-fit32/` attempt failed before simulation because the
frozen executable lost its execute bit. Restoring read/execute permissions and
retrying in a fresh directory repaired only launch setup; the failure is retained.

## Eight-credit pressure improvement

The candidate replaces r14's single line obligation with eight finite metadata
credits (128 bytes of line records; no payload buffer). Each packet directly
references a distinct line of the existing frame. Sender state authenticates
credit, line, frame, generation and direction. A credit lasts through the
coherent response and, for fills, charged SPD write completion. All256
WriteResp acknowledgments are still required before frame reassignment. One
page transfer, page-epoch drains and serialized pressure commands remain.
Rejected sends retain their line cursor/read reservation; port retry callbacks
and outstanding responses provide wakes. At most one new line issues per cycle.

| Pressure8, same original guest | r14 | Eight credits |
|---|---:|---:|
| Kernel ticks | 128,373,820 | 37,024,457 |
| Page-unavailable ticks | 104,592,706 | 13,243,343 |
| Coherent latency sum | 102,243,328 | 102,243,328 |
| Union of response-wait intervals | 102,243,328 | 13,208,600 |
| Fill / spill lines | 2,560 / 4,864 | 2,560 / 4,864 |
| Misses / dirty evictions | 34 / 19 | 34 / 19 |
| Peak response obligations | 1 | 8 |

The observed speedup is **3.47x**. Full output/guards, all98304 late view words,
seven commands and original4096 joint admissions pass. Native SPD reservation
latency sums and per-line coherent latency are unchanged; overlap hides latency
rather than removing traffic or costs. The candidate records6498 refused send
attempts and completes all7424 accepted obligations. Its residual23781114 ticks
outside page-unavailable intervals exactly matches the r14 pressure8 residual.
This is a mechanism improvement, not production throughput or multicore proof.
Evidence: `build/candidate-pressure8/`. Actual library mapping for this frozen
candidate was sampled in `build/candidate-fit32-r2/loaded-libraries.json`; the
shorter pressure run finished before a separate maps sample.

The same candidate's native16 control passed at8486369 ticks, exactly matching
r14. The accepted4097-element pressure8 tail also passed full output, guards and
all24582 late-view words at11767861 ticks (r8 baseline49566993; this tail baseline
is historical r8, not a new same-r14 comparison). Artifacts:
`build/candidate-native16/` and `build/candidate-tail4097/`.

The three-round same-guest/same-input reuse comparison also passed:557623272
ticks on r14 versus132292267 on the eight-credit candidate (**4.22x**), with
identical16896 fill lines,17664 spill lines,69 dirty evictions and138 misses.
All21 commands, outputs, guards and final six views passed. The candidate's
page-unavailable time was61547068 ticks. Artifact: `build/candidate-rolling8/`.

## Separately authorized original GZZ predicate extension

After preserving the mapping/transport measurements, Root authorized the
minimum predicate support needed by the **actual original GZZ kernel**. This is
a separate build, `build/pager-predicate/objects/gem5.opt`, SHA256
`44b6fdde87adfbc334da52f084b7b51af03859490ed6fab018c8e4e5f6cc62bf`.
The frozen compilation source and complete configuration tree are under
`build/pager-predicate/source/`; committed source differs only in formatting
and include sorting. Token equivalence was checked for the four changed files.

Native masked Stream loads, ordinary gathers and vector RMW may now lease at
most three distinct mask/data/destination pages. The mask has the same
generation ownership as data operands, in both serialized and overlap modes.
Original engine element-readiness checks, nonzero predicate decisions,
false-lane `setFakeData`, RowTable admission and RMW response ownership remain
unchanged. Predicated ALU, Range, FP64, another worker and destination/mask
aliases remain rejected before generation replacement.

A masked destination generation keeps prior resident/backed bytes while
clearing element readiness. Native false lanes become ready without overwriting
those bytes; selected lanes overwrite through original engine responses.
Pending transfers/live pins still prevent generation changes. Existing CPU
dirty writebacks update the preserved frame, and readiness is cleared after
invalidation before the producer runs. No payload buffer or CPU pager is added.

The test owner is
`cg-deterministic-resolution-20261027-101716-afd0efde`, source directory
`original-gzz-pager-test-20261110`. Its timed block is the original GZZ code;
initialization provisions tag31 and the complete independent oracle runs after
ROI. T16 guest SHA256:
`affc6ecbe41f17098467b25df042d767838a096a1912b9e76d882be4e9dd4a08`.
Logical IDs are0=temp/volume/point gradient,1=zone volume,2=zone index,3=mask,
4=point index then CPU-written floating contribution. The CPU reads/writes only
selected lanes; stale inactive integer bits interpreted as NaNs are legitimate
and are not incorrectly required to be finite. The final masked RMW consumes
CPU-written tile4 using index2 and mask3. The owner validates this actual path.

The new serialized lease bookkeeping independently passed the original
unpredicated4097-element pressure tail at11767861 ticks, exactly equal to the
transport-only candidate (`build/predicate-serial-tail4097/`). Actual masked GZZ
acceptance and matched new-model native controls are owned by the test owner;
provisional old-r14 GZZ controls are not used as a new-model performance claim.

Both initial44b6 actual-GZZ attempts (16384 and4097 corners) stopped at the
pre-existing Stream guard requiring a64-byte-aligned base and zero source min,
before predicate acceptance. The original vectors require only4-byte alignment;
later chunks retain the original base with source min16384. The preserved
failures are `original-gzz-paged-16384-20261110-121035-8a24e9ee` and
`original-gzz-paged-4097-20261110-121340-d8549570` under the shared
`quick-experiments` directory. They are unsupported-input failures, not wrong
numerical results, and are not rerun unchanged.

The successor keeps stride1, nonnegative ordered bounds and4-byte alignment.
Native PageInfo maintains absolute source `curr_itr` and min-relative `curr_idx`;
addresses remain `base + curr_itr * 4`, while SPD leases use `curr_idx`.
RequestTable's `(vaddr - block_vaddr) / word_size` selects valid words of partial
first/last cache lines; `curr_idx < my_size` bounds the logical tail. Registered
source-range checks remain per selected word. No guest pointer rebasing,
allocation alignment change, or hot-loop replacement is used. Pressure mode
still drains admitted RequestTable work before releasing a page lease, including
a cache line spanning two logical pages. Only StreamAccess is rebuilt for this
repair; frozen source and build evidence are in `build/pager-predicate-stream/`.
Successor executable SHA256:
`103a723695dbac74d736d0eaf1095892aae10b38d54e6a3bde1c3d3f4e674312`.

The repaired **actual original GZZ4097** case passed:184097 zones,3887 selected
corners, zero volume/gradient/CPU-tile4 errors, unchanged input and max absolute
error0. It executes12 original commands, including6 masked commands. The
complete output and selected-lane oracle covers the real in-ROI cached CPU
write into tile4 followed by masked RMW, plus the one-word second-page tail.
Kernel ticks33490061; peak10 frames,0 spill/fill traffic. This is a correctness
acceptance, not a performance comparison or pressure result. The guest remains
the same affc T16 ELF and the test owner's timed source is checkpoint18982e29.

Evidence: shared `quick-experiments/original-gzz-paged-4097-20261110-121941-c4550172/`;
local `build/gzz-tail-result.json` and `build/gzz-tail-r2-loaded-libraries.json`.
Output SHA256:
`1740eb1c8935b17cad25740731101a05cffb9f267787aad9bfb6d710c8174216`.
The actual loaded Ramulator library is unchanged at
`86ac860ca25c90b5b25524e5e224e4313b51465958133ec3bccfb71ef8a64749`.

The owner's repaired **actual original GZZ16384** also passed:196384 zones,
15559 selected corners, zero volume/gradient/CPU-tile4 errors, unchanged input,
max absolute error0. Kernel ticks105291635; peak20 frames,0 spills/fills.
Output SHA256:
`c9bf314b250d41136b7dc8c29622fb6ab445553026b1d63d21a5654f4358cc99`.
Evidence: `quick-experiments/original-gzz-paged-16384-20261110-122000-c7572d6a/`
and local `build/gzz-owner16-result.json`. This is still one worker with20
pages fitting the shared32-frame pool. The owner retains the32768/nonzero-min
case and matched same-successor native4/native16 controls; no speedup is claimed
against its provisional old-r14 controls or from the transport micro to GZZ.

All code/style commit hooks pass. This checkout lacks `MAINTAINERS.yaml`, so
only the commit-message tag lookup hook is skipped; no code check is bypassed.
