# Device-owned scratchpad paging

The r8/r14 implementation and acceptance record below are historical.
The [pressure investigation](pager_pressure_investigation.md) records the
subsequent eight-credit transport, controlled fixed/dynamic comparison, and
original-GZZ predicate/Stream extension with frozen binaries and actual oracles.

Original-interface acceptance passed on r8: fit32, pressure8, stock controls, boundaries and tails. The optional resident overlap profile also passed full16K and cross-page-tail oracles.

The original guest issues ordinary Stream, Indirect load, ALU and vector RMW
commands with original encodings. A single command retains its logical extent
(up to 16384 words) and native engine cursor. The implementation does not emit
four CPU commands, require logical adapter encodings, or add paging operations
to the application's hot loop.

## Initialization and configuration

Enable `--maa-device-owned-spd-paging`. Set logical tile elements to 16384 and
physical tile elements to 4096, with 32 architectural tile IDs/physical frames.
`--maa-device-owned-spd-frames=N` selects 3 through 32 usable existing frames;
32 is the default and 8 is the intended pressure test. Frames `[N,32)` are
explicitly reserved. Their payload is not repurposed as backing or buffering.
The existing `logical_spd_cache_mode` parameter encodes device paging as N+1;
0 and 1 retain their prior meanings. Paging is disabled by default.

During initialization, the driver allocates a dedicated, cache-line-aligned
2097152-byte guest RAM backing area and registers it with the existing
`m5_add_mem_region(begin,end,31)` operation. This is additional one-time backing
provisioning. The allocation must remain live through all commands and CPU tile
reads. Tag31 persists across `clear_mem_region` only in device mode. Overlapping
regions, a too-small/misaligned area and rebinding tag31 to another area are
rejected. Tag31 is reserved for this mode; callers that already use it must
resolve that collision during driver initialization.

The first implementation permits one active native command from worker core0.
Eight IDs/core remain the software logical partition; they do not partition the
physical frame allocator. Core0 may safely use globally allocated frames, but
may not address another software core's logical IDs. The design retains owner
and generation fields needed to extend scheduling concurrency later.

Supported commands initially use unpredicated 32-bit operands: dense aligned
Stream loads, ordinary Indirect loads, scalar/vector ALU and vector RMW. Other
opcodes, FP64, predicates, in-place source/destination aliases, logical adapter
encodings and other workers fail clearly before generation replacement. A
partial-length unpredicated producer replaces its tile's valid extent; it does
not update a slice of the previous generation. The optional accepted shared-progress CPU response broker and other
experimental logical schedulers are separate modes and are not enabled with
this first implementation. Native mode remains available for them. The old
logical descriptor Runtime and its private payload bank are not constructed in
device mode. Checkpointing after page use fails explicitly: page-directory and
mid-run payload checkpoint serialization are not implemented. A restart from a
pre-ROI checkpoint does not resume unserialized paging progress.

## Storage, timing and progress

SPD retains its existing 524288-byte payload array. A finite 128-entry directory
maps logical `(tile,page,generation)` to one of the 32 existing frames. A frame
holds its page owner, generation, dirty state, page-epoch pin and replacement
age. Logical element readiness is packed into 65536 bytes, additional to the
payload, directory and frame metadata. Paging summaries at statistics dumps and process exit report the actual directory
and frame C++ record sizes and cumulative fill/spill line counters; this is not a 512KiB total-hardware claim.

A native instruction leases only its current page from each operand (at most
three frames for an unpredicated vector ALU). Stream retains RequestTable
owners until responses finish. Indirect retains stock Row/Offset entries and
pins only the current page epoch; at a page boundary it drains admitted native
work, then releases those page leases and continues the same command. It does
not wait for future pages before servicing requests that free the old leases.
ALU retains its native logical cursor across page changes. This prototype has
two global performance restrictions: one active command and one outstanding
backing line transfer. The pressure profile also drains native RT work at 4K page
boundaries. The explicit32-frame profile retains command pins through true
retirement and preserves stock RT/Offset entries and logical ordinals across
pages; only ordinary native capacity causes drains. This is a single-worker
resident best case: eight logical tiles times four pages fit all32 frames. It
is not a general pressure or multicore result. One physical port does not imply
one outstanding request; transport serialization remains a prototype restriction.
Per-engine leases and finite transport credits are required before broader
performance conclusions. No extra sorter or full16K residency rule is introduced.

Dirty data remains resident until replacement. One finite transfer slot issues
one real coherent 64-byte ReadReq or response-bearing WriteReq at a time.
The packet refers directly to the pinned existing SRAM frame; no host backing
vector or extra payload page is allocated. Dirty replacement waits for every
WriteResp before reassigning the frame. A reload fills that frame through real
ReadResp transfers. A spill reserves and completes its SPD read-port access
before sending SRAM bytes. A final fill retains transfer ownership until the
charged SPD write-port completion, then publishes residency. No-victim pressure
is distinguished from a pending transfer; admitted RT work can drain without
clearing live pins merely to find a victim. Sender state authenticates the frame, generation, line and
transfer direction; retries cannot advance the transfer cursor.

Directory page acquisition charges lookup work, and backing line transfers
contend for the existing SPD read/write ports. Native service and bank costs
continue to use the stock engines. CPU timing requests use the same page map,
readiness references and retry protocol, including late reads of evicted pages.
No functional-read or syscall shortcut supplies tile data.

## Actual validation

The first original-interface16K run used commit 7f71d1df's r7 executable
(`64333261ebce74b684df002b5653fced0104ea4e72772ae9f78927c63fb525f8`).
The unchanged raw T16384 ELF
`d631c71c9e229190c3e0b3855389067fa1ba391ada671e99254739e03dd79594`
submitted three Stream loads, two Indirect loads, one vector multiply and one
native vector RMW. All 16384 outputs plus guards matched the CPU oracle, and
all 98304 words in six late logical tile views matched exactly. The first ROI
was 23943561 simulated ticks. This was the earlier page-epoch prototype:
maximum joint admission was 4096, so it does not prove 16K coalescing.

Evidence is retained outside Git at
`/data1/nier/dx100-diagnostic-private/quick-experiments/raw-api-paged16-16384-f32-20261110-005043-40bd62d3/small-result.json`.
Its service and child exited successfully. Notification delivery was false and
the test owner reconciled the terminal result through the lean runner's wait.

The reviewed fit32/port implementation is commit a06f3ce2, r8 executable
`fc91de61191c10ed98d69c723f6338ae261d807f1666bc703803680657c8deeb`.
Commit 6fb3d3a8/r9 changes only metadata summary formatting (`%zu` to the gem5
formatter's supported `%lu`); its executable is
`be04b67f66638a57f50f9a929aaa0777563bc8abdb16929a429ba412c0f6dbe4`.
Both private incremental builds passed. The original-interface owner completed
nine actual model cases on r8, including native4/native16 controls, fit32 and
pressure8 at16384, boundaries4095/4096/8192/16383 and pressure4097. Every full
output/guard and all six late tile views matched. The same T16384 ELF was used
for stock native16 and paging. Native4 has4096 Offset entries, whereas native16
and paged16 have16384; these are not equal-area controls.

| r8 case | Kernel simulated ticks | Maximum joint indirect admissions |
|---|---:|---:|
| Native4 stock | 23592062 | 4096 |
| Native16 stock | 8486369 | 16384 |
| Paged16 fit32, one worker | 9214407 | 16384 |
| Paged16 pressure8, one worker | 128373820 | 4096 |

Pressure8 transferred2560 fill and4864 spill lines in the kernel; including late
CPU reads it transferred8960 fill and6144 spill lines. All transfers are actual
coherent requests. The one-outstanding transport restriction remains in these
prototype pressure timings. No general multicore, equal-area or production
performance conclusion is established.

The final original-interface evidence is
`/data1/nier/worktrees/codex-sessions/cg-deterministic-resolution-20261027-101716-afd0efde/DX100/device-paging-api-micros-20261110/results.json`,
SHA256 `8c90e8a722fecbb7e947f83c651fec1266b033c796a100c2e26304c6974d6690`.
Test source is2281ba70 and its result commit is04a5a497. All nine model services
terminated successfully; the owner reconciled earlier notification failures and
later callbacks delivered. The24 host O2/UBSan recorder cases also passed.

## Optional resident overlap profile

`--maa-device-owned-spd-overlap` additionally opts into existing native Stream,
Indirect and ALU overlap. It requires32 frames, one worker/core0, one Indirect
engine, and only worker0's logical IDs0..7. Its existing mode-parameter encoding
is97. Default paging and pressure profiles stay serialized.

This resident profile binds `(tile,page)` to the fixed existing frame
`tile*4+page`; it cannot evict another engine's payload. Three finite per-engine
records capture instruction identity, the three operand/destination generations
and an independent logical cursor epoch. Frame owner masks distinguish Stream,
Indirect and ALU leases. Retirement releases only its own bits; global unpinning
with any live engine owner fails. Original IF hazards qualify generation
replacement before a new producer or reader acquires a lease. CPU writeback
readiness is cleared at producer Service after invalidation, without changing
the already-qualified generation. The native one-past-tile Finished sentinel
does not map a fictitious page.

The lease table reports its actual host record size and peak active engines.
It allocates no extra payload. This is still a single-worker resident profile,
not pressure overlap or multicore paging.

The focused overlap follow-up used source d00f14ae and private r14 executable
`c5a7e9f5cf861b74a5eedb68de1837cfb7e84d16b2700752e196d8fc3084483d`.
The same accepted T16384 guest ran both16384 and4097 elements. Full output,
guards and all six late tile views matched exactly, byte-for-byte with the
accepted r8 outputs. Both runs retained the original seven CPU commands and
reached three active engine owners; all three indirect summaries retained the
full respective16384/4097 joint admissions with no mid-instruction drains.
Kernel ticks were8413440 and6061558 respectively. These are individual resident
micro observations, not production throughput or pressure-overlap conclusions.

The finite storage summary reports512KiB payload,64KiB packed readiness,
3072 bytes of directory records,1024 bytes of frame records, and144 bytes of
per-engine lease records. Control, arbitration and existing native state are
additional; these host record sizes are not a synthesized area claim.

Follow-up evidence and actual model/guest/library/process identity are retained
under this worktree at `build/device-spd-overlap16-r3/small-result.json` and
`build/device-spd-overlap4097-r1/small-result.json`. Both services and children
exited successfully, the actual deployed runtime was verified infinite before
the child started, and completion notifications have delivered receipts. The
actual loaded Ramulator library SHA256 was
`86ac860ca25c90b5b25524e5e224e4313b51465958133ec3bccfb71ef8a64749`.

The initial overlap-only failure (duplicate ALU event) remains preserved in
`build/device-spd-overlap16-r2`; mapping notifications now target only waiting
owners, consume a coalesced wake, and preserve queued native resource events.
Retirement also removes owner bits from pending lookups. The earlier r8
acceptance is unchanged and retained separately.
