# Isolate pager backing ownership from native RMW traffic

## Exact application evidence

The preserved diagnostic GZZ4 run is
`/data1/nier/dx100-diagnostic-private/quick-experiments/original-gzz-integrated-paged-65536-t4-20261111-234153-114e0730`.
Same guest/n65536/team4/input5991432121607789265; no oracle acceptance.
At tick21285375635 the unchanged SF lookupRequest panic captures:

```
object=system.tol3bus.snoop_filter
source=system.tol3bus.cpu_side_port[5]
peer=system.maa_coherent_frontends1.mem_sides[0]
packet=WritebackDirty [707d40:707d7f-8/8]
from_cache=1 block_cached=0 responding=0 invalidate=0 writable=0
requester=bit5 requested=0 holder=0
```

Region8 is **ZONE_VOLUME**, not point_volume or backing31. The compiled header
resets region_count to7; original GZZ registers zone_gradient first, then
zone_volume. Stale source comments are not region identities.

The six flushed events for707d40 show native ReadExReq selected cached at
21280224281, sent through cache_side_port1 at21280224594, ReadExResp delivered
at21280239618, then native WritebackDirty selected cached at that tick.
The later front-end eviction and SF state are captured at the panic. The
unflushed interval does not reveal exactly which internal transition removed
holder state; no such transition is invented here.

Native MAA RMW generates cache-like ReadEx/WritebackDirty transactions, whereas
the added stock cache front was intended to acquire ownership for raw pager
ReadReq/WriteReq. Placing all MAA traffic behind it conflated these contracts.
BaseCache handles an incoming writeback without acquiring a new writable copy
(base.cc1495 onward); a missing block can be allocated or the writeback forwarded.
The observed front then issued an ordinary-region eviction without a matching
SF holder. This is a distinct failure from the earlier raw-spill WriteReq snoop
attribute mismatch. Neither SF assertion is weakened.

## Bounded boundary repair

Native cache_sides reconnect directly to tol3bus, preserving the prior native
ReadEx/probe/Writeback path and LLC coherence. Only SPD region31 traffic uses
the four stock coherent fronts. It uses the already-existing retirement_sides
bank, not a new public guest API or new port declaration. SPD's only routing
change is sendPacketRetirementCache in place of sendPacketCache. Its SRAM port
charges, retries, sender identity, data pointer, WriteResp lifetime and frame
pins remain. The backing bank rejects any non31, non64-byte/aligned, masked-write,
uncacheable or non-ReadReq/WriteReq packet. It does not generically reject
ReadReq byte-enable masks; the current SPD producer creates fresh full64-byte
requests. Thus native cache-like ownership
transactions cannot enter these fronts again.

The existing unused virtual-retirement cache objects are omitted in paging
mode; native paging-off behavior is unchanged. Four512-byte fronts remain:
2KiB resident data,32 MSHRs/256 targets,32 normal plus32 reserved write entries,
packet payload and coherence/tag state, and their real cache latencies. Newest
backing bytes may reside coherently dirty in a front after WriteResp, until a
snoop or normal LLC writeback. No LLC bypass, flag manipulation, CPU worker
serialization or global drain is introduced.

No new request-port/counter banks are allocated. The four native and four
retirement banks already exist in the predecessor; their configured budgets
remain unchanged. At parameter65536 each cache/retirement bank's actual limit
is min(65536,16384)-32=16352; pager logical credits remain32 globally by default.
The previously idle retirement bank now carries backing traffic, so active
sharing changes and is not claimed performance-neutral. CPU snoop banks retain
32760 usable credits each,65520 aggregate per core. Emitted tol3bus source count
remains12. Native and backing traffic are now explicitly separate peers.

## Evidence and candidate identity

The4096-word native RMW fixture passed on the diagnostic broad-front model;
it did not reproduce the application failure. It is not cited as cause proof.
The actual application capture above supplies that evidence.

The isolated candidate passes both small tests with rc0 and delivered callbacks:

- `build/pager-backing-isolated/dirty-owner-isolated`: dirty CPU backing-owner
  overwrite, expected word123. This checks one word, not every spill byte.
- `build/pager-backing-isolated/rmw-footprint-isolated`: larger native RMW
  footprint, two workers, masks, CPU tile R/W generations and full output/guards.

Binary: `build/pager-backing-isolated/objects/gem5.opt`, SHA256
`5a634a43213ecc345502135e4b4961044eb7bc4fdc203b0df0d5446781a288ce`.
Required frozen config root: `build/pager-backing-isolated/source`, manifest
`14172f989fa7ccf7b96ff93a3abcf6bd881c2294dabec2a6cc7ac91c2f1c8ebb`.
`identity.json` and `objects/commands.json` bind paths/config and exact actions.
Only SPD/CpuSidePort were incrementally rebuilt, reusing the diagnostic SF
object and unchanged compatible model objects. No cold build or broad suite.
The companion private analyzer counts region31 sends on both cache and
retirement port names; old analyzers matching only cache_side_port omit the
new backing path. Ordinary RMW remains visible on cache_side_port.

Root/p87 review is requested against the actual diff and captured attributes.
p7Z owns the next unchanged original GZZ4 retry/full oracle; no duplicate target
is launched here. Full GZZ4 correctness, new-MSHR saturation and universal
coherence/liveness remain unproved. All older failed artifacts remain immutable.


## Exact original GZZ4 acceptance (2026-11-12)

The unchanged original GZZ4 n65536/team4/input5991432121607789265 run on
c4eb9457/model5a634a43 completed with full oracle PASS: zero volume, gradient
and all-four CPU-tile-view errors, input stable and max_abs0. Final output SHA256
is a969e686ef9d7b964c76fc3cccd889f40b8fc3adf2cb43a8163c2697c9907c40,
matching the owner's native output. The saved result reports rc0, successful
service termination and notification_delivered=true; gem5 reaches m5_exit.

Output directory:
`/data1/nier/dx100-diagnostic-private/quick-experiments/original-gzz-integrated-paged-65536-t4-20261111-235604-db4ba9d4`.
Owner report: original-gzz-integrated-20261111/backing-isolated-t4.json in p7Z's
worktree. Model and frozen config are unchanged from the candidate above.

First ROI is283724171 ticks. Owner-reconciled ROI traffic is38912 fill lines,
35840 spill lines and140 dirty evictions, peak32/32 frames and32 line credits,
with64403 rejected/retry attempts. Totals after late CPU views are56832 fill
lines,38144 spill lines and149 dirty evictions; these later totals must not be
attributed to the timed kernel. Network trace closure remains pending the
owner's postprocessing and is not inferred from the numerical PASS alone.

This accepts the exact original four-worker slice and complete saved oracle.
It is not generic saturation/liveness, area closure, universal coherence, or
pure paging performance evidence. The missing internal SF transition from the
failed predecessor remains unobserved. p7Z owns the remaining same-model
hybrid2 run on core6; no duplicate application run is launched here and the
protected inverse-native4 job on core5 is untouched.

## Same-model original GZZ2 completion

The unchanged original two-worker n65536/input5991432121607789265 run also
passes the full oracle and both CPU tile views, with the native-matching output
hash, rc0, m5_exit and delivered callback. Model/config remain5a634a43/c4eb9457.
Artifact:
`/data1/nier/dx100-diagnostic-private/quick-experiments/original-gzz-integrated-paged-65536-t2-20261112-001020-d9b254a8`.

| Workers | First ROI ticks | ROI fill lines | ROI spill lines | ROI evictions |
| ---: | ---: | ---: | ---: | ---: |
| 2 | 283914162 | 19456 | 18688 | 73 |
| 4 | 283724171 | 38912 | 35840 | 140 |

Both peak at32 frames/32 shared line credits. Two-worker retries are31985;
four-worker retries are64403. Owner-reported two-worker committed instructions
are351878,537507,0,0. Four workers are only0.067% quicker in these single
observations: an essential timing tie, not a demonstrated scaling improvement.
Two workers use about half the backing traffic and instruction work. ROI
traffic is separate from subsequent CPU tile-view traffic.

The owner reports no more model targets and normal closure of both application
jobs; bounded packet-closure postprocessing remains separately qualified.
The protected full inverse-native4 job also completed PASS according to its
owner. No new simulation or source change accompanies this record. General
liveness, new-bank saturation, area/frequency and pure paging claims do not
follow from these successful kernel observations.
