# Shared pager line credit capacity

Three runs on one runtime-configurable executable, using
`tests/maa/device_pager_pr.cpp`: synthetic PR-style 6000-row/18000-edge graph,
logical16K/physical4K, eight physical frames, serialized worker0/OMP1.
This is not the actual original PageRank kernel comparison owned by p7Z.

`DX100_PAGER_LINE_CREDITS` selects 1..256 credits; absent means eight, unchanged.
Credits cover both coherent spill writes and fill reads, not write-only traffic.
Each is 16 bytes of metadata on this build (128/512/2048 bytes respectively),
plus the fixed vector control and diagnostic counters. There is no new payload
buffer. Packets still reference pinned existing SRAM; SPD read reservations,
fill write-port completion, retries, frame generations and WriteResp retirement
are unchanged.

| Credits | Peak | ROI ticks | Final stats-window ticks | Credit-full ticks | Rejected sends | Accepted lines/M ticks |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 8 | 8 | 25542365 | 94408938 | 15136367 | 5326 | 263.77 |
| 32 | 32 | 12110283 | 80575590 | 226299 | 6077 | 636.70 |
| 128 | 45 | 12090251 | 80575590 | 0 | 6133 | 649.94 |

All three passed the full fixture numerical oracle, exited successfully and
recorded delivered completion callbacks. All accepted exactly 6144 lines:
4096 spill writes and 2048 fill reads, with 32 misses and 16 dirty evictions.
The default-eight ROI ticks exactly match the preceding frozen graph model.

Throughput is accepted lines divided by the interval from first to last
accepted request, including inter-page gaps. Credit-full ticks begin only when
another line is eligible to issue and no metadata slot is available; they end
when a slot becomes reusable, including any charged SPD fill completion.
Rejected send attempts are counted separately and are evidence of transport
backpressure, not credit-cap stalls. They do not distinguish downstream cache
queue pressure from individual port rejection. Outstanding response latency
can determine how long all credits remain occupied; the wait metric is not a
causal isolation of the memory hierarchy.

For this tested case, eight is insufficient: 32 is 2.109x faster in ROI ticks.
128 improves over 32 by only 0.1654%, with no final-window improvement. At128
there are no credit-full waits and occupancy peaks at45, while transport
rejections remain. This is a measured plateau near32, not proof32 is universally
sufficient or a write-only capacity recommendation. Stop after three runs;
no256 run is justified by this result. Defaults remain eight.

Artifacts: `build/pager-credit-sweep/gem5.opt`, `commands.json`,
`source-sha256.json`, `pager-credit-results.json`. Raw runs:
`/tmp/pager-credit-{8,32,128}-r1`. Each run.json records the identical model and
options with only the credit environment setting changed. The original `08f5`
model remains available at `build/pager-graph-r3/gem5.opt` for p7Z.

Sweep model SHA256:
`bb869fdea62e14b2818e46011818ff83c2ce3e549abb01fc95dbeb3d2a90874d`.

## Approved default32 integration

The user subsequently selected32 as the default for this model. Explicit
`DX100_PAGER_LINE_CREDITS=8` and `=128` overrides remain supported. This choice
is based on the bounded case above, not universal sufficiency. Only the default
initializer changed; native costs, ports, frame ownership and response retirement
are retained. Default metadata is32 x16 bytes =512 bytes, without payload storage.

Stable executable: `build/pager-default32/gem5.opt`, SHA256
`bee8388555ab48c7f06eb8c38cfa3d22f065f22ee755341fa9fecc5e0b3952ea`.
The exact config root and per-file hashes are in
`build/pager-default32/identity.json`; config manifest SHA256:
`62c32433bdaca1357e85ccd676388ebc97028065ddcde94b8664ea91f9eeff5f`.
Only SPD was recompiled; unchanged sweep objects were reused before linking.

One no-override synthetic PR-style pressure8 regression passed:
`/tmp/pager-credit-default32-r1`, zero numerical errors, returncode0 and delivered
callback. It reports32 credits,16 bytes/credit,6144 accepted lines and exactly
the preceding explicit32 counters. No completed sweep was repeated. The original
08f5 and sweep artifacts remain unchanged. Larger original PR and medium
GZP/inverse workload runs belong to p7Z.
