# Original GZZ active-worker sweep, fixed four-core hardware

Native16 first:65536corners gives4full16Kchunks; native4 gives16chunks. Same seed1 source/input, original timed GZZ two-pass kernel byte-identical to e4fc (build asserts it). Only setup sets active OpenMP workers1/2/4. Configured CPUs4, tile IDs32, native geometry/cache/engine/ports fixed within each native4 or native16 sweep. No paged/multicore acceptance is implied.

All zone volumes/gradients checked independently after ROI, plus each worker's actual final cached tile4-write→RMW data through original API. Equal static chunk groups under existing GCC9/libgomp omp-for default are checked via final original input/data lanes. Inactive lanes retain original semantics. PerCPU firstROI committed instruction counts and trace core IDs are reported, never equated to physical core cost. Native4/native16 themselves have different tile and Offset sizes, so worker optimum assessed separately. No baseline reuse from different model/count.

Use default32 model bee838 and frozen guest build original-gzz-sweep-guests-20261111-131821-3f6ca84f. Native16 workers1→2→4, then native4 only after larger authorized PR/UME jobs release their lanes. No new target launched by source preparation.
