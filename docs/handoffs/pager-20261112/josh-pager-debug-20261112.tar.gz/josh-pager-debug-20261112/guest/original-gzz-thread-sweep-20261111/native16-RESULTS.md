# Original GZZ native16 active-worker sweep

65536corners, same input/ELF/model, four configured O3CPUs and fixed32native16Ktiles/cache/engine/ports. Only active OpenMP workers changed. MAA configuration exactly equal across arms. Four full16Kchunks distribute real work to all four workers.

| Active workers | First ROI ticks | Speedup vs1 | PerCPU committed instructions |
|---|---:|---:|---|
|1|412639794|1.000x|702969,0,0,0|
|2|283621194|1.45490x|508064,351483,0,0|
|4|226721550|1.82003x|340102,379309,422806,323323|

Four workers are fastest among these tested settings, 1.25097x two workers. This does not establish a universal four-core optimum or a physical-core cost comparison: all arms retain four-core hardware. Total CPU instructions rise with worker/synchronization overhead, so speedup is sublinear. No per-site cause attribution claimed.

All full numerical/input/each-worker late CPUtileviews PASS. Output hashes identical, same24Stream/8comparison/8gather/8nativeRMW instructions. Original timed GZZ kernel byte-identical. Scope one65536corner original input, native16; native4 sweep underway. No paged multicore result is implied. Exact result paths/hashes/counters in native16-scaling.json.
