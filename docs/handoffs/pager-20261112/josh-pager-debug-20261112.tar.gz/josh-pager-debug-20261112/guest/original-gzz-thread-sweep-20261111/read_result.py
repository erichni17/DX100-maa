import argparse,json,re,struct,hashlib,gzip,collections
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('out',type=Path);p.add_argument('--threads',type=int,choices=[1,2,4],required=True);p.add_argument('--tile',type=int,choices=[4096,16384],required=True);a=p.parse_args();o=a.out
r=json.loads((o/'result.json').read_text());assert r['passed'] and r['returncode']==0 and r['service_result']=='success'
run=json.loads((o/'run.json').read_text());assert run['environment']['OMP_NUM_THREADS']==str(a.threads)
log=(o/'run.log').read_text();lines=re.findall('^ORIGINAL_GZZ PASS (.*)$',log,re.M);assert len(lines)==1
v=dict(re.findall(r'(\w+)=([^\s]+)',lines[0]));assert v['corners']=='65536' and all(v[k]=='0' for k in ('volume_errors','gradient_errors','cpu_tile5_errors')) and v['input_stable']=='1'
b=re.findall('^ORIGINAL_GZZ_BEGIN (.*)$',log,re.M);assert len(b)==1;b=dict(re.findall(r'(\w+)=([^\s]+)',b[0]));assert int(b['workers'])==a.threads and int(b['tile'])==a.tile
blob=(o/'gzz-output.bin').read_bytes();assert struct.unpack_from('<4Q',blob)==(0x475a5a31,65536,245536,int(b['input'])) and len(blob)==32+8*245536
cfg=json.loads((o/'gem5/config.json').read_text());assert len(cfg['system']['cpu'])==4 and cfg['system']['maa']['logical_spd_cache_mode']==0
s=(o/'gem5/stats.txt').read_text().split('---------- Begin Simulation Statistics ----------')[1].split('---------- End Simulation Statistics')[0]
inst={}
for i in range(4):
 m=re.search(r'^system.cpu'+str(i)+r'.thread_0.numInsts\s+(\d+)',s,re.M);assert m;inst[str(i)]=int(m[1])
assert sum(count>0 for count in inst.values())==a.threads
ops=collections.Counter()
with gzip.open(o/'gem5/commands.trace.gz','rt') as f:
 for line in f:
  if 'recvTimingReq:' in line and ' received!' in line and 'INSTR[' in line:ops[re.search(r'opcode\(([^)]+)\)',line)[1]]+=1
chunks=65536//a.tile;assert ops==dict(STREAM_LD=6*chunks,ALU_SCALAR=2*chunks,INDIR_LD=2*chunks,INDIR_RMW_VECTOR=2*chunks)
print(json.dumps(dict(passed=True,threads=a.threads,configured_cpus=4,tile=a.tile,n=65536,first_roi_ticks=int(re.search(r'^simTicks\s+(\d+)',s,re.M)[1]),committed_instructions_per_cpu=inst,native_opcodes=dict(ops),input_fingerprint=b['input'],output_sha256=hashlib.sha256(blob).hexdigest(),full_oracle_and_all_worker_tile_views=True,source=str(o),model_sha256=run['executable']['sha256']),indent=2))
