import argparse,hashlib,json,subprocess
from pathlib import Path
D=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
def timed(s):return s[s.index('void gradzatz_MAA()'):].split('    m5_reset_stats(0, 0);',1)[1].split('    m5_dump_stats(0, 0);',1)[0]
assert timed((D/'gzz.cpp').read_text())==timed((D/'original.cpp').read_text())
records={}
for tile in (4096,16384):
 elf=a.out/f'gzz-{tile}.elf';cmd=['/usr/bin/g++-9','-std=c++17','-O3','-g','-fopenmp','-DGEM5','-DMAA','-DNUM_CORES=4','-DTILE_SIZE='+str(tile),'-DMAA_MEM_SIZE=0x80000000','-I'+str(D/'include'),str(D/'gzz.cpp'),str(D/'m5op.S'),'-o',str(elf)]
 with (a.out/f'compile-{tile}.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError(f'compile{tile} failed')
 records[str(tile)]={'path':str(elf),'sha256':hashlib.sha256(elf.read_bytes()).hexdigest(),'command':cmd}
(a.out/'guests.json').write_text(json.dumps({'guests':records,'timed_kernel_byte_identical':True,'original_commit':'e4fc4afdf894f295442cef3604667a469fab8e62','source_sha256':hashlib.sha256((D/'gzz.cpp').read_bytes()).hexdigest()},indent=2)+'\n');print('ORIGINAL_GZZ_BUILD PASS',flush=True)
