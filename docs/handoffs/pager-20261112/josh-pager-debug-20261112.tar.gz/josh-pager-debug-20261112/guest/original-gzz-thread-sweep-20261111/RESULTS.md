# Original GZZ native active-worker sweep

Same65536corner input/model; all six full output and per-worker CPUtile oracles PASS, identical output hash. Four configured O3CPUs,32tiles/cache/engines/ports held fixed within each profile. Only active OpenMP workers changed.

| Active workers | Native4 ticks | Native16 ticks |
|---|---:|---:|
|1|497310363|412639794|
|2|360493368|283621194|
|4|295564961|226721550|

Four workers fastest among tested settings in both profiles. Native4 speedup vs1=1.682576x; native16=1.820029x. This establishes a conditional measured choice, not a universal four-core optimum or physical1-vs4-core cost comparison.

Counters confirm exactly1/2/4 active CPU contexts; exact perCPU committed instruction counts in scaling.json. Every profile preserves original native operation counts across thread choices and original timed source; all worker final CPUtilewrite→RMW views checked. Native16 has4fullchunks, native4 has16; no idle-worker fake scaling. Native16 and native4 themselves have different SPDcapacity/Offset and cannot be treated as equalarea. No new paged multicore claim.
