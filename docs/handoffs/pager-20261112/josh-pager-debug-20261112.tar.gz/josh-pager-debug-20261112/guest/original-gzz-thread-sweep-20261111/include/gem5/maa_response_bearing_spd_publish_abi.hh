#ifndef __GEM5_MAA_RESPONSE_BEARING_SPD_PUBLISH_ABI_HH__
#define __GEM5_MAA_RESPONSE_BEARING_SPD_PUBLISH_ABI_HH__

#include <cstdint>

namespace gem5::maa
{
struct ResponseBearingSpdPublishABI
{
    // Explicit opt-in in the existing logical-page identity register.
    // Unflagged callers still require exactly 4096 valid source elements.
    static constexpr uint32_t PartialPage = uint32_t{1} << 31;
    static constexpr uint32_t LogicalPageMask = 3;
    static constexpr uint32_t AllowedPageBits = PartialPage | LogicalPageMask;
};
} // namespace gem5::maa

#endif // __GEM5_MAA_RESPONSE_BEARING_SPD_PUBLISH_ABI_HH__
