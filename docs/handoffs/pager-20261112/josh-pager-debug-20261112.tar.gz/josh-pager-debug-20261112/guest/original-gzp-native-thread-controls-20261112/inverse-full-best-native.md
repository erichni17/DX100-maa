# Full original inverse GZP: best correct native workers

1000000corners/1180000points, same original inverse CSR/Range/gather/CPUaccumulation/normalization and seed1 input. All six native full oracles/CSR/strictactualunusedscalar/inputstability/allworker lateviews PASS; entire output hashes identical across1/2/4 and4K/16K. Existingone-worker outputs reused,2/4newdrivers onlyteamsetup/postROIqualification;timedkernel text bytepreserved.

| Active workers | Native4K ticks | Native16K ticks |
|---|---:|---:|
|1|31509983875|29697854412|
|2|17524832127|16308137901|
|4|10199650872|9161248645|

Four workers fastest among tested settings in bothprofiles. Existinghybrid1 full timing29710166267: **34.3305% of bestnative4K throughput and30.8354% of bestnative16K throughput**. The prior6.1% figure is onlyONE-vs-ONE, not a best-native gain. Native/hybrid active workers are selected independently; no hybridmulticore prerequisite or equalactiveworkers fairnessgate.

Configured4O3CPUs/32tiles/cache/engines/ports fixed and MAAconfig exactlyequal within each nativeprofile. CPU instruction counts confirm2/4real contexts and everyworker has nonemptyCSR contribution work. Native4Kphysicalpayload512KiB vsnative16K2MiB andOffset4096vs16384 are declaredprofiledifferences; no equalarea/physicalcorecost/energy claim. Hybrid1residentmode97 fits28of32physical4Kframes,zeroactualfill/spill; its metadata/lookup costs retained,not dynamicpagingpressure evidence.

Only correct full cases enter minima. Original forwardGZP multithread numerical failures are separate and excluded; barriers/math unchanged. All old outputs/failures/configs preserved. inverse-full-best-native.json holds exact metrics/hashes/paths/counters/worker views and source scope.
