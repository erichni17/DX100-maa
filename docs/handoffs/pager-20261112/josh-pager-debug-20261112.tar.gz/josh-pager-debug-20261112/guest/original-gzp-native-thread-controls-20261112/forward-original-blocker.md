# Original forward GZP best-native comparison: correctness blocker

All four requested65536corner parallel sanity controls fail the unchanged full numerical rule:

| Native tile | Workers | Used-gradient errors | Unused-gradient errors |
|---|---:|---:|---:|
|4K|2|1|0|
|4K|4|1|6|
|16K|2|4|0|
|16K|4|15|9|

Volumes arecorrect, inputhash6692817471587628661 stable, everyworker nonempty, team/tile/register allocationvalid, finalpublictileviews0errors. Full1Mforwardparallel controls were NOT launched afterfailedsanity, and failed fast timings are excluded. Existing acceptedone-worker timings/outputremain unchanged ONE-vs-ONE observations; a best-native forward speedup is NOT established.

Source preserves original timedkernel byte-for-byte:implicitompfor barrier BEFORE per-thread wait_ready(tile2),then CPU normalization ompfor with NO team barrier after final waits. This permits early normalizer threads to race otherworkers' pending shared scatter-adds. Hash-bound point122931 hascontributions32150/39755 on differentworkers andobserved1.5vs1;sourceadmitsnormalize1/2=.5 thenlate+1. Final4K4case has oneused0vs1 plus6unusedfinite0 inoneactualvirtualcacheline, consistentwithwhole-line interference. These exactinteger-contribution failures cannotbe reductionroundoff. Individualcachepacketordering isnotclaimedproven.

The user explicitly required original timedbarriers byte-preserved. Minimal opt-in post-finalwait team barrier patch is standalone,apply-checkpassed,unapplied/uncompiled. Selecting it would be a declared versioned synchronization correction, not original unchanged source or a newRowTable/fullwindow requirement. No barrier,math,tolerance,unusedpolicy or inputs were silently changed. To completecorrected forward best-native comparison requires explicit source-policy disposition; independently authorized inverse comparisons completed correctly.

Failures/classes/witnesses preserved in forward-failure-diagnosis.md,forward-native16-failure-classes.json,forward-native4-65536-t2-failure.json,forward-native4-failure-classes.json. No oldoutput/claim overwritten or rerun. No models remain active for this task.
