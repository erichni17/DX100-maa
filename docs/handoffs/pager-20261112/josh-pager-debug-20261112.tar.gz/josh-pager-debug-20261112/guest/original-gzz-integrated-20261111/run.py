import argparse,json,subprocess,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent
QUICK='/data1/nier/benchmark-delivery-original-suite-20261012/ume-third-gzz-cpu-recovery-r1/experiments/quick_run.py'
R14='c5a7e9f5cf861b74a5eedb68de1837cfb7e84d16b2700752e196d8fc3084483d'
p=argparse.ArgumentParser();p.add_argument('--model-root',type=Path,required=True);p.add_argument('--model',type=Path,required=True);p.add_argument('--model-sha',required=True);p.add_argument('--build',type=Path,required=True);p.add_argument('--profile',choices=['native4','native16','paged'],required=True);p.add_argument('--n',type=int,default=65536);p.add_argument('--threads',type=int,choices=[1,2,4],required=True);p.add_argument('--core',type=int,default=6);p.add_argument('--notify-pane',default='w41:p7Z');p.add_argument('--wait',action='store_true');a=p.parse_args()
if a.profile=='paged' and a.model_sha in {R14,'44b6fdde87adfbc334da52f084b7b51af03859490ed6fab018c8e4e5f6cc62bf'}:raise SystemExit('known unsupported original-GZZ pager model; use the hardware owner repaired artifact')
assert a.model_sha in {'36833eddb18ea5ebf016b73c2b8b7399604cad67eb951ada180a2b2342dd9250','7481514b62db6aaca2b0001af6507703f19e67d3d02c355cdd577bed681c8d85','e40b567a1bd4cd831858c1ea91867b5e1aa01c10ea9591e56e26b1f03518cfea','5a634a43213ecc345502135e4b4961044eb7bc4fdc203b0df0d5446781a288ce'}
assert (a.model_root/'configs/common/MAAConfig.py').is_file()
if a.profile=='paged' and a.threads>1 and a.model_sha in {'36833eddb18ea5ebf016b73c2b8b7399604cad67eb951ada180a2b2342dd9250','7481514b62db6aaca2b0001af6507703f19e67d3d02c355cdd577bed681c8d85'}:raise SystemExit('known coherent-spill protocol failure; wait for owner repair, no unchanged retry')
if a.model_sha=='e40b567a1bd4cd831858c1ea91867b5e1aa01c10ea9591e56e26b1f03518cfea':raise SystemExit('one diagnostic capture completed; no repeat authorized')
assert a.n==65536
b=json.loads((a.build/'guests.json').read_text());tile=4096 if a.profile=='native4' else 16384;elf=Path(b['guests'][str(tile)]['path']);assert hashlib.sha256(elf.read_bytes()).hexdigest()==b['guests'][str(tile)]['sha256']
# Reuse the already-accepted raw original test configuration, not its workload.
base=json.loads(Path('/data1/nier/dx100-diagnostic-private/quick-experiments/raw-api-native16-16384-f32-20261110-013013-8bbc84da/run.json').read_text())['argv'];args=list(base);args[0]=str(a.model)
args=[('--outdir={out}/gem5') if x.startswith('--outdir=') else ('--maa_num_tile_elements='+str(tile)) if x.startswith('--maa_num_tile_elements=') else ('--maa_physical_tile_elements='+str(4096 if a.profile=='paged' else tile)) if x.startswith('--maa_physical_tile_elements=') else ('--maa_num_offset_table_entries='+str(tile)) if x.startswith('--maa_num_offset_table_entries=') else ('--maa_num_offset_table_epoch_entries='+str(tile)) if x.startswith('--maa_num_offset_table_epoch_entries=') else x for x in args]
args[args.index('--cmd')+1]=str(elf);args[args.index('--options')+1]=str(a.n)+' '+str(a.threads)
if a.threads>1:args=[x+',MAACachePort,MAAPort' if x.startswith('--debug-flags=') else x for x in args]
mode=0
if a.profile=='paged':args+=['--maa-device-owned-spd-paging','--maa-device-owned-spd-frames=32'];mode=33
cmd=['python3',QUICK,'--name',f'original-gzz-integrated-{a.profile}-{a.n}-t{a.threads}','--kind','simulation','--memory','8G','--core',str(a.core),'--notify-pane',a.notify_pane,'--expected-exe-sha',a.model_sha,'--env','DEVICE_MODEL_ROOT='+str(a.model_root),'--env','OMP_NUM_THREADS='+str(a.threads),'--env','OMP_DYNAMIC=FALSE','--env','DX100_PAGER_LINE_CREDITS=32','--expect','ORIGINAL_GZZ PASS','--expect','volume_errors=0 gradient_errors=0 cpu_tile5_errors=0 input_stable=1','--check-json','gem5/config.json','system.maa.logical_spd_cache_mode',str(mode)]
if a.wait:cmd+=['--wait']
subprocess.run(cmd+['--']+args,check=True)
