# Original GZZ, best worker count within a four-CPU maximum

Same65536corner input5991432121607789265, original unchanged maa hotloop, fulloracle and allworker lateCPUtileviews; all accepted output hashes match. Native references reused under source-qualified native path/config compatibility, not repeated just for model identity.

| Collected point | Active workers | ROI ticks |
|---|---:|---:|
| Best native4,bee838 |4|295564961|
| Best native16,bee838 |4|226721550|
| Earlier hybrid,36833 nofront |1|330726442|
| Current hybrid,5a634a43 |2|283914162|
| Current hybrid,5a634a43 |4|283724171|

Four is the fastest current observed hybrid point, only0.067% ahead of two in a single observation; do not claim robust/universal four-worker optimum. Primary comparison selects native and hybrid worker counts independently within maximum4CPUhardware, not equal active threads. Current best hybrid1.041733x bestnative4 and79.909142% bestnative16 throughput. Earlier hybrid1 staysreported, but transport/fronts changed beforecurrent2/4; do not label its delta purethreadscaling or silently assume samehardwarecost.

## Actual paging pressure and cost

| Current workers | Timed fill lines | Timed spill lines | Dirty evictions | Peak frames | CPU instructions total |
|---|---:|---:|---:|---:|---:|
|2|19456|18688|73|32/32|889385|
|4|38912|35840|140|32/32|1816557|

Two uses roughly half backing traffic/CPU instruction work at nearly equal latency; no energy claim. All successful logged pager requests pair with responses, zerooutstanding at exit; lateCPUviews transfers counted separately outsideROI. Frontend dirty ownership at WriteResp is allowed; not LLC/DRAM commit proof.

PhysicalSPD512KiB32frames; extra logicalready/directory/frame/32credit metadata and reviewed coherentfront cache/queues/ports/latencies are real. Region31-only front uses four512B/8way caches,32MSHRs/256targets/32normal+32reserve writeentries,1cycle tag/data/response; native ReadEx/Writeback directpath restored. Native16 physicalpayload2MiB. AboveLLC/two-bank transport is also treatment; not pure paging or equalarea speedup. No RowTable replacement,all16Kresidencygate,CPU perpage construction,worker reduction or global drain.

Old failed models/captures preserved. Full numerical pressure acceptance is case-specific, not universal coherence/liveness/fullMSHRsaturation or genericmask support. All originalsimjobs completed; no new model targets launched in this report. best-worker-comparison.json contains exact paths/hashes/counters and original policy qualification.
