"""Reconcile successful pager packets, separating timed ROI from late views."""
import argparse,gzip,json,re,collections
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('out',type=Path);a=p.parse_args();o=a.out
r=json.loads((o/'result.json').read_text());assert r['passed']
s=(o/'gem5/stats.txt').read_text().split('---------- Begin Simulation Statistics ----------')[1].split('---------- End Simulation Statistics')[0];end=int(re.search(r'^finalTick\s+(\d+)',s,re.M)[1]);start=end-int(re.search(r'^simTicks\s+(\d+)',s,re.M)[1])
log=(o/'run.log').read_text();reports=[{k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',l)} for l in log.splitlines() if 'device_spd tick=' in l];assert reports[0]['tick']==end
pending={};counts={k:collections.Counter() for k in ('pre_roi','roi','post_roi')};peak=0;addresses=set();last=0
with gzip.open(o/'gem5/commands.trace.gz','rt') as f:
 for l in f:
  m=re.match(r'(\d+): ([^:]+): (.*)',l)
  if not m:continue
  t,owner,msg=int(m[1]),m[2],m[3];last=t;phase='pre_roi' if t<start else 'roi' if t<=end else 'post_roi'
  if ('cache_side_port' in owner or 'retirement_side_port' in owner) and 'sendPacket: sending' in msg and '-31/31]' in msg:
   q=re.search(r'\[([0-9a-f]+):([0-9a-f]+)-31/31\]',msg);assert q;lo,hi=int(q[1],16),int(q[2],16);assert lo%64==0 and hi-lo==63;addresses.add(lo)
  m=re.search(r'pager_(send|response) write=(\d+) line=(\d+)',msg)
  if not m:continue
  event,w,line=m[1],int(m[2]),int(m[3]);key=(w,line);name='spill' if w else 'fill'
  if event=='send':assert key not in pending;pending[key]=t;peak=max(peak,len(pending));counts[phase][name+'_sends']+=1
  else:assert key in pending;pending.pop(key);counts[phase][name+'_responses']+=1
assert not pending and peak<=32
for kind in ('fill','spill'):
 assert counts['roi'][kind+'_responses']==reports[0][kind+'_lines']
 assert sum(c[kind+'_responses'] for c in counts.values())==reports[-1][kind+'_lines']
 assert sum(c[kind+'_sends'] for c in counts.values())==sum(c[kind+'_responses'] for c in counts.values())
cfg=json.loads((o/'gem5/config.json').read_text())['system'];llc=[tuple(map(int,x.split(':')[:2])) for x in cfg['l3']['addr_ranges']];assert addresses and all(any(x<=addr and addr+64<=y for x,y in llc) for addr in addresses)
print(json.dumps(dict(passed=True,roi_start=start,roi_end=end,phase_packet_counts={k:dict(v) for k,v in counts.items()},outstanding_logged_pager_requests_at_exit=len(pending),peak_logged_requests=peak,roi_backing_line_payload_bytes=64*(counts['roi']['fill_responses']+counts['roi']['spill_responses']),region31_unique_attempted_line_addresses=len(addresses),all_observed_region31_lines_llc_routed=True,late_cpu_views_not_charged_to_roi=True,write_response_semantics='Original pager frame/credit released after coherentfront accepts bytes;front may own dirty data,not proof LLC/DRAM already updated',limits='Complete observed pager request pairing and full output oracle in this execution,not universal liveness/MSHR saturation/physicalarea proof',source=str(o)),indent=2))
