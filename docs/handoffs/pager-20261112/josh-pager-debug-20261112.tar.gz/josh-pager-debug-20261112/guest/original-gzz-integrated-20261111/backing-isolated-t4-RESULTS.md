# Original GZZ4: real paging pressure PASS

Original65536corner GZZ, input5991432121607789265, four active OpenMP workers/four configured CPUs, same original guest ea88382f; global5tiles/worker,20logicalIDs, no forced ID/core partition or CPU serialization. Original two-pass masked Stream/gather/RMW and cached CPU intermediate writes retained. Full output oracle, stable input and all4late CPUtileviews PASS; whole output hash matches native controls. Actual CPU committed instructions450084/561379/176183/628911 confirm all four active.

| Best tested point | ROI ticks |
|---|---:|
| Native4,4workers |295564961|
| Native16,4workers |226721550|
| Hybrid16/physical4K,4workers |283724171|

Hybrid4 achieves1.041733x bestnative4 and79.909142% bestnative16 throughput. Native results are reused via explicit source-qualified unchanged native path, not new same-binary targets. Worker count is chosen independently within common maximum4CPUhardware; equal active workers are not an acceptance condition. Prior hybrid1 PASS330726442 remains unchanged but used earlier no-front transport, so do not label four-vs-one delta pure thread scaling. Remaining hybrid2 is running on this exact repaired profile.

Actual timed backing traffic:38912fill and35840spill successful64Brequests, every response paired,4784128B total line payload;140dirty evictions; peak32/32frames and32line credits.64403transfer retry events are modeled backpressure, not a full-MSHR saturation claim. At normal exit ALL94976observed pager requests are paired, outstanding0.20480unique region31 lines observed and LLC routed.

Late CPUtileviews AFTER ROI add17920fills/2304spills and9dirty evictions; not hidden/free and not included in timed packet counts. Coherent front may own dirty data at WriteResp; matching original pager ACKs do not mean LLC/DRAM already holds newest data. Full application/late-view correctness validates this case, not universal coherence/liveness.

Hardware treatment:32physical4Kframes512KiB,logical readiness/directory/frame/shared32line-credit metadata; two-bank SPD demand/snoop transport; four512B backing-only coherent front caches (2KiB data/32tags),32MSHRs/256targets,32normal+32reserve writequeue entries plus payloads/ports/control and1cycle tag/data/response latency. Native ReadEx/Writeback restored direct path. This is not pure paging or equal-total-area speedup; native16 payload is2MiB and area/frequency closure unmodeled. No extra payload frame, new RowTable or all16Kresidency gate.

Old protocol failures/diagnostic captures preserved. Exact model5a634a43, c4eb9457/frozen14172f98, actual loadedDSO86ac and process identity in backing-isolated-launch.json. Numerical, traffic and baseline paths/hashes in backing-isolated-t4-vs-best-native.json.
